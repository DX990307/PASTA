#!/usr/bin/env python3
"""Reproducible formal rebuttal runs with host-memory admission control."""

import argparse
import csv
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import tarfile
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
GIB = 1024 ** 3
BENCHMARKS = [
    "bitonicsort", "im2col", "floydwarshall", "aes", "relu", "spmv",
    "matrixmultiplication-ptw", "matrixtranspose", "fastwalshtransform",
    "fft", "kmeans", "pagerank", "simpleconvolution", "fir",
]
COMMON = [
    "-timing", "-num-memory-banks=16", "-bandwidth=48",
    "-switch-latency=32", "-magic-memory-copy", "-report-all",
    "-disable-servers", "-max-wg=76800", "-mmutlb-ptcl-return-latency=80",
    "-gmmu-num-req-per-cycle=128", "-gmmu-tlb-num-sets=16",
    "-gmmu-tlb-num-ways=16", "-gmmu-pte-lookup-latency=32",
    "-gmmu-pte-lookup-slots=8", "-gmmu-ptcl-line-size=8",
    "-gmmu-flex-pcd-ways=0", "-log2-page-size=12",
    "-translation-trace", "-translation-trace-window-cycles=100000",
]
DESIGNS = {
    "baseline": [
        "-gmmu-vpn-mshr-baseline", "-mmutlb-vpn-mshr-baseline",
        "-gmmu-initial-ptcl-mode=false", "-gmmu-ptcl-threshold-low=0",
        "-gmmu-ptcl-threshold-high=1000000", "-mmutlb-demand-pte-only",
        "-ptw-demand-pte-only",
    ],
    "pasta_full": [
        "-gmmu-ptcl-threshold-low=4", "-gmmu-ptcl-threshold-high=16",
        "-gmmu-initial-ptcl-mode=false", "-gmmu-flex-tlb",
        "-gmmu-flex-promotion-threshold=3", "-mmutlb-flex-tlb",
        "-gmmu-idle-iommu-assist", "-gmmu-ptcl-mshr-lifetime-profile",
    ],
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, obj):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def mem_available():
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    raise RuntimeError("MemAvailable is unavailable; refusing unrestricted launch")


def process_memory(pid):
    try:
        fields = {}
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            if line.startswith(("VmRSS:", "VmHWM:")):
                key, value, _ = line.split()
                fields[key[:-1]] = int(value) * 1024
        return fields.get("VmRSS", 0), fields.get("VmHWM", 0)
    except FileNotFoundError:
        return 0, 0


def prepare(batch):
    batch_dir = ROOT / "results" / batch
    batch_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = batch_dir / "manifest.json"
    if manifest_path.exists():
        raise RuntimeError(f"Existing manifest must not be overwritten: {manifest_path}")
    artifacts = ROOT / "artifacts"
    artifacts.mkdir(exist_ok=True)
    binary = artifacts / f"simulator-{batch}"
    if binary.exists():
        raise RuntimeError(f"Refusing to overwrite frozen binary: {binary}")
    env = os.environ.copy()
    env.update(GOCACHE="/tmp/gocache", GOTOOLCHAIN="local", GOPROXY="off", GOSUMDB="off")
    command = ["go", "build", "-mod=readonly", "-buildvcs=false", "-o", str(binary), "."]
    build_cwd = ROOT / "src" / "akkalat" / "400latency"
    with (artifacts / f"build-{batch}.log").open("w") as log:
        subprocess.run(command, cwd=build_cwd, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True)
    source_files = sorted(p for p in (ROOT / "src").rglob("*") if p.is_file()
                          and "__pycache__" not in p.parts)
    sources = {str(p.relative_to(ROOT / "src")): digest(p) for p in source_files}
    archive = artifacts / f"source-{batch}.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        for p in source_files:
            tar.add(p, arcname=str(p.relative_to(ROOT / "src")), recursive=False)
    provenance = {
        "created_at": utc(), "origin": "PASTA-hyperscan-current-20260619",
        "origin_head": "42fad1e", "includes_preexisting_worktree_changes": True,
        "build_command": command, "binary_sha256": digest(binary),
        "archive_sha256": digest(archive), "source_sha256": sources,
    }
    write_json(artifacts / f"provenance-{batch}.json", provenance)
    points = [(n, 4, 16) for n in [16, 32, 64, 128, 1024]]
    points += [(16, local, shared) for local in [4, 8, 16] for shared in [16, 32, 64]]
    points += [(16, 64, 256)]
    points = list(dict.fromkeys(points))
    jobs = []
    for mshr, local, shared in points:
        for benchmark in BENCHMARKS:
            for design, design_flags in DESIGNS.items():
                job_id = f"{benchmark}__{design}__m{mshr}_g{local}_i{shared}"
                job_dir = batch_dir / job_id
                flags = [f"-gmmu-mshr-entries={mshr}", "-iommu-mshr-entries=64",
                         f"-gmmu-ptw-count={local}", f"-iommu-ptw-count={shared}"]
                jobs.append({
                    "id": job_id, "benchmark": benchmark, "design": design,
                    "gmmu_mshr_entries": mshr, "iommu_mshr_entries": 64,
                    "gmmu_ptw_count": local, "iommu_ptw_count": shared,
                    "reviewers": "A,C,D,E,F,G", "max_wg": 76800,
                    "expected_gpms": 48,
                    "command": [str(binary), f"-benchmark={benchmark}"] + COMMON
                               + design_flags + flags
                               + [f"-metric-file-name={job_dir / 'metrics'}"],
                })
    manifest = {"batch": batch, "created_at": utc(), "binary": str(binary),
                "binary_sha256": provenance["binary_sha256"], "formal_runs": True,
                "reserve_gib": 30, "jobs": jobs}
    write_json(manifest_path, manifest)
    print(f"Prepared {len(jobs)} formal runs in {batch_dir}", flush=True)


def metrics_for(job, directory):
    metrics = directory / "metrics.csv"
    values = {}
    per_cu = {}
    per_gpm = {}
    with metrics.open() as f:
        for row in csv.reader(f):
            if len(row) != 4:
                continue
            _, where, what, raw = [v.strip() for v in row]
            try:
                value = float(raw)
            except ValueError:
                continue
            if where in {"Driver", "RebuttalConfig"}:
                values[f"{where}.{what}"] = value
            if what == "wg_completed":
                if ".CU[" in where:
                    per_cu[where] = value
                elif ".CommandProcessor" in where or ".CP" in where:
                    per_gpm[where] = value
    total_time = values.get("Driver.total_time", 0)
    completed = values.get("Driver.wg_completed", 0)
    if not math.isfinite(total_time) or total_time <= 0 or completed <= 0:
        raise ValueError("Missing or invalid Driver total_time / completed workgroups")
    for key in ["gmmu_mshr_entries", "iommu_mshr_entries", "gmmu_ptw_count", "iommu_ptw_count"]:
        if values.get(f"RebuttalConfig.{key}") != job[key]:
            raise ValueError(f"Simulator configuration mismatch: {key}")
    if values.get("RebuttalConfig.max_wg") != job["max_wg"]:
        raise ValueError("Wrong workgroup cap")
    if values.get("RebuttalConfig.num_gpms") != job["expected_gpms"]:
        raise ValueError("Wrong GPM count")
    if completed > job["max_wg"]:
        raise ValueError("Completed workgroups exceeded limit")
    if sum(per_cu.values()) != completed:
        raise ValueError(f"Per-CU completion count {sum(per_cu.values())} != {completed}")
    return {"driver_time_s": total_time, "completed_wg": completed,
            "active_gpms": values.get("Driver.wg_active_gpms"),
            "wg_limit_reached": values.get("Driver.wg_limit_reached"),
            "wg_inflight_at_stop": values.get("Driver.wg_inflight_at_stop"),
            "metrics_sha256": digest(metrics), "per_gpm_wg_completed": per_gpm}


def summarize(directory, manifest):
    rows = []
    for job in manifest["jobs"]:
        state_file = directory / job["id"] / "state.json"
        state = json.loads(state_file.read_text()) if state_file.exists() else {"status": "queued"}
        rows.append({key: job[key] for key in ["id", "benchmark", "design", "gmmu_mshr_entries",
                    "iommu_mshr_entries", "gmmu_ptw_count", "iommu_ptw_count"]}
                    | {key: state.get(key, "") for key in ["status", "driver_time_s", "completed_wg",
                       "active_gpms", "wg_limit_reached", "wall_seconds", "peak_rss_gib", "error"]})
    temporary = directory / "summary.csv.tmp"
    with temporary.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(directory / "summary.csv")
    return rows


def run(batch, reserve_gib, max_workers, initial_job_gib):
    directory = ROOT / "results" / batch
    manifest = json.loads((directory / "manifest.json").read_text())
    if digest(manifest["binary"]) != manifest["binary_sha256"]:
        raise RuntimeError("Frozen executable hash changed")
    lock = (ROOT / "scheduler.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    queue = []
    for job in manifest["jobs"]:
        state_file = directory / job["id"] / "state.json"
        if not state_file.exists():
            queue.append(job)
            continue
        state = json.loads(state_file.read_text())
        if state["status"] == "completed":
            continue
        # Failed/interrupted outputs remain reviewable; a new manifest is used for reruns.
        if state["status"] in {"running", "interrupted"}:
            raise RuntimeError(f"Unresolved previous run: {job['id']}")
    running = []
    learned_peaks = {}
    reserve = reserve_gib * GIB
    last_report = 0
    last_launch = 0
    interrupted = False

    def request_stop(signum, frame):
        nonlocal interrupted
        interrupted = True

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    print(f"{utc()} START {batch}: {len(queue)} queued; reserve={reserve_gib} GiB; cap={max_workers}", flush=True)
    try:
        while queue or running:
            for item in list(running):
                rss, peak = process_memory(item["process"].pid)
                item["rss"] = rss
                item["peak"] = max(item["peak"], peak)
                code = item["process"].poll()
                if code is None:
                    continue
                item["log"].close()
                state = item["state"]
                state.update(returncode=code, ended_at=utc(),
                             wall_seconds=round(time.monotonic() - item["start"], 3),
                             peak_rss_gib=round(item["peak"] / GIB, 3))
                try:
                    if code != 0:
                        raise ValueError(f"Exit code {code}")
                    state.update(metrics_for(item["job"], item["directory"]))
                    state["status"] = "completed"
                except (OSError, ValueError) as error:
                    state.update(status="failed", error=str(error))
                write_json(item["directory"] / "state.json", state)
                benchmark = item["job"]["benchmark"]
                learned_peaks[benchmark] = max(learned_peaks.get(benchmark, 0), item["peak"])
                running.remove(item)
                print(f"{utc()} {state['status'].upper()} {item['job']['id']} "
                      f"wall={state['wall_seconds']}s peak={state['peak_rss_gib']}GiB "
                      f"{state.get('error', '')}", flush=True)
            if interrupted:
                break
            available = mem_available()
            if available < reserve and running:
                # Reclaim only this campaign's jobs, retaining failure records for an explicit rerun.
                victim = max(running, key=lambda item: item["rss"])
                print(f"{utc()} MEMORY GUARD: available={available/GIB:.2f}GiB; "
                      f"terminating {victim['job']['id']} to restore reserve", flush=True)
                victim["process"].terminate()
                try:
                    victim["process"].wait(timeout=5)
                except subprocess.TimeoutExpired:
                    victim["process"].kill()
                    victim["process"].wait()
                continue
            pending_growth = sum(max(0, item["estimate"] - item["rss"]) for item in running)
            if queue and len(running) < max_workers and time.monotonic() - last_launch >= 2:
                job = queue[0]
                peak = learned_peaks.get(job["benchmark"], initial_job_gib * GIB)
                estimate = max(6 * GIB, peak * 1.25)
                if available - pending_growth - estimate >= reserve + 2 * GIB:
                    if shutil.disk_usage(directory).free < 3 * GIB:
                        raise RuntimeError("Less than 3 GiB disk free; stop admission")
                    queue.pop(0)
                    job_dir = directory / job["id"]
                    job_dir.mkdir()
                    write_json(job_dir / "job.json", job)
                    log = (job_dir / "stdout.log").open("w")
                    log.write(shlex.join(job["command"]) + "\n")
                    log.flush()
                    runtime_env = {"GODEBUG": "randautoseed=0"}
                    process = subprocess.Popen(job["command"], cwd=job_dir, stdout=log,
                                               stderr=subprocess.STDOUT,
                                               env=os.environ | runtime_env)
                    state = {"status": "running", "started_at": utc(), "pid": process.pid,
                             "launch_memavailable_gib": round(available / GIB, 3),
                             "runtime_env": runtime_env}
                    write_json(job_dir / "state.json", state)
                    running.append({"job": job, "directory": job_dir, "process": process,
                                    "log": log, "state": state, "start": time.monotonic(),
                                    "rss": 0, "peak": 0, "estimate": estimate})
                    last_launch = time.monotonic()
                    print(f"{utc()} LAUNCH {job['id']} pid={process.pid}; "
                          f"available={available/GIB:.1f}GiB active={len(running)}", flush=True)
            if time.monotonic() - last_report >= 30:
                rows = summarize(directory, manifest)
                totals = {key: sum(r["status"] == key for r in rows)
                          for key in ["queued", "running", "completed", "failed"]}
                write_json(directory / "status.json", {
                    "updated_at": utc(), **totals, "memavailable_gib": available / GIB,
                    "reserve_gib": reserve_gib, "max_workers": max_workers,
                    "running_pids": [item["process"].pid for item in running],
                })
                print(f"{utc()} STATUS {totals} available={available/GIB:.1f}GiB", flush=True)
                last_report = time.monotonic()
            time.sleep(1)
    finally:
        for item in running:
            item["process"].terminate()
        for item in running:
            try:
                item["process"].wait(timeout=5)
            except subprocess.TimeoutExpired:
                item["process"].kill()
                item["process"].wait()
            item["log"].close()
            item["state"].update(status="interrupted", ended_at=utc())
            write_json(item["directory"] / "state.json", item["state"])
        rows = summarize(directory, manifest)
        write_json(directory / "status.json", {
            "updated_at": utc(), "stopped": True, "interrupted": interrupted,
            **{key: sum(r["status"] == key for r in rows)
               for key in ["queued", "running", "completed", "failed", "interrupted"]},
            "reserve_gib": reserve_gib, "memavailable_gib": mem_available() / GIB,
        })
    print(f"{utc()} STOP {batch} interrupted={interrupted}", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["prepare", "run", "summarize"])
    parser.add_argument("--batch", default="capacity-v1")
    parser.add_argument("--reserve-gib", type=float, default=30)
    parser.add_argument("--max-workers", type=int, default=128)
    parser.add_argument("--initial-job-gib", type=float, default=10)
    args = parser.parse_args()
    if args.reserve_gib < 30 or args.max_workers < 1 or args.initial_job_gib <= 0:
        parser.error("reserve must be >=30 GiB; workers and job estimate must be positive")
    if args.action == "prepare":
        prepare(args.batch)
    elif args.action == "run":
        run(args.batch, args.reserve_gib, args.max_workers, args.initial_job_gib)
    else:
        directory = ROOT / "results" / args.batch
        summarize(directory, json.loads((directory / "manifest.json").read_text()))


if __name__ == "__main__":
    main()
