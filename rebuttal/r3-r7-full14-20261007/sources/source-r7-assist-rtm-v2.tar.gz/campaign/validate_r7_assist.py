#!/usr/bin/env python3
"""Record R7 controlled-flow verification, not a reduced-input GPU pilot."""

import json
import os
import subprocess

import campaign


def main():
    root = campaign.ROOT
    stamp = campaign.utc().replace(":", "").replace("+0000", "Z")
    out = root / "analysis/diagnostics/r7-assist" / stamp
    out.mkdir(parents=True, exist_ok=False)
    env = os.environ | {"GOCACHE": "/tmp/gocache", "GOTOOLCHAIN": "local", "GOPROXY": "off",
                        "GOSUMDB": "off", "GOMAXPROCS": "2", "GODEBUG": "randautoseed=0"}
    src = root / "src"
    paths = sorted(list((src / "akita").rglob("*.go")) + list((src / "akkalat/assiststudy").glob("*.go"))
                   + list((src / "akkalat/cmd/assist-interference").glob("*.go")))
    sources = {str(p.relative_to(src)): campaign.digest(p) for p in paths}
    mmu_dir = src / "akita/mem/vm/mmu"
    listing = subprocess.run(["go", "list", "-mod=readonly", "-json", "."], cwd=mmu_dir,
                             env=env, text=True, capture_output=True, check=True)
    mmu_files = json.loads(listing.stdout)["GoFiles"] + ["fixed_capacity_control_test.go", "observation_test.go"]
    results = []
    jobs = []
    for race in [False, True]:
        suffix = "-race" if race else ""
        cmd = ["go", "test", "-p=1", "-mod=readonly", "-count=1", "-timeout=180s", "-v"]
        cmd += ["-race"] if race else []
        jobs.append(("controlled-flow" + suffix, src / "akkalat", cmd + ["./assiststudy"]))
        jobs.append(("mmu-focused" + suffix, mmu_dir, cmd + mmu_files))
    jobs.append(("build", src / "akkalat", ["go", "build", "-p=1", "-mod=readonly", "-buildvcs=false",
                                           "-o", "/tmp/pasta-r7-assist-development", "./cmd/assist-interference"]))
    for name, cwd, cmd in jobs:
        path = out / f"{name}.log"
        with path.open("w") as log:
            run = subprocess.run(cmd, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
        results.append({"name": name, "cmd": cmd, "cwd": str(cwd), "returncode": run.returncode,
                        "log": str(path), "log_sha256": campaign.digest(path)})
        print(f"{name}: exit {run.returncode}", flush=True)
    if sources != {str(p.relative_to(src)): campaign.digest(p) for p in paths}:
        raise RuntimeError("Source changed during R7 validation")
    record = {"created_at": campaign.utc(), "tests": results, "source_sha256": sources,
              "scope": "R7's two approved controlled translation flows with 48-GPM translation resources; "
                       "component tests and observer noninterference, not a GPU workload or external calibration. "
                       "MMU legacy mock lacks GetLastPage; focused production-file tests exclude the stale mock suite."}
    campaign.write_json(out / "tests.json", record)
    campaign.write_json(root / "analysis/diagnostics/r7-assist/latest.json",
                        {"record": str(out / "tests.json"), "sha256": campaign.digest(out / "tests.json")})
    print(out / "tests.json", flush=True)
    if any(x["returncode"] for x in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
