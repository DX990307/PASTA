#!/usr/bin/env python3
"""Freeze and run only R7's four controlled-flow points, separate from GPU jobs."""

import argparse
import csv
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import tarfile
import time

import campaign
import runtime_health


BATCH = "r7-assist-v1"
ENV = {"GOCACHE": "/tmp/gocache", "GOTOOLCHAIN": "local", "GOPROXY": "off",
       "GOSUMDB": "off", "GOMAXPROCS": "2", "GODEBUG": "randautoseed=0"}


def json_objects(text):
    decoder = json.JSONDecoder()
    while text.strip():
        text = text.lstrip()
        value, end = decoder.raw_decode(text)
        yield value
        text = text[end:]


def directory():
    return campaign.ROOT / "controlled-results" / BATCH


def prepare():
    root, src = campaign.ROOT, campaign.ROOT / "src"
    dest = directory()
    if dest.exists():
        raise ValueError("Controlled batch exists; verify/reuse it, never overwrite")
    validation_ref = root / "analysis/diagnostics/r7-assist/latest.json"
    reference = json.loads(validation_ref.read_text())
    validation_path = Path(reference["record"])
    if campaign.digest(validation_path) != reference["sha256"]:
        raise ValueError("Validation record hash mismatch")
    validation = json.loads(validation_path.read_text())
    if {x["name"] for x in validation["tests"]} != {
            "controlled-flow", "controlled-flow-race", "mmu-focused", "mmu-focused-race", "build"}:
        raise ValueError("Missing required controlled-flow/observer validation")
    if any(x["returncode"] for x in validation["tests"]):
        raise ValueError("Validation did not pass")
    for name, expected in validation["source_sha256"].items():
        if campaign.digest(src / name) != expected:
            raise ValueError(f"Source changed since validation: {name}")
    env = os.environ | ENV
    listing = subprocess.run(["go", "list", "-deps", "-mod=readonly", "-buildvcs=false", "-json", "./cmd/assist-interference"],
                             cwd=src / "akkalat", env=env, text=True, capture_output=True, check=True)
    files = set()
    for package in json_objects(listing.stdout):
        folder = Path(package["Dir"])
        if not folder.is_relative_to(src):
            continue
        for field in ["GoFiles", "CgoFiles", "CFiles", "HFiles", "SFiles", "EmbedFiles"]:
            files.update(folder / name for name in package.get(field, []))
    files.update(src / module / name for module in ["akita", "akkalat", "mgpusim"] for name in ["go.mod", "go.sum"])
    files.update((src / "akkalat/assiststudy").glob("*_test.go"))
    files.add(src / "akita/mem/vm/mmu/observation_test.go")
    hashes = {str(path.relative_to(src)): campaign.digest(path) for path in sorted(files)}
    artifacts = root / "artifacts"
    binary = artifacts / f"simulator-{BATCH}"
    archive = artifacts / f"source-{BATCH}.tar.gz"
    provenance_path = artifacts / f"provenance-{BATCH}.json"
    if any(p.exists() for p in [binary, archive, provenance_path]):
        raise ValueError("Partial frozen artifact already exists; audit before preparing another version")
    build = ["go", "build", "-p=1", "-mod=readonly", "-buildvcs=false", "-o", str(binary), "./cmd/assist-interference"]
    log = artifacts / f"build-{BATCH}.log"
    with log.open("x") as output:
        subprocess.run(build, cwd=src / "akkalat", env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
    with tarfile.open(archive, "x:gz") as target:
        for path in sorted(files):
            target.add(path, arcname="src/" + str(path.relative_to(src)))
        for name in ["r7_assist_campaign.py", "validate_r7_assist.py", "campaign.py"]:
            target.add(root / name, arcname="campaign/" + name)
    if hashes != {str(path.relative_to(src)): campaign.digest(path) for path in sorted(files)}:
        raise ValueError("Build source changed during freeze")
    go_version = subprocess.run(["go", "version", "-m", str(binary)], env=env, text=True,
                                capture_output=True, check=True).stdout
    provenance = {"created_at": campaign.utc(), "source_sha256": hashes,
                  "source_archive": str(archive), "archive_sha256": campaign.digest(archive),
                  "binary": str(binary), "binary_sha256": campaign.digest(binary), "build": build,
                  "build_log_sha256": campaign.digest(log), "go_build_metadata": go_version,
                  "validation": reference, "environment": ENV,
                  "scope": "Only approved R7 controlled translation requests; full 48-GPM translation "
                           "resources, fixed 500-cycle service, existing Assist policy. No GPU pilot or new sweep."}
    campaign.write_json(provenance_path, provenance)
    dest.mkdir(parents=True)
    jobs = []
    for scenario in ["native-burst", "capacity-race"]:
        for assist in [False, True]:
            identity = f"{scenario}__assist_{'on' if assist else 'off'}"
            output = dest / identity / "result.json"
            jobs.append({"id": identity, "scenario": scenario, "assist": assist,
                         "command": [str(binary), f"-scenario={scenario}", f"-assist={str(assist).lower()}",
                                     f"-output={output}"]})
    manifest = {"created_at": campaign.utc(), "batch": BATCH, "kind": "controlled-translation-flow",
                "binary": str(binary), "binary_sha256": provenance["binary_sha256"],
                "provenance": str(provenance_path), "provenance_sha256": campaign.digest(provenance_path),
                "jobs": jobs, "reviewers": "D/E/F", "scope_task": "R7", "gpu_max_wg": "not applicable"}
    campaign.write_json(dest / "manifest.json", manifest)
    print(f"Prepared {len(jobs)} controlled R7 points: {dest}")


def verify_manifest():
    manifest = json.loads((directory() / "manifest.json").read_text())
    provenance = json.loads(Path(manifest["provenance"]).read_text())
    if (campaign.digest(manifest["binary"]) != manifest["binary_sha256"] or
            campaign.digest(manifest["provenance"]) != manifest["provenance_sha256"] or
            campaign.digest(provenance["source_archive"]) != provenance["archive_sha256"]):
        raise ValueError("Frozen controlled artifacts changed")
    expected = {(scenario, assist) for scenario in ["native-burst", "capacity-race"] for assist in [False, True]}
    if len(manifest["jobs"]) != 4 or {(x["scenario"], x["assist"]) for x in manifest["jobs"]} != expected:
        raise ValueError("Not the approved four-point R7 matrix")
    return manifest


def validate_result(result, job):
    if (result["Scenario"] != job["scenario"] or result["Assist"] != job["assist"] or not result["Observed"]):
        raise ValueError("Controlled result configuration mismatch")
    identities, native, assisted = set(), [], []
    for row in result["Requests"]:
        if row["ID"] in identities:
            raise ValueError("Duplicate controlled identity")
        identities.add(row["ID"])
        if row["Returned"] < row["SourceAccepted"] or row["SourceAccepted"] < row["ReadyCycle"]:
            raise ValueError("Invalid controlled request timing")
        if row["Class"] == "native":
            if row["ReadyCycle"] != 400 or row["IssuePath"] != "native":
                raise ValueError("Native request changed readiness or route")
            native.append(row["Returned"] - row["ReadyCycle"])
        elif row["Class"] == "assist-candidate":
            wanted_path = "assist" if job["assist"] else ""
            if row["ReadyCycle"] != 0 or row["Owner"] != row["GPM"] or row["IssuePath"] != wanted_path:
                raise ValueError("Assist candidate changed readiness, ownership, or intended route")
            assisted.append(row)
        else:
            raise ValueError("Unknown controlled request class")
        if row["IssuePath"] in {"native", "assist"} and row["WalkEnded"] - row["WalkStarted"] != 500:
            raise ValueError("Controlled service duration changed")
    wanted_assists = 16 if job["scenario"] == "native-burst" else 94
    if len(native) != 64 or len(assisted) != wanted_assists:
        raise ValueError("Wrong controlled-flow population")
    native.sort()
    want = {"Count": 64, "Mean": statistics.mean(native), "P50": native[31],
            "P95": native[60], "P99": native[63], "Max": native[-1]}
    if any(not math.isclose(result["NativeLatency"][k], v, rel_tol=1e-12) for k, v in want.items()):
        raise ValueError("Native latency summary disagrees with per-request evidence")
    if result["PeakPTW"] > 16 or result["NativeSendFailures"] <= 0:
        raise ValueError("Walker capacity or source backpressure not verified")
    if job["assist"] and (result["AssistedWalksAtNativeReady"] == 0 or
                           result["AssistIssuesBeforeNativeReady"] != wanted_assists):
        raise ValueError("Required overlap/over-forwarding scenario was not exercised")
    if not job["assist"] and (result["AssistedWalksAtNativeReady"] or result["AssistQueries"] or
                              result["AssistIssuesBeforeNativeReady"]):
        raise ValueError("Assist OFF still queries or consumes shared capacity")
    for path, count in [("native", 64), ("assist", wanted_assists if job["assist"] else 0)]:
        if result["Network"].get("message_e2e.request." + path, {}).get("Started", 0) != count:
            raise ValueError("Network request population disagrees with original request identities")
    for counter in result["Network"].values():
        if counter["Started"] != counter["Completed"] or counter["Inflight"] != 0 or counter["InvalidDurations"] != 0:
            raise ValueError("Controlled network did not fully drain")
    return result


def run():
    manifest = verify_manifest()
    for job in manifest["jobs"]:
        target = directory() / job["id"]
        target.mkdir(exist_ok=True)
        state_path = target / "state.json"
        if state_path.exists():
            state = json.loads(state_path.read_text())
            if state["status"] != "completed":
                raise ValueError("Preserve unfinished/failed attempt; inspect its PID and evidence before another attempt")
            if campaign.digest(target / "result.json") != state["result_sha256"]:
                raise ValueError("Completed controlled result changed")
            validate_result(json.loads((target / "result.json").read_text()), job)
            print(f"Reused completed {job['id']}", flush=True)
            continue
        scoped = json.loads((campaign.ROOT / "scope/status.json").read_text())
        available = campaign.mem_available() / 2**30
        required = 30 + scoped["growth_reserved_gib"] + .25
        if available < required:
            raise RuntimeError(f"Wait for memory: {available:.2f} GiB available, {required:.2f} reserved including control")
        started = time.monotonic()
        state = {"status": "running", "started_at": campaign.utc(), "job": job,
                 "launch_memavailable_gib": available, "existing_growth_reservation_gib": scoped["growth_reserved_gib"],
                 "memory_envelope_gib": .25, "environment": ENV}
        with (target / "stdout.log").open("x") as log:
            child = subprocess.Popen(job["command"], cwd=target, env=os.environ | ENV,
                                     stdout=log, stderr=subprocess.STDOUT)
            state["pid"] = child.pid
            state["process"] = runtime_health.read_process(child.pid)
            campaign.write_json(state_path, state)
            peak, minimum = 0, available
            while child.poll() is None:
                peak = max(peak, *campaign.process_memory(child.pid))
                minimum = min(minimum, campaign.mem_available() / 2**30)
                time.sleep(.02)
            state.update(returncode=child.returncode, ended_at=campaign.utc(),
                         wall_seconds=time.monotonic()-started, peak_rss_gib=peak/2**30,
                         min_memavailable_gib=minimum)
        state["stdout_sha256"] = campaign.digest(target / "stdout.log")
        try:
            if child.returncode != 0:
                raise ValueError("Controlled executable returned nonzero")
            if minimum < 30 or peak / 2**30 > .25:
                raise ValueError("Controlled memory invariant/envelope violated")
            validate_result(json.loads((target / "result.json").read_text()), job)
            state.update(status="completed", result_sha256=campaign.digest(target / "result.json"))
        except Exception as error:
            state.update(status="failed", error=str(error))
            campaign.write_json(state_path, state)
            raise
        campaign.write_json(state_path, state)
        print(f"Completed {job['id']}: peak {peak/2**20:.1f} MiB", flush=True)
    summarize()


def summarize():
    manifest = verify_manifest()
    data = {}
    for job in manifest["jobs"]:
        target = directory() / job["id"]
        state = json.loads((target / "state.json").read_text())
        if state["status"] != "completed" or campaign.digest(target / "result.json") != state["result_sha256"]:
            raise ValueError("Comparison requires unchanged completed controlled results")
        data[(job["scenario"], job["assist"])] = validate_result(json.loads((target / "result.json").read_text()), job)
    summaries, paired = [], []
    identity_fields = ["ID", "Class", "GPM", "ReadyCycle", "PID", "VAddr", "Owner"]
    for scenario in ["native-burst", "capacity-race"]:
        off, on = data[(scenario, False)], data[(scenario, True)]
        if off["Config"] != on["Config"] or off["Model"] != on["Model"]:
            raise ValueError("Controlled hardware/model differs between OFF/ON")
        a = {x["ID"]: x for x in off["Requests"]}
        b = {x["ID"]: x for x in on["Requests"]}
        if a.keys() != b.keys() or any(any(a[k][f] != b[k][f] for f in identity_fields) for k in a):
            raise ValueError("OFF/ON did not replay the same original request population")
        deltas = []
        for key in a:
            if a[key]["Class"] != "native":
                continue
            x, y = a[key], b[key]
            delta = y["Returned"] - x["Returned"]
            deltas.append(delta)
            paired.append({"scenario": scenario, "id": key, "ready": x["ReadyCycle"],
                           "off_source_accepted": x["SourceAccepted"], "on_source_accepted": y["SourceAccepted"],
                           "off_returned": x["Returned"], "on_returned": y["Returned"], "delay_delta": delta})
        summaries.append({"scenario": scenario, "native_off": off["NativeLatency"], "native_on": on["NativeLatency"],
                          "mean_delta_cycles": statistics.mean(deltas), "max_same_request_delta_cycles": max(deltas),
                          "min_same_request_delta_cycles": min(deltas),
                          "mean_latency_increase_pct": (on["NativeLatency"]["Mean"] / off["NativeLatency"]["Mean"] - 1)*100,
                          "assist_issues_before_native_ready": on["AssistIssuesBeforeNativeReady"],
                          "active_assisted_walks_at_native_ready": on["AssistedWalksAtNativeReady"],
                          "peak_shared_queue": on["PeakPWQueue"], "peak_outstanding_assists": on["PeakOutstandingAssists"],
                          "control_message_bytes": None, "control_bytes_reason": "no modeled capacity-advertisement packets"})
    out = directory() / "summary.json"
    record = {"created_at": campaign.utc(), "summary": summaries, "limits": data[("native-burst", False)]["Limits"],
              "manifest_sha256": campaign.digest(directory() / "manifest.json"),
              "analysis_sha256": campaign.digest(__file__)}
    if out.exists():
        existing = json.loads(out.read_text())
        if existing["summary"] != summaries:
            raise ValueError("Existing controlled summary disagrees; preserve it for audit")
    else:
        campaign.write_json(out, record)
        with (directory() / "native-paired-requests.csv").open("x", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(paired[0]))
            writer.writeheader()
            writer.writerows(paired)
    print(json.dumps(summaries, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["prepare", "run", "summarize"])
    args = parser.parse_args()
    {"prepare": prepare, "run": run, "summarize": summarize}[args.action]()


if __name__ == "__main__":
    main()
