package pipelining

import (
	"math"
	"reflect"

	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

type delayedItem struct {
	elem       PipelineItem
	readyCycle uint64
}

// delayQueue models bounded in-flight storage independently of propagation
// delay. It is not a stage-by-stage pipeline: backpressure retains ready items.
type delayQueue struct {
	sim.HookableBase
	name                                         string
	freq                                         sim.Freq
	latency, width                               int
	out                                          sim.Buffer
	items                                        []delayedItem
	head, size                                   int
	cycle                                        uint64
	hasCycle                                     bool
	accepted, emitted                            int
	totalAccepted, totalEmitted, readyWaitCycles uint64
	peakItems                                    int
}

// NewDelayQueue creates a FIFO with fixed item capacity and per-cycle input and
// output limits. Call Tick before CanAccept in each component cycle. Items age
// in simulation time, including intervals when downstream backpressure stops
// the component from ticking.
func NewDelayQueue(name string, freq sim.Freq, latency, width, capacity int, out sim.Buffer) Pipeline {
	sim.NameMustBeValid(name)
	if freq <= 0 || math.IsNaN(float64(freq)) || math.IsInf(float64(freq), 0) ||
		latency <= 0 || width <= 0 || capacity <= 0 || out == nil {
		panic("delay queue requires positive frequency, latency, width, capacity, and an output buffer")
	}
	return &delayQueue{
		name: name, freq: freq, latency: latency, width: width, out: out,
		items: make([]delayedItem, capacity),
	}
}

func (p *delayQueue) Name() string { return p.name }

func (p *delayQueue) startCycle(now sim.VTimeInSec) {
	cycle := p.freq.Cycle(now)
	if p.hasCycle && cycle < p.cycle {
		panic("delay queue time moved backwards")
	}
	if !p.hasCycle || cycle != p.cycle {
		p.cycle, p.hasCycle = cycle, true
		p.accepted, p.emitted = 0, 0
	}
}

func (p *delayQueue) CanAccept() bool {
	return p.size < len(p.items) && p.accepted < p.width
}

func (p *delayQueue) Accept(now sim.VTimeInSec, elem PipelineItem) {
	p.startCycle(now)
	if !p.CanAccept() || elem == nil {
		panic("delay queue cannot accept item")
	}
	tail := (p.head + p.size) % len(p.items)
	p.items[tail] = delayedItem{elem: elem, readyCycle: p.cycle + uint64(p.latency)}
	p.size++
	p.accepted++
	p.totalAccepted++
	if p.size > p.peakItems {
		p.peakItems = p.size
	}
	tracing.StartTask(elem.TaskID()+"pipeline", elem.TaskID(), p,
		"pipeline", reflect.TypeOf(elem).String(), nil)
}

func (p *delayQueue) Tick(now sim.VTimeInSec) bool {
	p.startCycle(now)
	progress := false
	for p.size > 0 && p.emitted < p.width {
		item := &p.items[p.head]
		if item.readyCycle > p.cycle {
			// Keep the ticking component awake until the head becomes ready.
			return true
		}
		if !p.out.CanPush() {
			return progress
		}
		p.totalEmitted++
		p.readyWaitCycles += p.cycle - item.readyCycle
		tracing.EndTask(item.elem.TaskID()+"pipeline", p)
		p.out.Push(item.elem)
		*item = delayedItem{}
		p.head = (p.head + 1) % len(p.items)
		p.size--
		p.emitted++
		progress = true
	}
	return progress
}

func (p *delayQueue) Clear() {
	clear(p.items)
	p.head, p.size = 0, 0
	p.cycle, p.hasCycle = 0, false
	p.accepted, p.emitted = 0, 0
	p.totalAccepted, p.totalEmitted, p.readyWaitCycles = 0, 0, 0
	p.peakItems = 0
}

// DelayQueueStats is a read-only snapshot. Delay and ready-wait totals cover
// departed items only; in-flight items at the observation boundary are separate.
func (p *delayQueue) DelayQueueStats() map[string]uint64 {
	return map[string]uint64{
		"capacity_flits": uint64(len(p.items)), "latency_cycles": uint64(p.latency),
		"width_flits_per_cycle": uint64(p.width), "accepted_flits": p.totalAccepted,
		"departed_flits": p.totalEmitted, "inflight_flits": uint64(p.size),
		"peak_flits": uint64(p.peakItems), "departed_ready_wait_flit_cycles": p.readyWaitCycles,
		"departed_base_delay_flit_cycles": p.totalEmitted * uint64(p.latency),
	}
}
