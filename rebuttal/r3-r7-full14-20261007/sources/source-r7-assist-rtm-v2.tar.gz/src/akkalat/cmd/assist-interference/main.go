package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	"github.com/sarchlab/akkalat/assiststudy"
)

func main() {
	scenario := flag.String("scenario", "", "native-burst or capacity-race")
	assist := flag.Bool("assist", false, "enable unchanged Idle-IOMMU Assist policy")
	output := flag.String("output", "", "new output JSON path")
	flag.Parse()
	if *output == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "scenario and output are required; positional arguments are unsupported")
		os.Exit(2)
	}
	if _, err := os.Stat(*output); err == nil || !os.IsNotExist(err) {
		fmt.Fprintln(os.Stderr, "refusing to replace or access existing output")
		os.Exit(2)
	}
	result, err := assiststudy.RunMonitored(*scenario, *assist, true)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		panic(err)
	}
	f, err := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		panic(err)
	}
	if _, err := f.Write(append(data, '\n')); err != nil {
		panic(err)
	}
	if err := f.Close(); err != nil {
		panic(err)
	}
	fmt.Printf("%s assist=%v native_mean=%.3f native_p99=%.3f cycles; output=%s\n",
		*scenario, *assist, result.NativeLatency.Mean, result.NativeLatency.P99, *output)
}
