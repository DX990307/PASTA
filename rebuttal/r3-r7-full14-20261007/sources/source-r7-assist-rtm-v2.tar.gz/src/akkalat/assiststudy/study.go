// Package assiststudy replays the two approved R7 translation request flows.
package assiststudy

import (
	"fmt"
	"math"
	"reflect"
	"sort"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/mmu"
	"github.com/sarchlab/akita/v3/mem/vm/mmuCache"
	"github.com/sarchlab/akita/v3/mem/vm/mmuTLB"
	"github.com/sarchlab/akita/v3/mem/vm/tlb_gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/monitoring"
	"github.com/sarchlab/akita/v3/noc/networking/mesh"
	"github.com/sarchlab/akita/v3/noc/networking/trafficstats"
	"github.com/sarchlab/akita/v3/sim"
)

const nativeGPM = 24

// RequestSpec records pre-backpressure identity and readiness, identical OFF/ON.
type RequestSpec struct {
	ID         string
	Class      string
	GPM        int
	ReadyCycle int64
	PID        vm.PID
	VAddr      uint64
	Owner      uint64
}

type RequestResult struct {
	RequestSpec
	SourceAccepted, Returned int64
	L2Issued, SharedArrived  int64
	WalkStarted, WalkEnded   int64
	IssuePath                string
	PTWInflightAtIssue       int
	SendFailures             int
}

type Occupancy struct {
	Cycle                      int64
	Active, Queued, Backlog    int
	ActiveAssist, ActiveNative int
}

type Summary struct {
	Count                    int
	Mean, P50, P95, P99, Max float64
}

type Result struct {
	Scenario, Model                   string
	Assist                            bool
	Observed                          bool
	Requests                          []RequestResult
	Occupancy                         []Occupancy
	NativeLatency                     Summary
	PeakPTW, PeakPWQueue, PeakBacklog int
	PeakOutstandingAssists            int
	AssistIssuesBeforeNativeReady     int
	AssistedWalksAtNativeReady        int
	AssistQueries, FreeAssistQueries  int
	NativeSendFailures                int
	Network                           map[string]trafficstats.Counter
	Config                            map[string]int
	Limits                            []string
}

func Plan(scenario string) ([]RequestSpec, error) {
	var result []RequestSpec
	appendRequest := func(class string, gpm int, ready int64, owner uint64) {
		result = append(result, RequestSpec{ID: fmt.Sprintf("r7-%s-%03d", class, len(result)),
			Class: class, GPM: gpm, ReadyCycle: ready, PID: 1,
			VAddr: uint64(len(result)+1) << 21, Owner: owner})
	}
	switch scenario {
	case "native-burst":
		for gpm := 1; gpm <= 16; gpm++ {
			appendRequest("assist-candidate", gpm, 0, uint64(gpm))
		}
	case "capacity-race":
		for gpm := 1; gpm <= 48; gpm++ {
			if gpm == nativeGPM {
				continue
			}
			for i := 0; i < 2; i++ {
				appendRequest("assist-candidate", gpm, 0, uint64(gpm))
			}
		}
	default:
		return nil, fmt.Errorf("unknown R7 scenario %q", scenario)
	}
	for i := 0; i < 64; i++ {
		appendRequest("native", nativeGPM, 400, 1)
	}
	return result, nil
}

type source struct {
	*sim.TickingComponent
	port, target sim.Port
	pending      []*vm.TranslationReq
	records      map[string]*RequestResult
	pageTable    vm.PageTable
}

func cycles(now sim.VTimeInSec) int64 { return int64(math.Round(float64(now) * 1e9)) }

func (s *source) Tick(now sim.VTimeInSec) bool {
	progress := false
	for s.port.Peek() != nil {
		rsp := s.port.Retrieve(now).(*vm.TranslationRsp)
		record := s.records[rsp.RespondTo]
		if record == nil || record.Returned >= 0 {
			panic("missing or duplicate R7 requester identity")
		}
		page, found := s.pageTable.Find(record.PID, record.VAddr)
		if !found || !page.Valid || rsp.Page != page || rsp.Dst != s.port ||
			rsp.TaskID != record.ID || rsp.OriginPort != s.port {
			panic("incorrect R7 translation response")
		}
		record.Returned = cycles(now)
		progress = true
	}
	for len(s.pending) > 0 {
		req := s.pending[0]
		record := s.records[req.ID]
		if cycles(now) < record.ReadyCycle {
			s.TickNow(sim.VTimeInSec(record.ReadyCycle) * 1e-9)
			break
		}
		req.SendTime = now
		if s.port.Send(req) != nil {
			record.SendFailures++
			break
		}
		record.SourceAccepted = cycles(now)
		s.pending = s.pending[1:]
		progress = true
	}
	return progress
}

type hookFunc func(sim.HookCtx)

func (f hookFunc) Func(ctx sim.HookCtx) { f(ctx) }

type provider struct {
	shared        *mmu.MMU
	queries, free int
}

func (p *provider) HasFreePTW() bool {
	p.queries++
	free := p.shared.HasFreePTW()
	if free {
		p.free++
	}
	return free
}
func (p *provider) PTWInflight() int { return p.shared.PTWInflight() }
func (p *provider) PTWCapacity() int { return p.shared.PTWCapacity() }

type observer struct {
	engine       sim.Engine
	shared       *mmu.MMU
	result       *Result
	records      map[string]*RequestResult
	active       map[string]mmu.WalkObservation
	outstanding  map[string]bool
	readySampled bool
}

func (o *observer) port(kind string) sim.Hook {
	return hookFunc(func(ctx sim.HookCtx) {
		msg, ok := ctx.Item.(*vm.TranslationReq)
		if !ok {
			return
		}
		r := o.records[msg.TaskID]
		if r == nil {
			panic("R7 downstream request lost its logical identity")
		}
		if kind == "issue" && ctx.Pos == sim.HookPosPortMsgSend {
			if r.L2Issued >= 0 {
				panic("duplicate R7 downstream issue")
			}
			r.L2Issued, r.IssuePath = cycles(o.engine.CurrentTime()), msg.TracePath
			r.PTWInflightAtIssue = o.shared.PTWInflight()
			if msg.TracePath == "assist" {
				o.outstanding[r.ID] = true
				if r.L2Issued < 400 {
					o.result.AssistIssuesBeforeNativeReady++
				}
				if len(o.outstanding) > o.result.PeakOutstandingAssists {
					o.result.PeakOutstandingAssists = len(o.outstanding)
				}
			}
		}
		if kind == "shared" && ctx.Pos == sim.HookPosPortMsgRecvd {
			if r.SharedArrived >= 0 {
				panic("duplicate R7 shared MMU arrival")
			}
			r.SharedArrived = cycles(o.engine.CurrentTime())
		}
	})
}

func (o *observer) Func(ctx sim.HookCtx) {
	if ctx.Pos != sim.HookPosAfterEvent {
		return
	}
	event := ctx.Item.(sim.Event)
	if cycles(event.Time()) > 100000 {
		panic("R7 controlled flow exceeded its completion deadline")
	}
	if !o.readySampled && cycles(event.Time()) >= 400 {
		for _, active := range o.active {
			if o.records[active.TaskID].Class == "assist-candidate" {
				o.result.AssistedWalksAtNativeReady++
			}
		}
		o.readySampled = true
	}
	for id := range o.outstanding {
		if o.records[id].Returned >= 0 {
			delete(o.outstanding, id)
		}
	}
	named, ok := event.Handler().(sim.Named)
	if !ok || named.Name() != o.shared.Name() {
		return
	}
	walks, queued, backlog := o.shared.ObserveWalks()
	current := make(map[string]mmu.WalkObservation)
	state := Occupancy{Cycle: cycles(event.Time()), Active: len(walks), Queued: queued, Backlog: backlog}
	for _, walk := range walks {
		current[walk.RequestID] = walk
		r := o.records[walk.TaskID]
		if r == nil {
			panic("R7 active walk lacks request identity")
		}
		if _, existed := o.active[walk.RequestID]; !existed {
			if r.WalkStarted >= 0 {
				panic("R7 request started multiple shared walks")
			}
			r.WalkStarted = state.Cycle
		}
		if r.Class == "native" {
			state.ActiveNative++
		} else {
			state.ActiveAssist++
		}
	}
	for id, old := range o.active {
		if _, exists := current[id]; !exists {
			o.records[old.TaskID].WalkEnded = state.Cycle
		}
	}
	o.active = current
	if state.Active > 16 {
		panic("R7 walker capacity exceeded")
	}
	o.result.PeakPTW = max(o.result.PeakPTW, state.Active)
	o.result.PeakPWQueue = max(o.result.PeakPWQueue, queued)
	o.result.PeakBacklog = max(o.result.PeakBacklog, backlog)
	previous := Occupancy{}
	if len(o.result.Occupancy) > 0 {
		previous = o.result.Occupancy[len(o.result.Occupancy)-1]
	}
	previous.Cycle = state.Cycle
	if len(o.result.Occupancy) == 0 || previous != state {
		o.result.Occupancy = append(o.result.Occupancy, state)
	}
}

func direct(engine sim.Engine, name string, a, b sim.Port, aCapacity, bCapacity int) {
	c := sim.NewDirectConnection(name, engine, sim.GHz)
	c.PlugIn(a, aCapacity)
	c.PlugIn(b, bCapacity)
}

// Run uses full-size translation resources with synthetic open-loop requests.
// observed=false is only the paired noninterference control for test coverage.
func Run(scenario string, assist, observed bool) (Result, error) {
	return run(scenario, assist, observed, false)
}

// RunMonitored executes the formal controlled flow with AkitaRTM enabled.
func RunMonitored(scenario string, assist, observed bool) (Result, error) {
	return run(scenario, assist, observed, true)
}

func run(scenario string, assist, observed, monitored bool) (Result, error) {
	translationtrace.Configure(false, "", 100000)
	plan, err := Plan(scenario)
	if err != nil {
		return Result{}, err
	}
	result := Result{Scenario: scenario, Assist: assist, Observed: observed,
		Model: "v8 translation/network logic; fixed 500-cycle walk service; R7 controlled flow",
		Config: map[string]int{"gpms": 48, "mesh_x": 7, "mesh_y": 7, "central_x": 3, "central_y": 3,
			"local_walkers_per_gpm": 4, "shared_walkers": 16, "walk_service_cycles": 500,
			"l2_sets": 16, "l2_ways": 16, "l2_mshrs": 16, "lookup_slots": 8, "pte_cycles": 32,
			"iotlb_sets": 64, "iotlb_ways": 32, "iotlb_mshrs": 64, "iotlb_lookup_cycles": 80,
			"switch_latency": 32, "flits_per_cycle": 48, "flit_bytes": 16,
			"source_connection_capacity": 16, "l2_reply_connection_capacity": 64,
			"native_ready_cycle": 400, "native_requests": 64, "coalescing_low": 4, "coalescing_high": 16,
			"initial_ptcl_mode": 0, "mmu_walk_coalescing": 0},
		Limits: []string{"Controlled open-loop translation flow, not a GPU workload or hardware calibration.",
			"Assist uses current active-walker count without reserving pending network/queue requests; no advertisement protocol.",
			"Exact translation/control wire bytes are unmodeled; TrafficBytes=0 still consumes one modeled flit.",
			"Endpoint unsent-flit storage and MMU mockBuffer remain unbounded in the inherited model.",
			"500-cycle service is an explicit equal-service control, not the default variable shared-walker timing.",
			"Input represents L1 miss requests; CU execution, data traffic, and L1 cache activity are not replayed."}}
	engine := sim.NewSerialEngine()
	pt := vm.NewPageTable(12)
	records := make(map[string]*RequestResult)
	for _, spec := range plan {
		for bit := uint64(0); bit < 8; bit++ {
			addr := spec.VAddr + bit*4096
			pt.Insert(vm.Page{PID: spec.PID, VAddr: addr, PAddr: addr + 0x100000000,
				PageSize: 4096, Valid: true, DeviceID: spec.Owner})
		}
		records[spec.ID] = &RequestResult{RequestSpec: spec, SourceAccepted: -1, Returned: -1,
			L2Issued: -1, SharedArrived: -1, WalkStarted: -1, WalkEnded: -1, PTWInflightAtIssue: -1}
	}
	shared := mmu.MakeBuilder().WithEngine(engine).WithPageTable(pt).WithLog2PageSize(12).
		WithMaxNumReqInFlight(16).WithFixedWalkLatency(500).WithPageWalkingLatency(500).
		WithWalkCoalescing(false).WithDemandPTEOnly(false).Build("R7.SharedMMU")
	upper := mmuCache.MakeBuilder().WithEngine(engine).WithNumWays(1).WithNumSets(32).
		WithNumMSHREntry(64).WithMSHREntryDepth(64).WithNumReqPerCycle(256).
		WithLog2PageSize(12).WithLowModule(shared.GetPortByName("Top")).Build("R7.Upper")
	iotlb := mmuTLB.MakeBuilder().WithEngine(engine).WithNumSets(64).WithNumWays(32).
		WithNumMSHREntry(64).WithMSHREntryDepth(64).WithNumReqPerCycle(32).
		WithPageSize(4096).WithLog2PageSize(12).WithPageTable(pt).WithSetAsLineTLB(true).
		WithLookupLatencyCycles(80).WithLowModule(upper.GetPortByName("Top")).Build("R7.IOTLB")
	upper.UpModule = iotlb.GetPortByName("Bottom")
	shared.TopModule = upper.GetPortByName("Bottom")
	direct(engine, "R7.IOTLBToUpper", iotlb.GetPortByName("Bottom"), upper.GetPortByName("Top"), 6400, 6400)
	direct(engine, "R7.UpperToMMU", upper.GetPortByName("Bottom"), shared.GetPortByName("Top"), 6400, 6400)
	state := &provider{shared: shared}
	obs := &observer{engine: engine, shared: shared, result: &result, records: records,
		active: make(map[string]mmu.WalkObservation), outstanding: make(map[string]bool)}
	if observed {
		engine.AcceptHook(obs)
		shared.GetPortByName("Top").AcceptHook(obs.port("shared"))
	}
	var netStats *trafficstats.Tracer
	connector := mesh.NewConnector().WithEngine(engine).WithFreq(sim.GHz).
		WithFlitSize(16).WithBandwidth(48).WithSwitchLatency(32)
	if observed {
		netStats = trafficstats.New(engine, func(msg sim.Msg) string {
			switch m := msg.(type) {
			case *vm.TranslationReq:
				return "request." + m.TracePath
			case *vm.TranslationRsp:
				if r := records[m.TaskID]; r != nil {
					return "response." + r.Class
				}
			}
			return "other"
		}, nil)
		connector = connector.WithVisTracer(netStats)
	}
	connector.CreateNetwork("R7.Mesh")
	connector.AddTile([3]int{6, 6, 0}, nil)
	connector.AddTile([3]int{3, 3, 0}, []sim.Port{iotlb.GetPortByName("Top")})
	var sources []*source
	var l2s []*tlb_gmmu.GMMUTLB
	id := 0
	for y := 0; y < 7; y++ {
		for x := 0; x < 7; x++ {
			if x == 3 && y == 3 {
				continue
			}
			id++
			name := fmt.Sprintf("R7.GPM%02d", id)
			local := gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(uint64(id)).WithPageTable(pt).
				WithMaxNumReqInFlight(4).WithPageWalkingLatency(500).WithLog2PageSize(12).
				WithLowModule(shared.GetPortByName("Top")).WithIsPrediction(true).Build(name + ".GMMU")
			l2 := tlb_gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(uint64(id)).WithPageTable(pt).
				WithLog2PageSize(12).WithPageSize(4096).WithNumSets(16).WithNumWays(16).
				WithNumMSHREntry(16).WithNumReqPerCycle(128).WithPTELookupSlots(8).
				WithPTELookupLatencyCycles(32).WithPTCLLineSize(8).WithFlexTLB(true).
				WithPTCLModeThresholds(4, 16).WithInitialPTCLMode(false).WithFlexPromotionThreshold(3).
				WithLowModule(local.GetPortByName("Top")).WithIOMMUPort(iotlb.GetPortByName("Top")).
				WithIdleIOMMUAssist(assist).WithSharedPTWStateProvider(state).Build(name + ".L2")
			if observed {
				l2.OutsidePort.AcceptHook(obs.port("issue"))
				l2.GetPortByName("Bottom").AcceptHook(obs.port("issue"))
			}
			direct(engine, name+".L2ToGMMU", l2.GetPortByName("Bottom"), local.GetPortByName("Top"), 640, 640)
			connector.AddTile([3]int{x, y, 0}, []sim.Port{l2.OutsidePort})
			s := &source{target: l2.GetPortByName("Top"), records: records, pageTable: pt}
			s.TickingComponent = sim.NewTickingComponent(name+".Source", engine, sim.GHz, s)
			s.port = sim.NewLimitNumMsgPort(s, 16, name+".Source.Port")
			s.AddPort("Port", s.port)
			direct(engine, name+".SourceToL2", s.port, s.target, 16, 64)
			for _, spec := range plan {
				if spec.GPM != id {
					continue
				}
				r := vm.TranslationReqBuilder{}.WithPID(spec.PID).WithVAddr(spec.VAddr).
					WithSrc(s.port).WithDst(s.target).WithTaskID(spec.ID).WithOriginPort(s.port).
					WithDeviceID(uint64(id)).Build()
				r.ID, r.StartGPUID = spec.ID, id
				s.pending = append(s.pending, r)
			}
			sources, l2s = append(sources, s), append(l2s, l2)
		}
	}
	connector.EstablishNetwork()
	for _, s := range sources {
		if len(s.pending) > 0 {
			s.TickNow(sim.VTimeInSec(records[s.pending[0].ID].ReadyCycle) * 1e-9)
		}
	}
	if monitored {
		monitor := monitoring.NewMonitor()
		monitor.RegisterEngine(engine)
		monitor.StartServer()
	}
	if err := engine.Run(); err != nil {
		return Result{}, err
	}
	var native []float64
	for _, spec := range plan {
		r := *records[spec.ID]
		if r.Returned < r.ReadyCycle || r.SourceAccepted < r.ReadyCycle {
			return Result{}, fmt.Errorf("request did not complete: %+v", r)
		}
		if observed && (r.L2Issued < r.SourceAccepted ||
			(r.IssuePath != "" && (r.WalkStarted < r.SharedArrived || r.WalkEnded-r.WalkStarted != 500))) {
			return Result{}, fmt.Errorf("inconsistent request path/stage timing: %+v", r)
		}
		if r.Class == "native" {
			native = append(native, float64(r.Returned-r.ReadyCycle))
			result.NativeSendFailures += r.SendFailures
		}
		result.Requests = append(result.Requests, r)
	}
	for _, l2 := range l2s {
		if l2.MSHRAdmissionStats()["mshr_entries_at_stop"] != 0 {
			return Result{}, fmt.Errorf("L2 MSHR leaked: %s", l2.Name())
		}
	}
	if shared.PTWInflight() != 0 {
		return Result{}, fmt.Errorf("shared walk leaked")
	}
	if observed {
		result.Network = netStats.Snapshot()
	}
	result.AssistQueries, result.FreeAssistQueries = state.queries, state.free
	result.NativeLatency = summarize(native)
	return result, nil
}

func summarize(values []float64) Summary {
	sort.Float64s(values)
	r := Summary{Count: len(values)}
	if len(values) == 0 {
		return r
	}
	for _, value := range values {
		r.Mean += value
	}
	r.Mean /= float64(len(values))
	quantile := func(q float64) float64 { return values[int(math.Ceil(q*float64(len(values))))-1] }
	r.P50, r.P95, r.P99, r.Max = quantile(.5), quantile(.95), quantile(.99), values[len(values)-1]
	return r
}

// SameFunctionalOutcome checks observation noninterference, not Assist ON/OFF.
func SameFunctionalOutcome(a, b Result) bool {
	if len(a.Requests) != len(b.Requests) || a.NativeLatency != b.NativeLatency {
		return false
	}
	for i, x := range a.Requests {
		y := b.Requests[i]
		if !reflect.DeepEqual(x.RequestSpec, y.RequestSpec) || x.SourceAccepted != y.SourceAccepted ||
			x.Returned != y.Returned || x.SendFailures != y.SendFailures {
			return false
		}
	}
	return true
}
