package assiststudy

import (
	"fmt"
	"reflect"
	"testing"
)

func TestPlanHasFixedIdentityReadinessAndDistinctPTCLs(t *testing.T) {
	for _, scenario := range []string{"native-burst", "capacity-race"} {
		a, err := Plan(scenario)
		if err != nil {
			t.Fatal(err)
		}
		b, _ := Plan(scenario)
		if !reflect.DeepEqual(a, b) {
			t.Fatal("request plan is not deterministic")
		}
		seen := make(map[uint64]bool)
		native, assist := 0, 0
		for _, request := range a {
			if seen[request.VAddr/32768] {
				t.Fatal("independent flow requests share a PTCL")
			}
			seen[request.VAddr/32768] = true
			if request.Class == "native" {
				native++
				if request.ReadyCycle != 400 || request.GPM != nativeGPM || request.Owner == uint64(request.GPM) {
					t.Fatal("native readiness or remote ownership changed")
				}
			} else {
				assist++
				if request.ReadyCycle != 0 || request.Owner != uint64(request.GPM) {
					t.Fatal("assist candidate is not an initially ready local page")
				}
			}
		}
		if native != 64 || (scenario == "native-burst" && assist != 16) || (scenario == "capacity-race" && assist != 94) {
			t.Fatal("scenario population changed")
		}
	}
	if _, err := Plan("extra-sweep"); err == nil {
		t.Fatal("unknown experiment admitted")
	}
}

func TestR7ScenarioCompletionAndObserverNoninterference(t *testing.T) {
	for _, scenario := range []string{"native-burst", "capacity-race"} {
		for _, assist := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/assist-%v", scenario, assist), func(t *testing.T) {
				bare, err := Run(scenario, assist, false)
				if err != nil {
					t.Fatal(err)
				}
				observed, err := Run(scenario, assist, true)
				if err != nil {
					t.Fatal(err)
				}
				if !SameFunctionalOutcome(bare, observed) {
					for i := range bare.Requests {
						if bare.Requests[i].Returned != observed.Requests[i].Returned {
							t.Logf("timing mismatch: %+v / %+v", bare.Requests[i], observed.Requests[i])
						}
					}
					t.Fatal("observation changed request delivery, readiness, or backpressure")
				}
				if observed.NativeLatency.Count != 64 || observed.PeakPTW > 16 || observed.NativeSendFailures == 0 {
					t.Fatal("wrong population/capacity or source backpressure not exercised")
				}
				for key, counter := range observed.Network {
					if counter.Started != counter.Completed || counter.Inflight != 0 || counter.InvalidDurations != 0 {
						t.Fatalf("network did not drain: %s %+v", key, counter)
					}
				}
				if assist {
					if observed.AssistedWalksAtNativeReady == 0 || observed.AssistIssuesBeforeNativeReady == 0 {
						t.Fatal("native burst did not overlap assisted walk service")
					}
					if scenario == "capacity-race" && observed.AssistIssuesBeforeNativeReady <= 16 {
						t.Fatal("unreserved capacity race was not exercised")
					}
				} else if observed.AssistedWalksAtNativeReady != 0 || observed.AssistQueries != 0 {
					t.Fatal("disabled Assist still used the shared capacity provider")
				}
				t.Logf("scenario=%s assist=%v native=%+v issues=%d active_at_burst=%d peak_queue=%d failures=%d",
					scenario, assist, observed.NativeLatency, observed.AssistIssuesBeforeNativeReady,
					observed.AssistedWalksAtNativeReady, observed.PeakPWQueue, observed.NativeSendFailures)
			})
		}
	}
}
