package mmu

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

func TestFixedWalkServiceIndependentOfUpperCacheLatency(t *testing.T) {
	for _, upper := range []uint64{0, 32, 100, 400, 900} {
		m := MakeBuilder().WithFixedWalkLatency(500).Build("FixedWalk")
		req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(0x1000).Build()
		m.startWalking(req, upper, 0)
		if m.walkingTranslations[0].cycleLeft != 500 {
			t.Fatalf("upper latency %d changed fixed service", upper)
		}
		for cycle := 0; cycle < 500; cycle++ {
			m.walkPageTable(sim.VTimeInSec(cycle) * 1e-9)
		}
		if len(m.walkingTranslations) != 1 || m.walkingTranslations[0].cycleLeft != 0 {
			t.Fatal("fixed countdown completed early or did not reach zero")
		}
	}
}

func TestNativeWalkServiceRemainsCacheDependent(t *testing.T) {
	for _, upper := range []uint64{0, 32, 400} {
		m := MakeBuilder().WithPageWalkingLatency(500).Build("NativeWalk")
		m.startWalking(nil, upper, 0)
		if m.walkingTranslations[0].cycleLeft != int(upper+100) {
			t.Fatal("fixed-service control altered the native default")
		}
	}
}

func TestSharedWalkerControlRespectsExactCapacity(t *testing.T) {
	for _, capacity := range []int{16, 32} {
		m := MakeBuilder().WithEngine(sim.NewSerialEngine()).
			WithMaxNumReqInFlight(capacity).WithFixedWalkLatency(500).
			WithWalkCoalescing(false).Build("CapacityControl")
		for i := 0; i < capacity+1; i++ {
			req := vm.TranslationReqBuilder{}.WithPID(1).
				WithVAddr(uint64(i) * 4096).WithTransLatency(uint64(i) * 25).Build()
			m.PWqueue = append(m.PWqueue, PWqueue{req: req})
		}
		if !m.processTranslationReqs(0) || m.PTWInflight() != capacity || m.HasFreePTW() || len(m.PWqueue) != 1 {
			t.Fatalf("capacity=%d was not enforced exactly", capacity)
		}
		if m.processTranslationReqs(0) || m.PTWCapacity() != capacity {
			t.Fatal("a full walker complex accepted an extra request")
		}
		for _, walk := range m.walkingTranslations {
			if walk.cycleLeft != 500 {
				t.Fatal("capacity change changed per-walk service")
			}
		}
		m.walkingTranslations = m.walkingTranslations[1:]
		if !m.HasFreePTW() || !m.processTranslationReqs(1) || m.PTWInflight() != capacity || len(m.PWqueue) != 0 {
			t.Fatal("queued request did not enter the released walker")
		}
	}
}
