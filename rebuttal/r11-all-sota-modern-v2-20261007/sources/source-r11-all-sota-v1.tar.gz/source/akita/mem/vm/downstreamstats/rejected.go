package downstreamstats

import (
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

const InvalidResponseSampleLimit = 8

// RejectedResponse copies bounded diagnostic evidence without retaining a
// mutable message or changing the validation decision.
type RejectedResponse struct {
	Reason, Stage, Path, ResponseID, RespondTo string
	Time, IssuedAt                             sim.VTimeInSec
	Port, Source, Destination                  string
	ExpectedSource, ExpectedDestination        string
	ExpectedPID                                vm.PID
	ExpectedBase                               uint64
	ExpectedBitmap                             uint8
	Page                                       vm.Page
}

func portName(port sim.Port) string {
	if port == nil {
		return ""
	}
	return port.Name()
}

func (o *Observer) responseRejection(t *transaction, rsp *vm.TranslationRsp, port sim.Port) string {
	p := rsp.Page
	switch {
	case rsp.Src == nil || rsp.Dst == nil || portName(rsp.Src) != t.destination ||
		portName(rsp.Dst) != t.source || portName(port) != t.source:
		return "route"
	case !p.Valid:
		return "nonpresent_page"
	case p.PID != t.pid:
		return "pid"
	case p.VAddr&((uint64(1)<<o.pageShift)-1) != 0:
		return "unaligned_page"
	case p.VAddr < t.base || (p.VAddr-t.base)>>o.pageShift >= 8:
		return "neighborhood"
	default:
		return ""
	}
}

func (o *Observer) rejectResponse(now sim.VTimeInSec, t *transaction, rsp *vm.TranslationRsp,
	port sim.Port, consume bool, reason string) {
	o.diagnostics.InvalidResponse++
	o.rejectedCounts[reason]++
	if len(o.rejectedSamples) == InvalidResponseSampleLimit {
		return
	}
	stage := "received"
	if consume {
		stage = "consumed"
	}
	o.rejectedSamples = append(o.rejectedSamples, RejectedResponse{
		Reason: reason, Stage: stage, Path: t.path, ResponseID: rsp.ID, RespondTo: rsp.RespondTo,
		Time: now, IssuedAt: t.start, Port: portName(port), Source: portName(rsp.Src), Destination: portName(rsp.Dst),
		ExpectedSource: t.destination, ExpectedDestination: t.source, ExpectedPID: t.pid,
		ExpectedBase: t.base, ExpectedBitmap: t.expected, Page: rsp.Page,
	})
}
