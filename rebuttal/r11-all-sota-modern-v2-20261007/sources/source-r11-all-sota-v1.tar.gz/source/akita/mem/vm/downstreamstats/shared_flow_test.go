package downstreamstats_test

import (
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/downstreamstats"
	"github.com/sarchlab/akita/v3/mem/vm/mmu"
	"github.com/sarchlab/akita/v3/mem/vm/mmuCache"
	"github.com/sarchlab/akita/v3/mem/vm/mmuTLB"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

// An IOTLB MSHR may mix paths. The observer must preserve both incoming
// transaction identities without inheriting the shared walk's representative.
// Set-as-line IOTLB mode expands each single-page request into eight physical
// responses; only the original requested bit ends the demand transaction.
func TestActualIOTLBMixedPathsRetainSeparateTransactions(t *testing.T) {
	var outcomes [2][2]localOutcome
	for observed := 0; observed < 2; observed++ {
		translationtrace.Configure(false, "", 100)
		engine := sim.NewSerialEngine()
		pt := vm.NewPageTable(12)
		for bit := uint64(0); bit < 8; bit++ {
			pt.Insert(vm.Page{Valid: true, PID: 1, VAddr: bit * 4096, PAddr: 0x100000 + bit*4096, PageSize: 4096, DeviceID: 1})
		}
		shared := mmu.MakeBuilder().WithEngine(engine).WithPageTable(pt).WithLog2PageSize(12).
			WithMaxNumReqInFlight(16).WithFixedWalkLatency(500).WithPageWalkingLatency(500).
			WithWalkCoalescing(false).WithDemandPTEOnly(false).Build("SharedFlow.MMU")
		upper := mmuCache.MakeBuilder().WithEngine(engine).WithNumWays(1).WithNumSets(32).
			WithNumMSHREntry(64).WithMSHREntryDepth(64).WithNumReqPerCycle(256).
			WithLog2PageSize(12).WithLowModule(shared.GetPortByName("Top")).Build("SharedFlow.Upper")
		iotlb := mmuTLB.MakeBuilder().WithEngine(engine).WithNumSets(64).WithNumWays(32).
			WithNumMSHREntry(64).WithMSHREntryDepth(64).WithNumReqPerCycle(32).
			WithPageSize(4096).WithLog2PageSize(12).WithPageTable(pt).WithSetAsLineTLB(true).
			WithLookupLatencyCycles(80).WithLowModule(upper.GetPortByName("Top")).Build("SharedFlow.IOTLB")
		upper.UpModule, shared.TopModule = iotlb.GetPortByName("Bottom"), upper.GetPortByName("Bottom")
		connect := func(name string, a, b sim.Port) {
			c := sim.NewDirectConnection(name, engine, sim.GHz)
			c.PlugIn(a, 6400)
			c.PlugIn(b, 6400)
		}
		connect("SharedFlow.UpperLink", iotlb.GetPortByName("Bottom"), upper.GetPortByName("Top"))
		connect("SharedFlow.WalkLink", upper.GetPortByName("Bottom"), shared.GetPortByName("Top"))
		ports := [2]sim.Port{sim.NewLimitNumMsgPort(nil, 16, "SharedFlow.Native"), sim.NewLimitNumMsgPort(nil, 16, "SharedFlow.Assist")}
		connection := sim.NewDirectConnection("SharedFlow.Sources", engine, sim.GHz)
		connection.PlugIn(iotlb.GetPortByName("Top"), 6400)
		stats := downstreamstats.New(engine, 12, sim.GHz)
		var requests [2]*vm.TranslationReq
		for i, path := range []string{"native", "assist"} {
			connection.PlugIn(ports[i], 16)
			if observed == 1 {
				ports[i].AcceptHook(stats.Hook(ports[i], false))
			}
			requests[i] = vm.TranslationReqBuilder{}.WithSrc(ports[i]).WithDst(iotlb.GetPortByName("Top")).
				WithPID(1).WithVAddr(0).WithBitMap([8]bool{true}).WithOriginPort(ports[i]).WithTaskID(path).Build()
			requests[i].TracePath = path
			if ports[i].Send(requests[i]) != nil {
				t.Fatal("initial send rejected")
			}
		}
		if err := engine.Run(); err != nil {
			t.Fatal(err)
		}
		if iotlb.IncomingRequestCount() != 2 || iotlb.DownstreamRequestCount() != 1 {
			t.Fatal("requests did not share IOTLB work")
		}
		for i, port := range ports {
			outcomes[observed][i].Drained = engine.CurrentTime()
			for msg := port.Retrieve(engine.CurrentTime()); msg != nil; msg = port.Retrieve(engine.CurrentTime()) {
				rsp := msg.(*vm.TranslationRsp)
				if rsp.RespondTo != requests[i].ID {
					t.Fatal("IOTLB response lost original downstream identity")
				}
				outcomes[observed][i].Page, outcomes[observed][i].Returned = rsp.Page, rsp.RecvTime
				outcomes[observed][i].Responses++
			}
			if outcomes[observed][i].Responses != 8 {
				t.Fatal("incorrect physical response count")
			}
		}
		if observed == 1 {
			s := stats.Snapshot()
			for _, path := range []string{"native", "assist"} {
				if c := s.Paths[path]; c.Started != 1 || c.Completed != 1 || c.Inflight != 0 {
					t.Fatalf("mixed-path population: %+v", s)
				}
			}
			if s.Diagnostics.InvalidResponse != 0 || s.Diagnostics.InvalidTime != 0 ||
				s.Diagnostics.DuplicateIssue != 0 || s.Diagnostics.UnknownPath != 0 ||
				s.Ports["outside"].Consumed != 16 {
				t.Fatalf("shared flow observation error: %+v", s)
			}
		}
	}
	if !reflect.DeepEqual(outcomes[0], outcomes[1]) {
		t.Fatal("observer changed shared IOTLB/MMU return/drain times")
	}
}
