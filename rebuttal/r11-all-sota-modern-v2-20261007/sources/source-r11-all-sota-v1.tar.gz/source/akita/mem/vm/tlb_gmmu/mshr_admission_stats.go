package tlb_gmmu

// MSHRAdmissionStats reports entry occupancy independently of a finite denominator.
func (tlb *GMMUTLB) MSHRAdmissionStats() map[string]float64 {
	m, ok := tlb.mshr.(*mshrImpl)
	if !ok {
		return nil
	}
	unbounded := 0.0
	if m.capacity == 0 {
		unbounded = 1
	}
	return map[string]float64{
		"mshr_entry_capacity":           float64(m.capacity),
		"mshr_entry_capacity_unbounded": unbounded,
		"mshr_entries_peak":             float64(m.peakEntries),
		"mshr_entries_at_stop":          float64(len(m.entries)),
	}
}
