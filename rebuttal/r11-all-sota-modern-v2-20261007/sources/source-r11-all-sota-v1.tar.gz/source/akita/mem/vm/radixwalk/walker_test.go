package radixwalk

import (
	"errors"
	"fmt"
	"reflect"
	"testing"
)

type testMemory struct {
	levels int
	next   uint64
	pages  map[uint64]*[512]uint64
}

func memory(levels int) *testMemory {
	return &testMemory{levels: levels, next: 0x100000, pages: make(map[uint64]*[512]uint64)}
}
func (m *testMemory) mapPage(root, va, pa uint64) {
	if m.pages[root] == nil {
		m.pages[root] = new([512]uint64)
	}
	node := root
	for level := m.levels; level >= 1; level-- {
		index := (va >> uint(12+9*(level-1))) & 511
		if level == 1 {
			m.pages[node][index] = pa | 7
			return
		}
		if m.pages[node][index]&1 == 0 {
			m.next += 4096
			m.pages[m.next] = new([512]uint64)
			m.pages[node][index] = m.next | 7
		}
		node = m.pages[node][index] & addressMask
	}
}
func (m *testMemory) response(a MemoryAccess) Response {
	r := Response{Token: a.Token, LineAddress: a.LineAddress}
	p := m.pages[a.NodeAddress]
	if p == nil {
		r.MemoryError = true
		return r
	}
	word := (a.LineAddress - a.NodeAddress) / 8
	copy(r.Entries[:], p[word:word+8])
	return r
}
func (m *testMemory) pte(root, va uint64, level int) *uint64 {
	node := root
	for l := m.levels; l > level; l-- {
		node = m.pages[node][(va>>uint(12+9*(l-1)))&511] & addressMask
	}
	return &m.pages[node][(va>>uint(12+9*(level-1)))&511]
}
func fullConfig() Config {
	return Config{Levels: 4, Walkers: 2, BufferEntries: 8, LeafCoalescing: true, UpperCoalescing: true, AwareScheduling: true}
}
func newWalker(t *testing.T, c Config) *Walker {
	t.Helper()
	w, err := New(c)
	if err != nil {
		t.Fatal(err)
	}
	return w
}
func request(id string, va uint64) Request {
	return Request{ID: id, PID: 1, Root: 0x1000, VAddr: va, User: true}
}
func ok(t *testing.T, err error) {
	t.Helper()
	if err != nil {
		t.Fatal(err)
	}
}
func onlyAccess(t *testing.T, w *Walker) MemoryAccess {
	t.Helper()
	a := w.Accesses()
	if len(a) != 1 {
		t.Fatalf("want one access, got %+v", a)
	}
	return a[0]
}
func enqueue(t *testing.T, w *Walker, reqs ...Request) {
	t.Helper()
	for _, r := range reqs {
		ok(t, w.Enqueue(0, r))
	}
}

type timedResponse struct {
	due      uint64
	response Response
}
type runResult struct {
	completions map[string]Completion
	accesses    []MemoryAccess
	stats       Stats
	cycles      uint64
}

func run(t *testing.T, c Config, reqs []Request, m *testMemory) runResult {
	t.Helper()
	w := newWalker(t, c)
	enqueue(t, w, reqs...)
	result := runResult{completions: make(map[string]Completion)}
	var inflight []timedResponse
	for now := uint64(0); now < 10000; now++ {
		pending := inflight[:0]
		for _, event := range inflight {
			if event.due == now {
				ok(t, w.Return(now, event.response))
			} else {
				pending = append(pending, event)
			}
		}
		inflight = pending
		if completion, ready := w.PeekCompletion(); ready {
			if _, duplicate := result.completions[completion.Request.ID]; duplicate {
				t.Fatal("duplicate completion")
			}
			result.completions[completion.Request.ID] = completion
			ok(t, w.ConsumeCompletion(now, completion.Request.ID))
		}
		ok(t, w.Schedule(now))
		// One accepted cacheline per cycle models shared backend bandwidth.
		if accesses := w.Accesses(); len(accesses) > 0 {
			a := accesses[0]
			ok(t, w.CommitAccess(now, a.Token))
			inflight = append(inflight, timedResponse{now + uint64(5+a.Level*3), m.response(a)})
			result.accesses = append(result.accesses, a)
		}
		if len(result.completions) == len(reqs) {
			if len(w.Buffered()) != 0 || len(inflight) != 0 {
				t.Fatal("completion did not drain buffer/backend")
			}
			for _, a := range w.Active() {
				if a.Valid {
					t.Fatal("walker slot leaked")
				}
			}
			result.stats = w.Snapshot()
			result.cycles = now
			return result
		}
	}
	t.Fatal("controlled walker sequence did not finish")
	return result
}

func TestThreeRequestRadixTreeAndBaselineUseTheSamePTEs(t *testing.T) {
	va0 := uint64(0xf5)<<39 | uint64(0xa3)<<30 | uint64(0x29)<<21 | uint64(0x89)<<12
	va1 := va0 + 4096
	va2 := uint64(0xf5)<<39 | uint64(0xa3)<<30 | uint64(0x2a)<<21 | uint64(0xb)<<12
	reqs := []Request{request("a", va0), request("b", va1), request("c", va2)}
	m := memory(4)
	for i, r := range reqs {
		m.mapPage(r.Root, r.VAddr, 0xa00000+uint64(i)*4096)
	}
	base := fullConfig()
	base.LeafCoalescing = false
	base.UpperCoalescing = false
	base.AwareScheduling = false
	b, n := run(t, base, reqs, m), run(t, fullConfig(), reqs, m)
	if len(b.accesses) != 12 || len(n.accesses) != 5 || n.stats.MemoryAccesses != ([6]uint64{0, 2, 1, 1, 1}) ||
		n.stats.Started != 2 || n.stats.LeafCoalesced != 1 || n.stats.PartialEvents[2] != 2 {
		t.Fatalf("wrong work saved: B=%+v N=%+v", b.stats, n.stats)
	}
	for i, r := range reqs {
		x, y := b.completions[r.ID], n.completions[r.ID]
		if x.Fault != NoFault || y.Fault != NoFault || x.PAddr != y.PAddr || x.PAddr != 0xa00000+uint64(i)*4096 {
			t.Fatal("sibling PTE or physical path was not used")
		}
	}
	t.Logf("RADIX_EVIDENCE baseline_accesses=%d neighbor_accesses=%d baseline_cycles=%d neighbor_cycles=%d neighbor_started=%d leaf_followers=%d",
		len(b.accesses), len(n.accesses), b.cycles, n.cycles, n.stats.Started, n.stats.LeafCoalesced)
}

func TestNoPartialProgressUntilCommittedCachelineReturns(t *testing.T) {
	w := newWalker(t, fullConfig())
	enqueue(t, w, request("a", 0), request("b", 4096))
	ok(t, w.Schedule(0))
	a := onlyAccess(t, w)
	if len(w.Buffered()) != 1 || w.Buffered()[0].HasPartialAddr || !w.Buffered()[0].Coalescible {
		t.Fatal("admission-time upper coalescing")
	}
	before := w.Snapshot()
	if w.Return(1, Response{Token: a.Token, LineAddress: a.LineAddress}) == nil {
		t.Fatal("unissued return accepted")
	}
	if !reflect.DeepEqual(before, w.Snapshot()) {
		t.Fatal("bad response changed counters")
	}
	for now := uint64(1); now < 5; now++ {
		ok(t, w.Schedule(now))
		if onlyAccess(t, w).Token != a.Token {
			t.Fatal("retry allocated another access")
		}
	}
	if w.Snapshot().MemoryAccesses[4] != 0 || w.Buffered()[0].HasPartialAddr {
		t.Fatal("unaccepted memory access advanced state")
	}
	ok(t, w.CommitAccess(5, a.Token))
	if w.CommitAccess(5, a.Token) == nil {
		t.Fatal("duplicate issue accepted")
	}
	bad := Response{Token: a.Token, LineAddress: a.LineAddress + 64}
	if w.Return(6, bad) == nil {
		t.Fatal("wrong cacheline accepted")
	}
	rsp := Response{Token: a.Token, LineAddress: a.LineAddress, Entries: [8]uint64{0: 0x2000 | 7}}
	ok(t, w.Return(7, rsp))
	b := w.Buffered()[0]
	if !b.HasPartialAddr || b.PartialLevel != 4 || b.NextPTAddr != 0x2000 || w.Snapshot().PartialEvents[4] != 1 {
		t.Fatalf("missing returned upper PTE: %+v", b)
	}
	if w.Return(7, rsp) == nil {
		t.Fatal("stale access token advanced the next level")
	}
	b.NextPTAddr = 0x9000
	if w.Buffered()[0].NextPTAddr != 0x2000 {
		t.Fatal("snapshot exposed live state")
	}
}

func TestContextIsolationAndLeafCachelineBoundary(t *testing.T) {
	for _, context := range []string{"pid", "root", "generation"} {
		t.Run(context, func(t *testing.T) {
			a, b := request("a", 0), request("b", 4096)
			switch context {
			case "pid":
				b.PID++
			case "root":
				b.Root = 0x9000
			case "generation":
				b.Generation++
			}
			m := memory(4)
			m.mapPage(a.Root, a.VAddr, 0xa00000)
			m.mapPage(b.Root, b.VAddr, 0xb00000)
			result := run(t, fullConfig(), []Request{a, b}, m)
			if len(result.accesses) != 8 || result.stats.LeafCoalesced != 0 {
				t.Fatal("address spaces/roots/generations merged")
			}
		})
	}
	m := memory(4)
	a, b := request("a", 7*4096), request("b", 8*4096)
	m.mapPage(a.Root, a.VAddr, 0xa00000)
	m.mapPage(b.Root, b.VAddr, 0xb00000)
	r := run(t, fullConfig(), []Request{a, b}, m)
	if r.stats.MemoryAccesses[1] != 2 || r.stats.LeafCoalesced != 0 {
		t.Fatal("cross-line leaf completion")
	}
}

func TestPartiallyAdvancedRequestNeverRegresses(t *testing.T) {
	c := fullConfig()
	c.AwareScheduling = false
	w := newWalker(t, c)
	enqueue(t, w, request("a", 0), request("b", 8*4096), request("pending", 4096))
	ok(t, w.Schedule(0))
	accesses := w.Accesses()
	if len(accesses) != 2 {
		t.Fatal("NoSched did not admit two walks")
	}
	m := memory(4)
	for _, va := range []uint64{0, 4096, 8 * 4096} {
		m.mapPage(0x1000, va, 0x900000+va)
	}
	for _, a := range accesses {
		ok(t, w.CommitAccess(0, a.Token))
	}
	ok(t, w.Return(1, m.response(accesses[0])))
	for now := uint64(2); now <= 3; now++ {
		a := onlyAccess(t, w)
		ok(t, w.CommitAccess(now-1, a.Token))
		ok(t, w.Return(now, m.response(a)))
	}
	before := w.Buffered()[0]
	if before.PartialLevel != 2 {
		t.Fatal("pending request did not reach leaf start")
	}
	ok(t, w.Return(4, m.response(accesses[1])))
	after := w.Buffered()[0]
	if after.PartialLevel != 2 || after.NextPTAddr != before.NextPTAddr {
		t.Fatal("late higher-level return regressed partial progress")
	}
}

func TestIssuedPeersAreNotCancelledOrRetroactivelyMerged(t *testing.T) {
	c := fullConfig()
	c.AwareScheduling = false
	reqs := []Request{request("a", 0), request("b", 4096), request("pending", 8192)}
	m := memory(4)
	for _, r := range reqs {
		m.mapPage(r.Root, r.VAddr, 0x900000+r.VAddr)
	}
	r := run(t, c, reqs, m)
	if r.stats.Started != 2 || len(r.accesses) != 8 || r.stats.LeafCoalesced != 1 {
		t.Fatalf("active requests were illegally eliminated: %+v", r.stats)
	}
}

func TestResponseBackpressureKeepsBoundedStorage(t *testing.T) {
	c := fullConfig()
	c.Walkers = 1
	c.BufferEntries = 1
	w := newWalker(t, c)
	m := memory(4)
	m.mapPage(0x1000, 0, 0x900000)
	m.mapPage(0x1000, 4096, 0x901000)
	enqueue(t, w, request("a", 0))
	ok(t, w.Schedule(0))
	ok(t, w.Enqueue(0, request("b", 4096)))
	for now := uint64(1); now <= 4; now++ {
		a := onlyAccess(t, w)
		ok(t, w.CommitAccess(now-1, a.Token))
		ok(t, w.Return(now, m.response(a)))
	}
	first, ready := w.PeekCompletion()
	if !ready || first.Request.ID != "a" {
		t.Fatal("leader not first completion")
	}
	if w.ConsumeCompletion(4, "b") == nil {
		t.Fatal("out-of-order sink consumed storage")
	}
	if !errors.Is(w.Enqueue(4, request("c", 8192)), ErrBufferFull) {
		t.Fatal("completed buffer freed before response acceptance")
	}
	ok(t, w.Schedule(10))
	if len(w.Accesses()) != 0 || !w.Active()[0].Completed {
		t.Fatal("walker slot freed under blocked response")
	}
	ok(t, w.ConsumeCompletion(10, "a"))
	ok(t, w.ConsumeCompletion(11, "b"))
	if _, ready := w.PeekCompletion(); ready || len(w.Buffered()) != 0 || w.Active()[0].Valid {
		t.Fatal("completed state leaked")
	}
	if w.Snapshot().CompletionWaitCycles != 13 {
		t.Fatal("response wait cycles wrong")
	}
}

func TestTimeoutAndLeafOnlyScheduling(t *testing.T) {
	c := fullConfig()
	c.MaxWaitCycles = 5
	w := newWalker(t, c)
	enqueue(t, w, request("a", 0), request("b", 4096))
	ok(t, w.Schedule(0))
	ok(t, w.Schedule(0))
	if len(w.Accesses()) != 1 || w.Snapshot().HeldWalkerTicks != 1 {
		t.Fatal("held slot double-counted or admitted early")
	}
	ok(t, w.Schedule(4))
	if len(w.Accesses()) != 1 {
		t.Fatal("guard fired early")
	}
	ok(t, w.Schedule(5))
	if len(w.Accesses()) != 2 || w.Snapshot().TimeoutStarts != 1 {
		t.Fatal("guard did not release held request")
	}
	c.UpperCoalescing = false
	c.MaxWaitCycles = 0
	w = newWalker(t, c)
	enqueue(t, w, request("a", 0), request("b", 4096))
	ok(t, w.Schedule(0))
	if len(w.Accesses()) != 2 || w.Snapshot().HeldWalkerTicks != 0 {
		t.Fatal("leaf-only variant waited for an upper-level opportunity")
	}
}

func TestPermissionAndNonpresentPTEsNeverBecomeSuccess(t *testing.T) {
	for _, scenario := range []string{"missing-leader-leaf", "missing-follower-leaf", "write-denied", "execute-denied", "user-denied", "large-page"} {
		t.Run(scenario, func(t *testing.T) {
			reqs := []Request{request("a", 0), request("b", 4096)}
			m := memory(4)
			m.mapPage(0x1000, 0, 0x900000)
			m.mapPage(0x1000, 4096, 0x901000)
			wantA, wantB := NoFault, NoFault
			switch scenario {
			case "missing-leader-leaf":
				*m.pte(0x1000, 0, 1) = 0
				wantA = NotPresent
			case "missing-follower-leaf":
				*m.pte(0x1000, 4096, 1) = 0
				wantB = NotPresent
			case "write-denied":
				reqs[1].Access = Write
				*m.pte(0x1000, 0, 4) &= ^uint64(2)
				wantB = PermissionFault
			case "execute-denied":
				reqs[1].Access = Execute
				*m.pte(0x1000, 0, 3) |= uint64(1) << 63
				wantB = PermissionFault
			case "user-denied":
				*m.pte(0x1000, 0, 2) &= ^uint64(4)
				wantA = PermissionFault
				wantB = PermissionFault
			case "large-page":
				*m.pte(0x1000, 0, 2) |= 128
				wantA = UnsupportedLargePage
				wantB = UnsupportedLargePage
			}
			r := run(t, fullConfig(), reqs, m)
			if r.completions["a"].Fault != wantA || r.completions["b"].Fault != wantB {
				t.Fatalf("incorrect faults: %+v", r.completions)
			}
			if wantB != NoFault && r.completions["b"].PAddr != 0 {
				t.Fatal("fault fabricated a mapping")
			}
		})
	}
}

func TestLateRequestInheritsAncestorPermissions(t *testing.T) {
	w := newWalker(t, fullConfig())
	leader := request("a", 0)
	late := request("b", 4096)
	late.Access = Write
	m := memory(4)
	m.mapPage(0x1000, 0, 0x900000)
	m.mapPage(0x1000, 4096, 0x901000)
	*m.pte(0x1000, 0, 4) &= ^uint64(2)
	enqueue(t, w, leader)
	ok(t, w.Schedule(0))
	for now := uint64(1); now <= 2; now++ {
		a := onlyAccess(t, w)
		ok(t, w.CommitAccess(now-1, a.Token))
		ok(t, w.Return(now, m.response(a)))
	}
	ok(t, w.Enqueue(2, late))
	a := onlyAccess(t, w)
	if a.Level != 2 {
		t.Fatal("not at L2")
	}
	ok(t, w.CommitAccess(2, a.Token))
	ok(t, w.Return(3, m.response(a)))
	completion, ready := w.PeekCompletion()
	if !ready || completion.Request.ID != "b" || completion.Fault != PermissionFault {
		t.Fatal("late partial coalescing bypassed ancestor permission")
	}
}

func TestFiveLevelsAndCanonicalAddresses(t *testing.T) {
	for _, levels := range []int{4, 5} {
		for _, high := range []bool{false, true} {
			t.Run(fmt.Sprintf("levels%d-high%v", levels, high), func(t *testing.T) {
				c := fullConfig()
				c.Levels = levels
				va := uint64(0x12345)
				if high {
					va |= ^((uint64(1) << uint(12+9*levels-1)) - 1)
				}
				r := request("offset", va)
				m := memory(levels)
				m.mapPage(r.Root, va, 0x900000)
				result := run(t, c, []Request{r}, m)
				if len(result.accesses) != levels || result.completions["offset"].PAddr != 0x900345 {
					t.Fatal("wrong radix depth, canonical indexing, or byte offset")
				}
			})
		}
	}
}

func TestInvalidInputsAndMemoryErrors(t *testing.T) {
	for _, c := range []Config{{Levels: 3, Walkers: 1, BufferEntries: 1}, {Levels: 4, Walkers: 0, BufferEntries: 1},
		{Levels: 4, Walkers: 1, BufferEntries: 0}, {Levels: 4, Walkers: 1, BufferEntries: 1, UpperCoalescing: true}} {
		if _, err := New(c); err == nil {
			t.Fatal("invalid config accepted")
		}
	}
	w := newWalker(t, fullConfig())
	for _, r := range []Request{request("noncanonical", uint64(1)<<48), {ID: "unaligned-root", Root: 1}, {ID: "bad-access", Access: 99}} {
		if w.Enqueue(0, r) == nil {
			t.Fatal("invalid input accepted")
		}
	}
	enqueue(t, w, request("a", 0), request("b", 4096))
	if w.Enqueue(0, request("a", 8192)) == nil {
		t.Fatal("outstanding identity reused")
	}
	ok(t, w.Schedule(0))
	a := onlyAccess(t, w)
	ok(t, w.CommitAccess(0, a.Token))
	ok(t, w.Return(1, Response{Token: a.Token, LineAddress: a.LineAddress, MemoryError: true}))
	c, ready := w.PeekCompletion()
	if !ready || c.Fault != MemoryFault || w.Buffered()[0].Completed {
		t.Fatal("failed memory read satisfied pending requests")
	}
	if w.Schedule(0) == nil {
		t.Fatal("time regression accepted")
	}
	ok(t, w.ConsumeCompletion(1, "a"))
	ok(t, w.Schedule(1))
	if a := onlyAccess(t, w); a.Request.ID != "b" || a.Level != 4 {
		t.Fatal("memory fault incorrectly advanced waiting request")
	}
}
