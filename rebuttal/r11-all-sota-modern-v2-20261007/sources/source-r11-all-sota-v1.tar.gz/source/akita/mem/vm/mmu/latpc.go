package mmu

import (
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

func (m *MMU) LATPCStats() (bool, uint64) { return m.latpcEnabled, m.latpcMerged }

func (m *MMU) mergeLATPC(now sim.VTimeInSec, req *vm.TranslationReq) bool {
	for n := range m.walkingTranslations {
		t := &m.walkingTranslations[n]
		pages, valid := m.neighborPages(req)
		if !valid || len(pages) != 1 || pages[0].VAddr>>12 != req.LATPC.VPN || !t.latpcBatch.Add(req) {
			continue
		}
		t.cycleLeft++
		m.latpcMerged++
		if !req.IsPrefetch {
			translationtrace.EndStage(req.ID, "shared_mmu_pwqueue_wait", now)
			translationtrace.AddStageCycles(req.ID, "shared_mmu_ptw_service", uint64(t.cycleLeft))
		}
		tracing.TraceReqReceive(req, m)
		return true
	}
	return false
}

func (m *MMU) canSendLATPCMembers(t transaction) bool {
	if t.latpcBatch == nil {
		return true
	}
	return m.topSender.CanSend(1 + len(t.latpcBatch.Members))
}

func (m *MMU) sendLATPCMembers(now sim.VTimeInSec, t transaction) {
	if t.latpcBatch == nil {
		return
	}
	for _, req := range t.latpcBatch.Members {
		pages, valid := m.neighborPages(req)
		if !valid || len(pages) != 1 {
			panic("LATPC batch mapping changed before completion")
		}
		m.topSender.Send(vm.TranslationRspBuilder{}.WithSendTime(now).WithSrc(m.topPort).
			WithDst(req.Src).WithRspTo(req.ID).WithPage(pages[0]).WithTaskID(req.TaskID).
			WithOriginPort(req.OriginPort).WithPrefetch(req.IsPrefetch).Build())
		tracing.TraceReqComplete(req, m)
	}
}
