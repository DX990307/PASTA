// Package downstreamstats observes physical L2 translation transactions.
package downstreamstats

import (
	"math"
	"math/bits"
	"sync"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

// Duration keeps raw totals and power-of-two cycle bins. Bin 0 is zero cycles;
// bin k>0 covers (2^(k-2), 2^(k-1)] cycles, with bin 1 covering (0, 1].
// The last bin also absorbs overflow. Durations are rounded to the nearest
// cycle only for the histogram.
type Duration struct {
	Count               uint64
	Seconds, MaxSeconds float64
	CycleBins           [65]uint64
}

func (d *Duration) add(seconds float64, freq sim.Freq) {
	d.Count++
	d.Seconds += seconds
	if seconds > d.MaxSeconds {
		d.MaxSeconds = seconds
	}
	cycles := math.Round(seconds * float64(freq))
	bin := 0
	if cycles > 0 {
		if cycles >= math.Exp2(63) {
			bin = 64
		} else {
			bin = bits.Len64(uint64(cycles)-1) + 1
		}
	}
	d.CycleBins[bin]++
}

// Counter counts downstream requests, not original requesters or inferred PTEs.
// Received latency ends at the last expected physical response's port arrival;
// consumed latency ends when L2 retrieves the last such response.
type Counter struct {
	Started, Completed, Inflight, PeakInflight  uint64
	ExpectedPages, ReceivedPages, ConsumedPages uint64
	Received, Consumed, CompletionPortWait      Duration
	PendingAgeSeconds, OldestPendingSeconds     float64
}

// Diagnostics retain unexpected observations. Local GMMU line-return mode can
// legitimately emit duplicate/non-demand sectors and unmatched post-completion
// responses. Those counters are not by themselves a correctness failure.
type Diagnostics struct {
	DuplicateIssue, InvalidIssue, UnknownPath                             uint64
	UnmatchedReceive, UnmatchedConsume, InvalidResponse                   uint64
	DuplicateReceive, DuplicateConsume, ConsumeBeforeReceive, InvalidTime uint64
	NonDemandSector                                                       uint64
}

type transaction struct {
	path, source, destination    string
	pid                          vm.PID
	base                         uint64
	expected, received, consumed uint8
	start, receivedAt            sim.VTimeInSec
}

type PortCounter struct{ Received, Consumed uint64 }

type Snapshot struct {
	Ports           map[string]PortCounter
	Paths           map[string]Counter
	Diagnostics     Diagnostics
	RejectedCounts  map[string]uint64
	RejectedSamples []RejectedResponse
}

// Observer retains only live transactions and fixed-size aggregate counters.
// It never changes a message, cache state, simulated event, or packet size.
type Observer struct {
	mu              sync.Mutex
	clock           sim.TimeTeller
	pageShift       uint64
	freq            sim.Freq
	active          map[string]*transaction
	counts          map[string]Counter
	ports           map[string]PortCounter
	diagnostics     Diagnostics
	rejectedCounts  map[string]uint64
	rejectedSamples []RejectedResponse
}

func New(clock sim.TimeTeller, pageShift uint64, freq sim.Freq) *Observer {
	if clock == nil || pageShift > 60 || freq <= 0 {
		panic("invalid downstream observer configuration")
	}
	return &Observer{clock: clock, pageShift: pageShift, freq: freq,
		rejectedCounts: map[string]uint64{"route": 0, "nonpresent_page": 0, "pid": 0, "unaligned_page": 0, "neighborhood": 0},
		ports:          map[string]PortCounter{"local": {}, "outside": {}}, active: make(map[string]*transaction), counts: map[string]Counter{"local": {}, "native": {}, "assist": {}, "unknown": {}}}
}

type portHook struct {
	observer *Observer
	port     sim.Port
	local    bool
}

// Hook must be attached once to each L2 Bottom/Outside port, before requests run.
func (o *Observer) Hook(port sim.Port, local bool) sim.Hook {
	if port == nil {
		panic("nil downstream observation port")
	}
	return &portHook{o, port, local}
}

func (h *portHook) Func(ctx sim.HookCtx) {
	o := h.observer
	o.mu.Lock()
	defer o.mu.Unlock()
	now := o.clock.CurrentTime()
	switch msg := ctx.Item.(type) {
	case *vm.TranslationReq:
		if ctx.Pos == sim.HookPosPortMsgSend {
			o.issue(now, msg, h.port, h.local)
		}
	case *vm.TranslationRsp:
		if ctx.Pos == sim.HookPosPortMsgRecvd || ctx.Pos == sim.HookPosPortMsgRetrieve {
			label := "outside"
			if h.local {
				label = "local"
			}
			p := o.ports[label]
			if ctx.Pos == sim.HookPosPortMsgRetrieve {
				p.Consumed++
			} else {
				p.Received++
			}
			o.ports[label] = p
			o.response(now, msg, h.port, ctx.Pos == sim.HookPosPortMsgRetrieve)
		}
	}
}

func (o *Observer) issue(now sim.VTimeInSec, req *vm.TranslationReq, port sim.Port, local bool) {
	if req.ID == "" || req.Src == nil || req.Dst == nil || req.Src.Name() != port.Name() ||
		req.VAddr&((uint64(1)<<o.pageShift)-1) != 0 {
		o.diagnostics.InvalidIssue++
		return
	}
	if o.active[req.ID] != nil {
		o.diagnostics.DuplicateIssue++
		return
	}
	path := req.TracePath
	if local && (path == "" || path == "local") {
		path = "local"
	} else if local || (path != "native" && path != "assist") {
		path = "unknown"
		o.diagnostics.UnknownPath++
	}
	var expected uint8
	for i, present := range req.BitMap {
		if present {
			expected |= 1 << uint(i)
		}
	}
	// A zero bitmap is the protocol's ordinary single-page request, not eight pages.
	if expected == 0 {
		expected = 1 << ((req.VAddr >> o.pageShift) & 7)
	}
	o.active[req.ID] = &transaction{path: path, source: req.Src.Name(), destination: req.Dst.Name(),
		pid: req.PID, base: (req.VAddr >> (o.pageShift + 3)) << (o.pageShift + 3), expected: expected, start: now}
	c := o.counts[path]
	c.Started++
	c.Inflight++
	c.ExpectedPages += uint64(bits.OnesCount8(expected))
	if c.Inflight > c.PeakInflight {
		c.PeakInflight = c.Inflight
	}
	o.counts[path] = c
}

func (o *Observer) response(now sim.VTimeInSec, rsp *vm.TranslationRsp, port sim.Port, consume bool) {
	t := o.active[rsp.RespondTo]
	if t == nil {
		if consume {
			o.diagnostics.UnmatchedConsume++
		} else {
			o.diagnostics.UnmatchedReceive++
		}
		return
	}
	p := rsp.Page
	if reason := o.responseRejection(t, rsp, port); reason != "" {
		o.rejectResponse(now, t, rsp, port, consume, reason)
		return
	}
	bit := uint8(1 << ((p.VAddr - t.base) >> o.pageShift))
	if t.expected&bit == 0 {
		o.diagnostics.NonDemandSector++
		return
	}
	if now < t.start || math.IsNaN(float64(now)) || math.IsInf(float64(now), 0) {
		o.diagnostics.InvalidTime++
		return
	}
	c := o.counts[t.path]
	if !consume {
		if t.received&bit != 0 {
			o.diagnostics.DuplicateReceive++
			return
		}
		t.received |= bit
		c.ReceivedPages++
		if t.received == t.expected {
			t.receivedAt = now
			c.Received.add(float64(now-t.start), o.freq)
		}
	} else {
		if t.consumed&bit != 0 {
			o.diagnostics.DuplicateConsume++
			return
		}
		if t.received&bit == 0 {
			o.diagnostics.ConsumeBeforeReceive++
			return
		}
		if now < t.receivedAt {
			o.diagnostics.InvalidTime++
			return
		}
		t.consumed |= bit
		c.ConsumedPages++
		if t.consumed == t.expected {
			c.Completed++
			c.Inflight--
			c.Consumed.add(float64(now-t.start), o.freq)
			c.CompletionPortWait.add(float64(now-t.receivedAt), o.freq)
			delete(o.active, rsp.RespondTo)
		}
	}
	o.counts[t.path] = c
}

// Snapshot never flushes incomplete requests into the completed population.
func (o *Observer) Snapshot() Snapshot {
	o.mu.Lock()
	defer o.mu.Unlock()
	s := Snapshot{Paths: make(map[string]Counter, len(o.counts)), Ports: make(map[string]PortCounter), Diagnostics: o.diagnostics,
		RejectedCounts:  make(map[string]uint64, len(o.rejectedCounts)),
		RejectedSamples: append([]RejectedResponse(nil), o.rejectedSamples...)}
	for reason, count := range o.rejectedCounts {
		s.RejectedCounts[reason] = count
	}
	for port, c := range o.ports {
		s.Ports[port] = c
	}
	for path, c := range o.counts {
		s.Paths[path] = c
	}
	now := o.clock.CurrentTime()
	for _, t := range o.active {
		age := float64(now - t.start)
		if age < 0 {
			continue
		}
		c := s.Paths[t.path]
		c.PendingAgeSeconds += age
		if age > c.OldestPendingSeconds {
			c.OldestPendingSeconds = age
		}
		s.Paths[t.path] = c
	}
	return s
}
