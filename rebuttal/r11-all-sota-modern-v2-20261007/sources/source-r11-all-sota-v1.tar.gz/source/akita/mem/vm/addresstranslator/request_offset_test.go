package addresstranslator

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

type offsetTestPort struct {
	sim.Port
	sent   []sim.Msg
	reject bool
}

func (p *offsetTestPort) Send(msg sim.Msg) *sim.SendError {
	if p.reject {
		return sim.NewSendError()
	}
	p.sent = append(p.sent, msg)
	return nil
}

func TestRequestOffsetsKeepAlignedTranslationsAndDistinctAccesses(t *testing.T) {
	memory := sim.NewLimitNumMsgPort(nil, 16, "Memory.Top")
	a := MakeBuilder().WithEngine(sim.NewSerialEngine()).
		WithLog2PageSize(12).WithLowModuleFinder(&mem.SingleLowModuleFinder{LowModule: memory}).
		WithTranslationProvider(sim.NewLimitNumMsgPort(nil, 16, "L1.Top")).Build("Offset.AT")
	translation := &offsetTestPort{Port: a.translationPort}
	bottom := &offsetTestPort{Port: a.bottomPort}
	a.translationPort, a.bottomPort = translation, bottom
	addresses := []uint64{0x1004, 0x1ff0}
	for _, address := range addresses {
		req := mem.ReadReqBuilder{}.WithAddress(address).WithByteSize(4).WithPID(1).Build()
		if a.topPort.Recv(req) != nil || !a.translate(0) {
			t.Fatal("memory access not admitted")
		}
	}
	if len(translation.sent) != 2 || len(a.transactions) != 2 {
		t.Fatal("same-page accesses lost their individual transaction identity")
	}
	for i, msg := range translation.sent {
		req := msg.(*vm.TranslationReq)
		if req.VAddr != 0x1000 || req.PID != 1 || req.Src != translation ||
			(i > 0 && req.ID == translation.sent[0].Meta().ID) {
			t.Fatal("translation address was not aligned or its identity was reused")
		}
	}
	// Return translations in reverse order while the first memory send is blocked.
	for _, i := range []int{1, 0} {
		req := translation.sent[i].(*vm.TranslationReq)
		rsp := vm.TranslationRspBuilder{}.WithRspTo(req.ID).
			WithPage(vm.Page{PID: 1, VAddr: 0x1000, PAddr: 0x9000, PageSize: 4096, Valid: true}).Build()
		if translation.Recv(rsp) != nil {
			t.Fatal("test translation return blocked")
		}
		bottom.reject = true
		if a.parseTranslation(1e-9) || translation.Peek() != rsp || len(bottom.sent) != 1-i {
			t.Fatal("memory-side backpressure lost a response or sent an access")
		}
		bottom.reject = false
		if !a.parseTranslation(2e-9) || translation.Peek() != nil {
			t.Fatal("memory-side retry did not consume the translation")
		}
		got := bottom.sent[len(bottom.sent)-1].(*mem.ReadReq)
		want := uint64(0x9000) + addresses[i]%4096
		if got.Address != want || got.AccessByteSize != 4 || got.Dst != memory || got.PID != 0 {
			t.Fatalf("offset %x translated to %x, want %x", addresses[i], got.Address, want)
		}
		t.Logf("P1_OFFSET vaddr=%#x vpn=%#x paddr=%#x", addresses[i], req.VAddr, got.Address)
	}
	if len(a.transactions) != 0 || len(a.inflightReqToBottom) != 2 {
		t.Fatal("translation state leaked or a memory access was lost")
	}
}
