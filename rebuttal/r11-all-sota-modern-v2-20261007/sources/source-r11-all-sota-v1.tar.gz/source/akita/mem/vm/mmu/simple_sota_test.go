package mmu

import (
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
	"testing"
)

func TestSimpleSOTADemandReplies(t *testing.T) {
	for _, mode := range []string{"baseline", "neighbor", "latpc"} {
		t.Run(mode, func(t *testing.T) {
			engine := sim.NewSerialEngine()
			source := sim.NewLimitNumMsgPort(nil, 128, "SOTA.Source")
			table := vm.NewPageTable(12)
			b := MakeBuilder().WithEngine(engine).WithPageTable(table).WithMaxNumReqInFlight(1).WithWalkCoalescing(false).WithDemandPTEOnly(true)
			if mode == "neighbor" {
				b = b.WithNeighborAbstract("full")
			}
			if mode == "latpc" {
				b = b.WithLATPC(true)
			}
			m := b.Build("SOTA.MMU")
			link := sim.NewDirectConnection("SOTA.Link", engine, sim.GHz)
			link.PlugIn(source, 128)
			link.PlugIn(m.topPort, 128)
			var vpns []uint64
			for n := 0; n < 8; n++ {
				vpns = append(vpns, uint64(8+n))
				table.Insert(vm.Page{Valid: true, PID: 1, VAddr: uint64(8+n) << 12, PAddr: uint64(256+n) << 12, PageSize: 4096, DeviceID: 1})
			}
			infos := vm.DetectLATPC(vpns)
			requests := map[string]uint64{}
			for n, info := range infos {
				var mask [8]bool
				mask[n] = true
				r := vm.TranslationReqBuilder{}.WithSrc(source).WithDst(m.topPort).WithPID(1).WithDeviceID(1).
					WithVAddr(8 << 12).WithBitMap(mask).WithTransLatency(400).WithOriginPort(source).WithTaskID("warp").Build()
				if mode == "latpc" {
					r.LATPC = info
				}
				requests[r.ID] = info.VPN << 12
				if source.Send(r) != nil {
					t.Fatal("send failed")
				}
			}
			if err := engine.Run(); err != nil {
				t.Fatal(err)
			}
			for msg := source.Retrieve(engine.CurrentTime()); msg != nil; msg = source.Retrieve(engine.CurrentTime()) {
				r := msg.(*vm.TranslationRsp)
				address, ok := requests[r.RespondTo]
				if !ok || r.Page.VAddr != address {
					t.Fatal("wrong or duplicate response")
				}
				delete(requests, r.RespondTo)
			}
			if len(requests) != 0 || len(m.PWqueue) != 0 || m.PTWInflight() != 0 {
				t.Fatal("unfinished requests")
			}
			if mode == "neighbor" && m.neighborAbstractStats.PendingCompletions != 7 {
				t.Fatalf("leaf coalescing did not serve bitmap requests: %+v", m.neighborAbstractStats)
			}
			if mode == "latpc" && m.latpcMerged != 7 {
				t.Fatal("LATP batching did not merge")
			}
			if mode == "baseline" && engine.CurrentTime() < 4000e-9 {
				t.Fatal("baseline countdown changed")
			}
			if mode != "baseline" && engine.CurrentTime() > 600e-9 {
				t.Fatal("coalescing failed to save walks")
			}
		})
	}
}

func TestNeighborPIDAndUnmappedCandidate(t *testing.T) {
	m := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithWalkCoalescing(false).WithDemandPTEOnly(true).WithNeighborAbstract("full").Build("Guard.MMU")
	a := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(4096).Build()
	b := vm.TranslationReqBuilder{}.WithPID(2).WithVAddr(8192).Build()
	if m.sameNeighbor(a, b, 1) {
		t.Fatal("cross-PID match")
	}
	m.PWqueue = []PWqueue{{req: vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(8192).Build()}}
	m.completeNeighborPending(0, a)
	if len(m.PWqueue) != 1 || m.neighborAbstractStats.PendingCompletions != 0 {
		t.Fatal("unmapped request falsely completed")
	}
}
