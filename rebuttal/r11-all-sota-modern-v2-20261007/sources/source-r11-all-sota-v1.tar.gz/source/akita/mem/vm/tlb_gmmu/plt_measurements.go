package tlb_gmmu

import "github.com/sarchlab/akita/v3/mem/vm"

// PLTMeasurements counts demanded offsets at the time a PLT lookup completes.
// Shadow probes do not alter replacement state or simulated timing.
type PLTMeasurements struct {
	DemandProbes         uint64
	DemandHits           uint64
	DemandMisses         uint64
	FalseMisses          uint64
	GroupsWithFalseMiss  uint64
	CandidateValidations uint64
	OracleRecovered      uint64
}

func (tlb *GMMUTLB) observePLTLookup(
	pid vm.PID, baseVAddr uint64,
	lookupBitmap, demandBitmap [8]bool,
	result *pcdLookupResult,
) {
	if !tlb.pltShadow && !tlb.pltIdealLocator {
		return
	}
	hadFalseMiss := false
	for bit := 0; bit < 8; bit++ {
		// Late arrivals outside this lookup are not locator false misses.
		if !lookupBitmap[bit] || !demandBitmap[bit] {
			continue
		}
		tlb.pltMeasurements.DemandProbes++
		if result.HitBitmap[bit] {
			tlb.pltMeasurements.DemandHits++
			continue
		}
		tlb.pltMeasurements.DemandMisses++
		addr := baseVAddr + (uint64(bit) << tlb.log2Pagesize)
		setID := tlb.vAddrToSetIDForPID(pid, addr)
		way, page, found := tlb.Sets[setID].Lookup(pid, addr)
		if !found || !page.Valid || page.PID != pid || page.VAddr != addr {
			continue
		}
		tlb.pltMeasurements.FalseMisses++
		hadFalseMiss = true
		if tlb.pltIdealLocator {
			// An explicitly ideal locator recovers a resident demanded PTE for free.
			result.HitBitmap[bit] = true
			result.MissBitmap[bit] = false
			result.Pages[bit] = page
			tlb.visit(setID, way)
			tlb.pltMeasurements.OracleRecovered++
		}
	}
	if hadFalseMiss {
		tlb.pltMeasurements.GroupsWithFalseMiss++
	}
}

func (tlb *GMMUTLB) PLTStudyStats() map[string]float64 {
	s := tlb.pltMeasurements
	rows, evictions := 0, 0
	if tlb.pcd != nil {
		rows = tlb.pcd.numSets * tlb.pcd.numWays
		evictions = tlb.pcd.entryEvictions
	}
	shadow, ideal, disabled := 0.0, 0.0, 0.0
	if tlb.pltDisabled {
		disabled = 1
	}
	if tlb.pltShadow {
		shadow = 1
	}
	if tlb.pltIdealLocator {
		ideal = 1
	}
	return map[string]float64{
		"plt_shadow_enabled":         shadow,
		"plt_lookup_disabled":        disabled,
		"full_way_lookup_jobs":       float64(tlb.fullWayLookupJobs),
		"full_way_tag_comparisons":   float64(tlb.fullWayTagComparisons),
		"plt_ideal_locator_enabled":  ideal,
		"plt_extra_latency_cycles":   float64(tlb.pltExtraLatency),
		"plt_total_rows":             float64(rows),
		"plt_row_evictions":          float64(evictions),
		"plt_stale_candidate_bits":   float64(tlb.pcdStaleBits),
		"plt_demand_probes":          float64(s.DemandProbes),
		"plt_demand_hits":            float64(s.DemandHits),
		"plt_demand_misses":          float64(s.DemandMisses),
		"plt_false_miss_bits":        float64(s.FalseMisses),
		"plt_groups_with_false_miss": float64(s.GroupsWithFalseMiss),
		"plt_candidate_validations":  float64(s.CandidateValidations),
		"plt_oracle_recovered_bits":  float64(s.OracleRecovered),
	}
}
