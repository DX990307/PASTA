package radixwalk

import (
	"encoding/binary"
	"errors"
	"math"

	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

type MemoryPortStats struct {
	ReadRequests, ReadResponses, SendFailures                      uint64
	DeclaredRequestBytes, DeclaredResponseBytes, ReturnedDataBytes uint64
}

type issuedRead struct {
	access      MemoryAccess
	destination sim.Port
}

// MemoryPort bridges the core to existing physical ReadReq/DataReadyRsp
// traffic. Timing, bandwidth, queuing, and cacheline bytes come from the
// connected cache/memory backend, not a synthetic walker latency.
type MemoryPort struct {
	walker         *Walker
	port           sim.Port
	low            mem.LowModuleFinder
	freq           sim.Freq
	width          int
	cycle          uint64
	cycleValid     bool
	sent, received int
	nextWalker     int
	pending        map[uint64]*mem.ReadReq
	inflight       map[string]issuedRead
	stats          MemoryPortStats
}

func NewMemoryPort(walker *Walker, port sim.Port, low mem.LowModuleFinder, freq sim.Freq, width int) (*MemoryPort, error) {
	if walker == nil || port == nil || low == nil || freq <= 0 || math.IsNaN(float64(freq)) || math.IsInf(float64(freq), 0) || width <= 0 {
		return nil, errors.New("invalid radix memory port configuration")
	}
	return &MemoryPort{walker: walker, port: port, low: low, freq: freq, width: width,
		pending: make(map[uint64]*mem.ReadReq), inflight: make(map[string]issuedRead)}, nil
}

func (p *MemoryPort) prepareCycle(now sim.VTimeInSec) error {
	if now < 0 || math.IsNaN(float64(now)) || math.IsInf(float64(now), 0) {
		return errors.New("invalid memory port time")
	}
	cycle := p.freq.Cycle(now)
	if err := p.walker.checkTime(cycle); err != nil {
		return err
	}
	if p.cycleValid && cycle < p.cycle {
		return errors.New("memory port time moved backwards")
	}
	if !p.cycleValid || cycle != p.cycle {
		p.cycle = cycle
		p.cycleValid = true
		p.sent = 0
		p.received = 0
	}
	return nil
}

// Issue sends at most width cacheline reads per cycle, using round-robin
// walker arbitration. Repeated calls in a cycle share the same width budget.
func (p *MemoryPort) Issue(now sim.VTimeInSec) (bool, error) {
	if err := p.prepareCycle(now); err != nil {
		return false, err
	}
	progress := false
	accesses := p.walker.Accesses()
	startWalker := p.nextWalker
	for offset := 0; offset < len(p.walker.active) && p.sent < p.width; offset++ {
		index := (startWalker + offset) % len(p.walker.active)
		var selected *MemoryAccess
		for i := range accesses {
			if accesses[i].Walker == index {
				selected = &accesses[i]
				break
			}
		}
		if selected == nil {
			continue
		}
		a := *selected
		msg := p.pending[a.Token]
		if msg == nil {
			if a.Request.PID > math.MaxUint32 {
				return progress, errors.New("PID exceeds Akita memory protocol width")
			}
			destination := p.low.Find(a.LineAddress)
			if destination == nil {
				return progress, errors.New("no physical memory destination for page-table line")
			}
			msg = mem.ReadReqBuilder{}.WithSrc(p.port).WithDst(destination).WithSendTime(now).
				WithPID(vm.PID(a.Request.PID)).WithAddress(a.LineAddress).WithByteSize(64).Build()
			p.pending[a.Token] = msg
		}
		msg.SendTime = now
		if p.port.Send(msg) != nil {
			p.stats.SendFailures++
			return progress, nil
		}
		if err := p.walker.CommitAccess(p.cycle, a.Token); err != nil {
			return progress, err
		}
		delete(p.pending, a.Token)
		p.inflight[msg.ID] = issuedRead{a, msg.Dst}
		p.stats.ReadRequests++
		p.stats.DeclaredRequestBytes += uint64(msg.TrafficBytes)
		p.sent++
		progress = true
		p.nextWalker = (index + 1) % len(p.walker.active)
	}
	return progress, nil
}

// Receive decodes only complete 64-byte little-endian responses whose message
// identity and ports match a committed read. A malformed return is not consumed.
func (p *MemoryPort) Receive(now sim.VTimeInSec) (bool, error) {
	if err := p.prepareCycle(now); err != nil {
		return false, err
	}
	progress := false
	for p.received < p.width {
		msg := p.port.Peek()
		if msg == nil {
			break
		}
		rsp, ok := msg.(*mem.DataReadyRsp)
		if !ok {
			return progress, errors.New("unexpected radix memory response type")
		}
		read, ok := p.inflight[rsp.RespondTo]
		if !ok || rsp.Src != read.destination || rsp.Dst != p.port || len(rsp.Data) != 64 {
			return progress, errors.New("malformed or unmatched radix cacheline response")
		}
		response := Response{Token: read.access.Token, LineAddress: read.access.LineAddress}
		for i := range response.Entries {
			response.Entries[i] = binary.LittleEndian.Uint64(rsp.Data[i*8 : (i+1)*8])
		}
		if err := p.walker.Return(p.cycle, response); err != nil {
			return progress, err
		}
		p.port.Retrieve(now)
		delete(p.inflight, rsp.RespondTo)
		p.stats.ReadResponses++
		p.stats.ReturnedDataBytes += uint64(len(rsp.Data))
		p.stats.DeclaredResponseBytes += uint64(rsp.TrafficBytes)
		p.received++
		progress = true
	}
	return progress, nil
}

func (p *MemoryPort) Snapshot() MemoryPortStats { return p.stats }
