package tlb_gmmu

import (
	"fmt"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

func newMSHROnlyFlow(t *testing.T, coalescing, initialPTCL bool, entries int) *requestFlow {
	t.Helper()
	translationtrace.Configure(false, "", 100000)
	t.Cleanup(func() { translationtrace.Configure(false, "", 100000) })
	pt := vm.NewPageTable(12)
	for pid := vm.PID(1); pid <= 2; pid++ {
		for bit := uint64(0); bit < 16; bit++ {
			pt.Insert(vm.Page{PID: pid, VAddr: bit * 4096, PAddr: uint64(pid)*0x100000 + bit*4096,
				PageSize: 4096, Valid: true, DeviceID: 2})
		}
	}
	// With PLT absent, fixed PTCL mode selects existing per-PTE downstream
	// splitting. Zero thresholds keep it enabled without speculative lookups.
	l2 := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithDeviceID(1).
		WithNumSets(16).WithNumWays(16).WithNumReqPerCycle(128).
		WithNumMSHREntry(entries).WithPageTable(pt).WithLog2PageSize(12).
		WithPageSize(4096).WithPTELookupSlots(8).WithPTELookupLatencyCycles(32).
		WithPerVPNMSHRBaseline(!coalescing).WithFlexTLB(false).
		WithInitialPTCLMode(initialPTCL).WithPTCLModeThresholds(0, 0).
		WithIdleIOMMUAssist(false).
		WithIOMMUPort(sim.NewLimitNumMsgPort(nil, 64, "MSHROnly.IOTLB")).
		WithLowModule(sim.NewLimitNumMsgPort(nil, 64, "MSHROnly.Local")).Build("MSHROnly.L2")
	h := &requestFlow{t: t, tlb: l2}
	h.top = &routeTestPort{Port: l2.topPort}
	h.bottom = &routeTestPort{Port: l2.bottomPort}
	h.outside = &routeTestPort{Port: l2.OutsidePort}
	l2.topPort, l2.bottomPort, l2.OutsidePort = h.top, h.bottom, h.outside
	return h
}

func TestMSHROnlyFlowPreservesDemandAndRequesterIdentity(t *testing.T) {
	for _, coalescing := range []bool{false, true} {
		t.Run(fmt.Sprint(coalescing), func(t *testing.T) {
			h := newMSHROnlyFlow(t, coalescing, true, 16)
			for _, spec := range []struct{ pid, bit int }{{1, 0}, {1, 2}, {1, 0}, {2, 2}} {
				h.admit(vm.PID(spec.pid), spec.bit, fmt.Sprintf("GPM%d.L1", len(h.requests)+1))
			}
			wantEntries := 3
			if coalescing {
				wantEntries = 2
			}
			if n, _ := h.tlb.mshr.Occupancy(); n != wantEntries || h.tlb.pcd != nil || h.tlb.flexTLBEnabled {
				t.Fatal("wrong allocation granularity or a hidden locator")
			}
			h.outside.reject = true
			h.until(70)
			if len(h.walks()) != 0 {
				t.Fatal("blocked output counted as issued")
			}
			h.admit(1, 5, "Late.BeforeIssue")
			h.until(110)
			h.outside.reject = false
			h.until(120)
			h.admit(1, 7, "Late.AfterIssue")
			h.until(170)
			if len(h.walks()) != 5 || h.tlb.idleIOMMUAssistIssued != 0 || len(h.tlb.ptclRepresentativeMiss) != 0 {
				t.Fatal("MSHR-only mode lost a demand or added Assist/representative work")
			}
			seen := map[[2]uint64]bool{}
			for _, req := range h.walks() {
				key := [2]uint64{uint64(req.PID), req.VAddr}
				if h.tlb.bitmapCount(req.BitMap) != 1 || req.BitMap[h.tlb.ptclBit(req.VAddr)] != true || seen[key] {
					t.Fatal("non-demand sector, duplicate, or multi-PTE downstream transaction")
				}
				seen[key] = true
			}
			h.top.reject = true
			walks := h.walks()
			for i := len(walks) - 1; i >= 0; i-- {
				h.returnWalk(walks[i])
			}
			if len(h.top.sent) != 0 {
				t.Fatal("reply bypassed backpressure")
			}
			h.top.reject = false
			h.until(h.cycle + 4)
			h.checkReplies()
			if h.tlb.ptclMode != coalescing || h.tlb.switchToPTECount != 0 || h.tlb.switchToPTCLCount != 0 {
				t.Fatal("fixed demand-only control changed modes")
			}
			t.Logf("MSHR_ONLY l2_coalescing=%v requests=%d unique_demands=5 downstream=%d initial_entries=%d lookup_jobs=%d lookup_cycles=%d",
				coalescing, len(h.requests), len(walks), wantEntries, h.tlb.pteLookupDelayCount, h.tlb.pteLookupDelayCycles)
		})
	}
}

func TestMSHROnlyEntryCapacityStillAppliesToOtherNeighborhoods(t *testing.T) {
	h := newMSHROnlyFlow(t, true, true, 1)
	h.admit(1, 0, "First")
	h.admit(1, 2, "SameNeighborhood")
	other := h.request(1, 8, "OtherNeighborhood")
	h.enqueue(other)
	if h.tlb.lookupFromTopPort(h.now()) || h.top.Peek() != other {
		t.Fatal("different neighborhood bypassed full entry capacity")
	}
	h.until(70)
	if len(h.walks()) != 2 {
		t.Fatal("entry compression erased per-PTE downstream work")
	}
	for _, r := range h.walks() {
		h.returnWalk(r)
	}
	h.until(150)
	if len(h.walks()) != 3 || h.top.Peek() != nil {
		t.Fatal("blocked neighborhood did not resume after retirement")
	}
	h.returnWalk(h.walks()[2])
	h.until(h.cycle + 3)
	h.checkReplies()
}

// The old candidate is deliberately characterized, not accepted as a legal
// control: its multi-bit packet is incompatible with demand-only IOTLB input.
func TestLegacyMSHROnlyCandidateCanBundleBeforeModeSwitch(t *testing.T) {
	h := newMSHROnlyFlow(t, true, false, 16)
	h.admit(1, 0, "A")
	h.admit(1, 2, "B")
	h.admit(1, 5, "C")
	h.until(70)
	if len(h.walks()) != 1 || h.walks()[0].BitMap != ([8]bool{0: true, 2: true, 5: true}) {
		t.Fatal("legacy candidate behavior changed; reassess its compatibility evidence")
	}
	t.Log("MSHR_ONLY legacy_initial_pte_mode=true demand_sectors=3 emitted_packets=1 emitted_bitmap=0,2,5 unsafe_for_demand_only_iotlb=true")
}
