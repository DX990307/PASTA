package downstreamstats

import (
	"math"
	"reflect"
	"sync"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

type testClock struct{ now sim.VTimeInSec }

func (c *testClock) CurrentTime() sim.VTimeInSec { return c.now }

type testConnection struct {
	sim.Connection
	reject bool
}

func (c *testConnection) Send(sim.Msg) *sim.SendError {
	if c.reject {
		return sim.NewSendError()
	}
	return nil
}
func (c *testConnection) NotifyAvailable(sim.VTimeInSec, sim.Port) {}

type fixture struct {
	clock        *testClock
	observer     *Observer
	port, remote sim.Port
	conn         *testConnection
}

func newFixture(local bool) fixture {
	c := &testClock{}
	f := fixture{clock: c, observer: New(c, 12, sim.GHz),
		port:   sim.NewLimitNumMsgPort(nil, 16, "L2.Bottom"),
		remote: sim.NewLimitNumMsgPort(nil, 16, "Walker.Top"), conn: &testConnection{}}
	f.port.SetConnection(f.conn)
	f.port.AcceptHook(f.observer.Hook(f.port, local))
	return f
}
func (f fixture) request(path string, pid vm.PID, bitmap [8]bool) *vm.TranslationReq {
	r := vm.TranslationReqBuilder{}.WithSrc(f.port).WithDst(f.remote).
		WithPID(pid).WithVAddr(0).WithBitMap(bitmap).Build()
	r.TracePath = path
	return r
}
func (f fixture) reply(req *vm.TranslationReq, bit uint64) *vm.TranslationRsp {
	return vm.TranslationRspBuilder{}.WithSrc(f.remote).WithDst(f.port).WithRspTo(req.ID).
		WithPage(vm.Page{Valid: true, PID: req.PID, VAddr: bit * 4096, PAddr: 0x100000 + bit*4096}).Build()
}
func assertNear(t *testing.T, got, want float64) {
	t.Helper()
	if math.Abs(got-want) > 1e-18 {
		t.Fatalf("got %.15g want %.15g", got, want)
	}
}

func TestPhysicalBitmapCopiesAndBackpressure(t *testing.T) {
	f := newFixture(false)
	r := f.request("assist", 1, [8]bool{true, false, true})
	f.conn.reject = true
	if f.port.Send(r) == nil || f.observer.Snapshot().Paths["assist"].Started != 0 {
		t.Fatal("rejected send counted")
	}
	f.conn.reject = false
	f.clock.now = 1e-9
	f.port.Send(r)
	r.BitMap = [8]bool{} // IOTLB mutates the original bitmap while responding.
	f.clock.now = 4e-9
	f.port.Recv(f.reply(r, 2))
	f.clock.now = 5e-9
	f.port.Retrieve(f.clock.now)
	f.clock.now = 8e-9
	f.port.Recv(f.reply(r, 0))
	s := f.observer.Snapshot()
	c := s.Paths["assist"]
	if c.Started != 1 || c.Completed != 0 || c.Inflight != 1 || c.ExpectedPages != 2 ||
		c.ReceivedPages != 2 || c.ConsumedPages != 1 || c.Received.Count != 1 || c.Consumed.Count != 0 {
		t.Fatalf("partial bitmap population: %+v", c)
	}
	assertNear(t, c.Received.Seconds, 7e-9)
	assertNear(t, c.OldestPendingSeconds, 7e-9)
	f.clock.now = 12e-9
	f.port.Retrieve(f.clock.now)
	c = f.observer.Snapshot().Paths["assist"]
	if c.Completed != 1 || c.Inflight != 0 || c.ConsumedPages != 2 || c.Consumed.Count != 1 ||
		c.Consumed.CycleBins[5] != 1 || c.Received.CycleBins[4] != 1 || len(f.observer.active) != 0 {
		t.Fatalf("completed bitmap population: %+v", c)
	}
	assertNear(t, c.Consumed.Seconds, 11e-9)
	assertNear(t, c.CompletionPortWait.Seconds, 4e-9)
	if f.observer.Snapshot().Diagnostics != (Diagnostics{}) {
		t.Fatal("unexpected diagnostics")
	}
	// Snapshot arrays/maps must not alias live counters.
	s.Paths["assist"] = Counter{}
	if f.observer.Snapshot().Paths["assist"].Started != 1 {
		t.Fatal("snapshot is mutable")
	}
}

func TestPathsPIDSeparationAndInflightTail(t *testing.T) {
	f := newFixture(false)
	a, b := f.request("native", 1, [8]bool{}), f.request("assist", 2, [8]bool{true})
	f.port.Send(a)
	f.port.Send(b)
	f.clock.now = 8e-9
	f.port.Recv(f.reply(b, 0))
	f.port.Retrieve(f.clock.now)
	s := f.observer.Snapshot()
	if s.Paths["native"].Completed != 0 || s.Paths["native"].Inflight != 1 ||
		s.Paths["assist"].Completed != 1 || s.Paths["assist"].Inflight != 0 {
		t.Fatal("paths/PIDs mixed")
	}
	assertNear(t, s.Paths["native"].PendingAgeSeconds, 8e-9)
	for _, path := range []string{"", "local"} {
		local := newFixture(true)
		r := local.request(path, 1, [8]bool{true})
		local.port.Send(r)
		local.port.Recv(local.reply(r, 0))
		local.port.Retrieve(0)
		if local.observer.Snapshot().Paths["local"].Completed != 1 {
			t.Fatal("local route lost")
		}
	}
	unknown := f.request("", 1, [8]bool{true})
	f.port.Send(unknown)
	if f.observer.Snapshot().Diagnostics.UnknownPath != 1 {
		t.Fatal("unknown path guessed")
	}
}

func TestBadResponsesDoNotCompleteTransactions(t *testing.T) {
	f := newFixture(false)
	r := f.request("native", 1, [8]bool{true})
	f.port.Send(r)
	f.port.Send(r)
	badPID, invalid, wrongOffset, wrongSource := f.reply(r, 0), f.reply(r, 0), f.reply(r, 7), f.reply(r, 0)
	badPID.Page.PID = 2
	invalid.Page.Valid = false
	wrongSource.Src = f.port
	for _, rsp := range []*vm.TranslationRsp{badPID, invalid, wrongOffset, wrongSource} {
		f.port.Recv(rsp)
		f.port.Retrieve(0)
	}
	f.port.Recv(f.reply(r, 0))
	f.port.Recv(f.reply(r, 0))
	f.port.Retrieve(0)
	f.port.Retrieve(0)
	s := f.observer.Snapshot()
	if s.Paths["native"].Completed != 1 || s.Paths["native"].ConsumedPages != 1 ||
		s.Diagnostics.InvalidResponse != 6 || s.Diagnostics.NonDemandSector != 2 || s.Diagnostics.DuplicateIssue != 1 ||
		s.Diagnostics.DuplicateReceive != 1 || s.Diagnostics.UnmatchedConsume != 1 {
		t.Fatalf("invalid/duplicate response handling: %+v", s)
	}
	// A duplicate after retirement is unmatched, not a new completed transaction.
	f.port.Recv(f.reply(r, 0))
	f.port.Retrieve(0)
	if f.observer.Snapshot().Diagnostics.UnmatchedReceive != 1 {
		t.Fatal("late duplicate unreported")
	}
}

func TestConsumeBeforeReceiveAndBadClockAreVisible(t *testing.T) {
	f := newFixture(false)
	r := f.request("native", 1, [8]bool{true, true})
	f.clock.now = 1e-9
	f.port.Send(r)
	hook := f.observer.Hook(f.port, false)
	hook.Func(sim.HookCtx{Pos: sim.HookPosPortMsgRetrieve, Item: f.reply(r, 0)})
	f.clock.now = -1
	f.port.Recv(f.reply(r, 0))
	f.port.Retrieve(-1)
	f.clock.now = 2e-9
	f.port.Recv(f.reply(r, 0))
	f.port.Retrieve(2e-9)
	hook.Func(sim.HookCtx{Pos: sim.HookPosPortMsgRetrieve, Item: f.reply(r, 0)})
	s := f.observer.Snapshot()
	if s.Diagnostics.ConsumeBeforeReceive != 1 || s.Diagnostics.InvalidTime != 2 ||
		s.Diagnostics.DuplicateConsume != 1 || s.Paths["native"].Completed != 0 {
		t.Fatalf("%+v", s)
	}
}

func TestDurationBinEdgesAndConcurrentSnapshot(t *testing.T) {
	var d Duration
	for _, cycles := range []float64{0, 1, 2, 3, 4, 5, 8, 9} {
		d.add(cycles*1e-9, sim.GHz)
	}
	if !reflect.DeepEqual(d.CycleBins[:5], []uint64{1, 1, 1, 2, 2}) || d.CycleBins[5] != 1 {
		t.Fatal(d.CycleBins)
	}
	f := newFixture(false)
	r := f.request("native", 1, [8]bool{true})
	var wg sync.WaitGroup
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				f.observer.Snapshot()
			}
		}()
	}
	f.port.Send(r)
	f.port.Recv(f.reply(r, 0))
	f.port.Retrieve(0)
	wg.Wait()
	if f.observer.Snapshot().Paths["native"].Completed != 1 {
		t.Fatal("snapshot changed completion")
	}
}
