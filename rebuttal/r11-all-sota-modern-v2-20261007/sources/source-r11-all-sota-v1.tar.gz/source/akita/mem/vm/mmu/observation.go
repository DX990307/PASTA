package mmu

import "github.com/sarchlab/akita/v3/mem/vm"

// WalkObservation is a copy of live walker identity, not a scheduling handle.
type WalkObservation struct {
	RequestID  string
	TaskID     string
	PID        vm.PID
	VAddr      uint64
	CyclesLeft int
}

// ObserveWalks is read-only and must be called on the simulation thread.
func (mmu *MMU) ObserveWalks() (active []WalkObservation, queued, backlog int) {
	for _, walk := range mmu.walkingTranslations {
		active = append(active, WalkObservation{RequestID: walk.req.ID,
			TaskID: walk.req.TaskID, PID: walk.req.PID, VAddr: walk.req.VAddr,
			CyclesLeft: walk.cycleLeft})
	}
	return active, len(mmu.PWqueue), len(mmu.mockBuffer)
}
