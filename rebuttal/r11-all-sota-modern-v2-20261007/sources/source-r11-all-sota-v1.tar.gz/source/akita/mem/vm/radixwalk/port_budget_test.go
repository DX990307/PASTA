package radixwalk

import (
	"encoding/binary"
	"testing"

	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/sim"
)

func TestMemoryPortBudgetsAndRoundRobinAcrossRepeatedCalls(t *testing.T) {
	config := fullConfig()
	config.AwareScheduling = false
	w := newWalker(t, config)
	enqueue(t, w, request("a", 0), request("b", 4096))
	ok(t, w.Schedule(0))
	p := &recordingMemoryPort{Port: sim.NewLimitNumMsgPort(nil, 4, "Budget.Source")}
	dst := sim.NewLimitNumMsgPort(nil, 4, "Budget.Memory")
	b, err := NewMemoryPort(w, p, &mem.SingleLowModuleFinder{LowModule: dst}, sim.GHz, 1)
	ok(t, err)
	_, err = b.Issue(0)
	ok(t, err)
	_, err = b.Issue(0)
	ok(t, err)
	if len(p.messages) != 1 {
		t.Fatal("repeated issue multiplied width")
	}
	first := p.messages[0].(*mem.ReadReq)
	data := make([]byte, 64)
	binary.LittleEndian.PutUint64(data, 0x2000|7)
	p.Recv(mem.DataReadyRspBuilder{}.WithSrc(dst).WithDst(p).WithRspTo(first.ID).WithData(data).Build())
	_, err = b.Receive(1e-9)
	ok(t, err)
	_, err = b.Issue(1e-9)
	ok(t, err)
	second := p.messages[1].(*mem.ReadReq)
	if b.inflight[second.ID].access.Request.ID != "b" {
		t.Fatal("ready lower-numbered walker bypassed round-robin")
	}
	_, err = b.Issue(2e-9)
	ok(t, err)
	third := p.messages[2].(*mem.ReadReq)
	if b.inflight[third.ID].access.Request.ID != "a" {
		t.Fatal("walk did not resume at next level")
	}
	for _, r := range []*mem.ReadReq{second, third} {
		p.Recv(mem.DataReadyRspBuilder{}.WithSrc(dst).WithDst(p).WithRspTo(r.ID).WithData(data).Build())
	}
	_, err = b.Receive(3e-9)
	ok(t, err)
	_, err = b.Receive(3e-9)
	ok(t, err)
	if b.Snapshot().ReadResponses != 2 || p.Peek() == nil {
		t.Fatal("repeated receive multiplied response width")
	}
	_, err = b.Receive(4e-9)
	ok(t, err)
	if b.Snapshot().ReadResponses != 3 || p.Peek() != nil {
		t.Fatal("deferred response not retained")
	}
}
