package mmu

import (
	"math"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

// No physical memory traffic is inferred from these aggregate-timer counters.
type NeighborAbstractStats struct {
	LeafReturns, PendingCompletions, DemandPages, LevelsSkipped uint64
	PartialEvents                                               [6]uint64
	SchedulerHeldTicks, TimeoutStarts                           uint64
}

func (m *MMU) NeighborAbstractStats() (int, NeighborAbstractStats) {
	return m.neighborAbstractPolicy, m.neighborAbstractStats
}

func (m *MMU) neighborRegion(req *vm.TranslationReq, level int) uint64 {
	return (req.VAddr >> m.log2PageSize) >> uint(3+9*(level-1))
}

func (m *MMU) sameNeighbor(a, b *vm.TranslationReq, level int) bool {
	return a != nil && b != nil && a.PID == b.PID && m.neighborRegion(a, level) == m.neighborRegion(b, level)
}

// One aggregate upper-path return grants prefix credit to queued requests.
// This deliberately does not claim physical per-level PTE-return timing.
func (m *MMU) advanceNeighborPending(active *vm.TranslationReq) {
	for i := range m.PWqueue {
		p := &m.PWqueue[i]
		for level := 2; level <= 5; level++ {
			if !m.sameNeighbor(p.req, active, level) {
				continue
			}
			if p.neighborPartialLevel == 0 || level < p.neighborPartialLevel {
				p.neighborPartialLevel = level
				m.neighborAbstractStats.PartialEvents[level]++
			}
			break
		}
	}
}

func (m *MMU) selectNeighborPending(now sim.VTimeInSec) int {
	if m.neighborAbstractPolicy != 1 {
		return 0
	}
	cycle := uint64(math.Round(float64(now) * float64(m.Freq)))
	first, timeout := -1, -1
	for i := range m.PWqueue {
		p := &m.PWqueue[i]
		coalescible := false
		for _, active := range m.walkingTranslations {
			level := 5
			if active.neighborUpperReturned {
				level = 1
			}
			if m.sameNeighbor(p.req, active.req, level) {
				coalescible = true
				break
			}
		}
		if !coalescible {
			p.neighborHeld = false
			if first < 0 {
				first = i
			}
		} else {
			if !p.neighborHeld {
				p.neighborHeld = true
				p.neighborHoldStart = cycle
			}
			if cycle-p.neighborHoldStart >= 100000 && timeout < 0 {
				timeout = i
			}
		}
	}
	if first >= 0 {
		return first
	}
	if timeout >= 0 {
		m.neighborAbstractStats.TimeoutStarts++
		return timeout
	}
	m.neighborAbstractStats.SchedulerHeldTicks++
	return -1
}

func (m *MMU) neighborPages(req *vm.TranslationReq) ([]vm.Page, bool) {
	var pages []vm.Page
	if !m.hasBitmap(req.BitMap) {
		p, ok := m.pageTable.Find(req.PID, req.VAddr)
		if !ok {
			return nil, false
		}
		pages = append(pages, p)
	} else {
		base := m.getBaseVAddr(req.VAddr)
		for bit, demanded := range req.BitMap {
			if !demanded {
				continue
			}
			p, ok := m.pageTable.Find(req.PID, base+(uint64(bit)<<m.log2PageSize))
			if !ok {
				return nil, false
			}
			pages = append(pages, p)
		}
	}
	for _, p := range pages {
		if !p.Valid || p.PageSize != uint64(1)<<m.log2PageSize || p.IsMigrating ||
			m.pageNeedMigrate(transaction{req: req, page: p}) {
			return nil, false
		}
	}
	return pages, len(pages) > 0
}

func (m *MMU) completeNeighborPending(now sim.VTimeInSec, active *vm.TranslationReq) {
	if m.neighborAbstractPolicy == 0 {
		return
	}
	m.neighborAbstractStats.LeafReturns++
	kept := m.PWqueue[:0]
	for _, pending := range m.PWqueue {
		req := pending.req
		if !m.sameNeighbor(req, active, 1) {
			kept = append(kept, pending)
			continue
		}
		pages, valid := m.neighborPages(req)
		if !valid || !m.topSender.CanSend(len(pages)) {
			kept = append(kept, pending)
			continue
		}
		for _, page := range pages {
			m.topSender.Send(vm.TranslationRspBuilder{}.WithSendTime(now).WithSrc(m.topPort).
				WithDst(req.Src).WithRspTo(req.ID).WithPage(page).WithTaskID(req.TaskID).
				WithOriginPort(req.OriginPort).WithPrefetch(req.IsPrefetch).Build())
		}
		if !req.IsPrefetch {
			translationtrace.EndStage(req.ID, "shared_mmu_pwqueue_wait", now)
			translationtrace.AddStageCycles(req.ID, "shared_mmu_ptw_service", 0)
		}
		tracing.TraceReqComplete(req, m)
		m.neighborAbstractStats.PendingCompletions++
		m.neighborAbstractStats.DemandPages += uint64(len(pages))
	}
	m.PWqueue = kept
}
