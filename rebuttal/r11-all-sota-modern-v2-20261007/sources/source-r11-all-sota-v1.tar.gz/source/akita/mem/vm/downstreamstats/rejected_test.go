package downstreamstats

import (
	"fmt"
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
)

func TestRejectionSamplesAreBoundedCopiedAndDoNotComplete(t *testing.T) {
	f := newFixture(false)
	r := f.request("native", 1, [8]bool{true})
	f.port.Send(r)
	for n := 0; n < 12; n++ {
		rsp := f.reply(r, 0)
		rsp.Page.Valid = false
		rsp.ID = fmt.Sprintf("invalid-%d", n)
		f.port.Recv(rsp)
		f.port.Retrieve(0)
		rsp.Page.Valid, rsp.Page.PID, rsp.ID = true, 99, "mutated"
	}
	s := f.observer.Snapshot()
	if s.Diagnostics.InvalidResponse != 24 || len(s.RejectedSamples) != InvalidResponseSampleLimit ||
		s.RejectedCounts["nonpresent_page"] != 24 || s.Paths["native"].Completed != 0 {
		t.Fatalf("bad bounded rejection evidence: %+v", s)
	}
	for n, sample := range s.RejectedSamples {
		stage := "received"
		if n%2 != 0 {
			stage = "consumed"
		}
		if sample.ResponseID != fmt.Sprintf("invalid-%d", n/2) || sample.Page.Valid || sample.Page.PID != 1 ||
			sample.Stage != stage || sample.RespondTo != r.ID || sample.Path != "native" ||
			sample.ExpectedSource != f.remote.Name() || sample.ExpectedDestination != f.port.Name() ||
			sample.ExpectedBitmap != 1 || sample.Reason != "nonpresent_page" {
			t.Fatal("sample changed with message or lost transaction context")
		}
	}
	s.RejectedCounts["nonpresent_page"] = 0
	s.RejectedSamples[0].Reason = "mutated"
	if next := f.observer.Snapshot(); next.RejectedCounts["nonpresent_page"] != 24 || next.RejectedSamples[0].Reason != "nonpresent_page" {
		t.Fatal("snapshot mutated observer")
	}
	f.port.Recv(f.reply(r, 0))
	f.port.Retrieve(0)
	if f.observer.Snapshot().Paths["native"].Completed != 1 {
		t.Fatal("diagnostic capture prevented later valid completion")
	}
}

func TestRejectionReasonsPreserveOriginalValidationPredicate(t *testing.T) {
	f := newFixture(false)
	r := f.request("assist", 1, [8]bool{true})
	f.port.Send(r)
	transaction := *f.observer.active[r.ID]
	for _, test := range []struct {
		reason string
		change func(*vm.TranslationRsp)
	}{
		{"route", func(r *vm.TranslationRsp) { r.Src = nil }},
		{"route", func(r *vm.TranslationRsp) { r.Dst = f.remote }},
		{"nonpresent_page", func(r *vm.TranslationRsp) { r.Page.Valid = false }},
		{"pid", func(r *vm.TranslationRsp) { r.Page.PID++ }},
		{"unaligned_page", func(r *vm.TranslationRsp) { r.Page.VAddr++ }},
		{"neighborhood", func(r *vm.TranslationRsp) { r.Page.VAddr = 32768 }},
	} {
		rsp := f.reply(r, 0)
		test.change(rsp)
		before := *rsp
		f.port.Recv(rsp)
		f.port.Retrieve(0)
		if sample := f.observer.Snapshot().RejectedSamples; len(sample) < InvalidResponseSampleLimit && sample[len(sample)-1].Reason != test.reason {
			t.Fatal("incorrect reason")
		}
		if !reflect.DeepEqual(before, *rsp) || !reflect.DeepEqual(transaction, *f.observer.active[r.ID]) {
			t.Fatal("diagnostic changed response or transaction progress")
		}
	}
	s := f.observer.Snapshot()
	if s.Diagnostics.InvalidResponse != 12 || s.RejectedCounts["route"] != 4 || s.RejectedCounts["pid"] != 2 ||
		s.RejectedCounts["nonpresent_page"] != 2 || s.RejectedCounts["unaligned_page"] != 2 || s.RejectedCounts["neighborhood"] != 2 {
		t.Fatalf("reason populations do not cover rejected events: %+v", s.RejectedCounts)
	}
	// A valid but unrequested sector remains non-demand, not an invalid page.
	f.port.Recv(f.reply(r, 7))
	f.port.Retrieve(0)
	if f.observer.Snapshot().Diagnostics.NonDemandSector != 2 {
		t.Fatal("non-demand sectors were reclassified as invalid")
	}
}
