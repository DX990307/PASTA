package radixwalk

import "testing"

func TestCoalescedAncestorFaultPrecedesNonpresentLeaf(t *testing.T) {
	config := fullConfig()
	config.UpperCoalescing = false
	config.Walkers = 1
	m := memory(4)
	m.mapPage(0x1000, 0, 0x900000)
	m.mapPage(0x1000, 4096, 0x901000)
	*m.pte(0x1000, 0, 2) |= uint64(1) << 63
	*m.pte(0x1000, 4096, 1) = 0
	a, b := request("read-leader", 0), request("execute-follower", 4096)
	b.Access = Execute
	result := run(t, config, []Request{a, b}, m)
	if result.completions[a.ID].Fault != NoFault || result.completions[b.ID].Fault != PermissionFault {
		t.Fatal("coalescing changed the earlier ancestor permission fault into a leaf not-present fault")
	}
	if result.completions[b.ID].Permissions != (Permissions{}) || result.completions[b.ID].PAddr != 0 {
		t.Fatal("fault completion exposed a successful mapping/permission set")
	}
}
