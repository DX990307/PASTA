// Package radixwalk implements a response-driven radix walker and optional
// neighborhood coalescing. It has no synthetic total-walk countdown.
package radixwalk

import (
	"errors"
	"fmt"
)

const pageShift = 12
const addressMask uint64 = 0x000ffffffffff000

var ErrBufferFull = errors.New("walk request buffer full")

type AccessKind uint8

const (
	Read AccessKind = iota
	Write
	Execute
)

type Fault uint8

const (
	NoFault Fault = iota
	NotPresent
	PermissionFault
	UnsupportedLargePage
	MemoryFault
)

type Request struct {
	ID         string
	PID        uint64
	Root       uint64
	Generation uint64
	VAddr      uint64
	Access     AccessKind
	User       bool
}

type Permissions struct{ Writable, User, Executable bool }

var allPermissions = Permissions{true, true, true}

type Config struct {
	Levels, Walkers, BufferEntries                   int
	LeafCoalescing, UpperCoalescing, AwareScheduling bool
	// Zero disables the optional simulator starvation guard.
	MaxWaitCycles uint64
}

// MemoryAccess is a proposed cacheline read. A backend must successfully send
// it before CommitAccess; retries use the same token and do not advance a walk.
type MemoryAccess struct {
	Token                    uint64
	Walker, Level            int
	Request                  Request
	NodeAddress, LineAddress uint64
	EntryWord                int
}

type Response struct {
	Token, LineAddress uint64
	Entries            [8]uint64
	MemoryError        bool
}

type Completion struct {
	Request     Request
	PAddr       uint64
	Permissions Permissions
	Fault       Fault
	ReadyCycle  uint64
	Coalesced   bool
}

type BufferedRequest struct {
	Request        Request
	HasPartialAddr bool
	NextPTAddr     uint64
	PartialLevel   int
	Coalescible    bool
	Permissions    Permissions
	Completed      bool
}

type ActiveWalk struct {
	Valid, Inflight, Completed bool
	Walker, CurrentLevel       int
	Request                    Request
	NodeAddress                uint64
}

type Stats struct {
	Admitted, Started, Successful, Faulted               uint64
	LeafCoalesced, LeafCoalescedFaults                   uint64
	PartialEvents, PartialLevelsSkipped                  [6]uint64
	UpperCoalescedFaults                                 [6]uint64
	MemoryAccesses, CachelineReturns                     [6]uint64
	TimeoutStarts, HeldWalkerTicks                       uint64
	QueueWaitCycles, ServiceCycles, CompletionWaitCycles uint64
	PeakBuffered                                         int
}

type entry struct {
	state                                      BufferedRequest
	arrival, start, holdSince, completionOrder uint64
	holding, started                           bool
	done                                       *Completion
}

type activeWalk struct {
	entry         *entry
	level         int
	node          uint64
	permissions   Permissions
	access        MemoryAccess
	inflight      bool
	lastHeldCycle uint64
	heldRecorded  bool
}

// Walker stores pending requests and one service entry per hardware walker.
// Completed entries stay in their original buffer/slot until their response is
// accepted, bounding storage and preserving downstream response backpressure.
type Walker struct {
	config                         Config
	buffer                         []*entry
	active                         []activeWalk
	ids                            map[string]bool
	nextToken, nextCompletion, now uint64
	stats                          Stats
}

func New(config Config) (*Walker, error) {
	if (config.Levels != 4 && config.Levels != 5) || config.Walkers <= 0 || config.BufferEntries <= 0 ||
		(config.UpperCoalescing && !config.LeafCoalescing) ||
		(config.AwareScheduling && !config.LeafCoalescing) {
		return nil, errors.New("invalid radix walker configuration")
	}
	return &Walker{config: config, active: make([]activeWalk, config.Walkers), ids: make(map[string]bool)}, nil
}

func (w *Walker) checkTime(now uint64) error {
	if now < w.now {
		return errors.New("walk time moved backwards")
	}
	return nil
}

func (w *Walker) validRequest(req Request) bool {
	return req.ID != "" && req.Access <= Execute && req.Root&addressMask == req.Root &&
		canonicalAddress(req.VAddr, w.config.Levels)
}

func (w *Walker) Enqueue(now uint64, req Request) error {
	if err := w.checkTime(now); err != nil {
		return err
	}
	if !w.validRequest(req) {
		return errors.New("invalid request/root/canonical virtual address")
	}
	if w.ids[req.ID] {
		return errors.New("request ID is already outstanding")
	}
	if len(w.buffer) == w.config.BufferEntries {
		return ErrBufferFull
	}
	w.now = now
	w.buffer = append(w.buffer, &entry{state: BufferedRequest{Request: req, Permissions: allPermissions}, arrival: now})
	w.ids[req.ID] = true
	w.stats.Admitted++
	if len(w.buffer) > w.stats.PeakBuffered {
		w.stats.PeakBuffered = len(w.buffer)
	}
	return nil
}

func sameNeighborhood(a, b Request, level int) bool {
	shift := uint(pageShift + 9*(level-1) + 3)
	return a.PID == b.PID && a.Root == b.Root && a.Generation == b.Generation && a.VAddr>>shift == b.VAddr>>shift
}

func (w *Walker) nextLevel(e *entry) int {
	if e.state.HasPartialAddr {
		return e.state.PartialLevel - 1
	}
	return w.config.Levels
}

func (w *Walker) coalescible(e *entry) bool {
	if !w.config.AwareScheduling || e.done != nil {
		return false
	}
	for _, a := range w.active {
		if a.entry == nil || a.entry.done != nil || w.nextLevel(e) < a.level {
			continue
		}
		if a.level > 1 && !w.config.UpperCoalescing {
			continue
		}
		if sameNeighborhood(e.state.Request, a.entry.state.Request, a.level) {
			return true
		}
	}
	return false
}

// Schedule assigns free walkers in FCFS order, excluding active coalescing
// opportunities when enabled. HeldWalkerTicks is sampled once per slot/cycle;
// it equals held walker-cycles only when the adapter schedules every cycle.
func (w *Walker) Schedule(now uint64) error {
	if err := w.checkTime(now); err != nil {
		return err
	}
	w.now = now
	for index := range w.active {
		a := &w.active[index]
		if a.entry != nil {
			continue
		}
		selected := -1
		timedOut := false
		anyHeld := false
		for i, e := range w.buffer {
			if e.done != nil {
				continue
			}
			e.state.Coalescible = w.coalescible(e)
			if e.state.Coalescible {
				anyHeld = true
				if !e.holding {
					e.holding = true
					e.holdSince = now
				}
			} else {
				e.holding = false
			}
			timeout := e.holding && w.config.MaxWaitCycles > 0 && now-e.holdSince >= w.config.MaxWaitCycles
			if selected < 0 && (!e.state.Coalescible || timeout) {
				selected = i
				timedOut = timeout
			}
		}
		if selected < 0 {
			if anyHeld && (!a.heldRecorded || a.lastHeldCycle != now) {
				w.stats.HeldWalkerTicks++
				a.heldRecorded = true
				a.lastHeldCycle = now
			}
			continue
		}
		e := w.buffer[selected]
		copy(w.buffer[selected:], w.buffer[selected+1:])
		w.buffer[len(w.buffer)-1] = nil
		w.buffer = w.buffer[:len(w.buffer)-1]
		a.entry = e
		a.level = w.nextLevel(e)
		a.node = e.state.Request.Root
		a.permissions = allPermissions
		if e.state.HasPartialAddr {
			a.node = e.state.NextPTAddr
			a.permissions = e.state.Permissions
		}
		e.started = true
		e.start = now
		e.holding = false
		e.state.Coalescible = false
		w.stats.Started++
		w.stats.QueueWaitCycles += now - e.arrival
		if timedOut {
			w.stats.TimeoutStarts++
		}
		w.prepareAccess(index)
	}
	return nil
}

func (w *Walker) prepareAccess(index int) {
	a := &w.active[index]
	word := (a.entry.state.Request.VAddr >> uint(pageShift+9*(a.level-1))) & 511
	pteAddress := a.node + word*8
	w.nextToken++
	a.inflight = false
	a.access = MemoryAccess{Token: w.nextToken, Walker: index, Level: a.level, Request: a.entry.state.Request,
		NodeAddress: a.node, LineAddress: pteAddress &^ uint64(63), EntryWord: int(word & 7)}
}

// Accesses returns copied, not-yet-accepted cacheline requests in walker order.
func (w *Walker) Accesses() []MemoryAccess {
	var out []MemoryAccess
	for _, a := range w.active {
		if a.entry != nil && a.entry.done == nil && !a.inflight {
			out = append(out, a.access)
		}
	}
	return out
}

func (w *Walker) findAccess(token uint64) (*activeWalk, int) {
	for i := range w.active {
		a := &w.active[i]
		if a.entry != nil && a.entry.done == nil && a.access.Token == token {
			return a, i
		}
	}
	return nil, -1
}

func (w *Walker) CommitAccess(now, token uint64) error {
	if err := w.checkTime(now); err != nil {
		return err
	}
	a, _ := w.findAccess(token)
	if a == nil || a.inflight {
		return errors.New("unknown or already-issued access token")
	}
	w.now = now
	a.inflight = true
	w.stats.MemoryAccesses[a.level]++
	return nil
}

func permits(p Permissions, req Request) bool {
	return (!req.User || p.User) && (req.Access != Write || p.Writable) && (req.Access != Execute || p.Executable)
}

func decode(pte uint64, level int, prior Permissions, req Request) (Permissions, Fault) {
	// A coalesced follower may require stronger permissions than the leader.
	// Its ancestor fault precedes any fault in the newly returned entry.
	if !permits(prior, req) {
		return prior, PermissionFault
	}
	if pte&1 == 0 {
		return prior, NotPresent
	}
	p := Permissions{prior.Writable && pte&2 != 0, prior.User && pte&4 != 0, prior.Executable && pte&(uint64(1)<<63) == 0}
	if level > 1 && pte&128 != 0 {
		return p, UnsupportedLargePage
	}
	if !permits(p, req) {
		return p, PermissionFault
	}
	return p, NoFault
}

func (w *Walker) complete(now uint64, e *entry, pte uint64, p Permissions, fault Fault, coalesced bool) {
	w.nextCompletion++
	e.completionOrder = w.nextCompletion
	e.done = &Completion{Request: e.state.Request, Permissions: p, Fault: fault, ReadyCycle: now, Coalesced: coalesced}
	if fault == NoFault {
		e.done.PAddr = (pte & addressMask) | (e.state.Request.VAddr & 4095)
		w.stats.Successful++
	} else {
		e.done.Permissions = Permissions{}
		w.stats.Faulted++
	}
	if e.started {
		w.stats.ServiceCycles += now - e.start
	} else {
		w.stats.QueueWaitCycles += now - e.arrival
	}
	e.state.Completed = true
	e.state.Coalescible = false
	e.holding = false
}

// Return advances only the access identified by a committed token. Both
// baseline and Neighbor decode exactly the same supplied PTE data. Pending
// walks can use that data only at this return event, never at issue time.
func (w *Walker) Return(now uint64, rsp Response) error {
	if err := w.checkTime(now); err != nil {
		return err
	}
	a, index := w.findAccess(rsp.Token)
	if a == nil || !a.inflight || a.access.LineAddress != rsp.LineAddress {
		return errors.New("response does not match an in-flight cacheline access")
	}
	w.now = now
	level, leader, prior := a.level, a.entry.state.Request, a.permissions
	w.stats.CachelineReturns[level]++
	if rsp.MemoryError {
		w.complete(now, a.entry, 0, prior, MemoryFault, false)
		return nil
	}
	pte := rsp.Entries[a.access.EntryWord]
	p, fault := decode(pte, level, prior, leader)
	if fault != NoFault || level == 1 {
		w.complete(now, a.entry, pte, p, fault, false)
	} else {
		a.level--
		a.node = pte & addressMask
		a.permissions = p
		w.prepareAccess(index)
	}
	if (level == 1 && !w.config.LeafCoalescing) || (level > 1 && !w.config.UpperCoalescing) {
		return nil
	}
	for _, e := range w.buffer {
		if e.done != nil || w.nextLevel(e) < level || !sameNeighborhood(e.state.Request, leader, level) {
			continue
		}
		word := (e.state.Request.VAddr >> uint(pageShift+9*(level-1))) & 7
		entryPTE := rsp.Entries[word]
		permissions, entryFault := decode(entryPTE, level, prior, e.state.Request)
		if entryFault != NoFault || level == 1 {
			w.complete(now, e, entryPTE, permissions, entryFault, true)
			if level == 1 {
				if entryFault == NoFault {
					w.stats.LeafCoalesced++
				} else {
					w.stats.LeafCoalescedFaults++
				}
			} else {
				w.stats.UpperCoalescedFaults[level]++
			}
			continue
		}
		w.stats.PartialEvents[level]++
		w.stats.PartialLevelsSkipped[level] += uint64(w.nextLevel(e) - (level - 1))
		e.state.HasPartialAddr = true
		e.state.NextPTAddr = entryPTE & addressMask
		e.state.PartialLevel = level
		e.state.Permissions = permissions
		// Scheduling recomputes this against all active walks and the exact level.
		e.state.Coalescible = w.coalescible(e)
	}
	return nil
}

func (w *Walker) firstCompletion() *entry {
	var first *entry
	visit := func(e *entry) {
		if e != nil && e.done != nil && (first == nil || e.completionOrder < first.completionOrder) {
			first = e
		}
	}
	for _, a := range w.active {
		visit(a.entry)
	}
	for _, e := range w.buffer {
		visit(e)
	}
	return first
}

func (w *Walker) PeekCompletion() (Completion, bool) {
	e := w.firstCompletion()
	if e == nil {
		return Completion{}, false
	}
	return *e.done, true
}

// ConsumeCompletion is called only after the external response sink accepts
// the completion. A failed send must leave the entry/slot occupied.
func (w *Walker) ConsumeCompletion(now uint64, id string) error {
	if err := w.checkTime(now); err != nil {
		return err
	}
	e := w.firstCompletion()
	if e == nil || e.state.Request.ID != id {
		return errors.New("completion is absent or out of order")
	}
	w.now = now
	w.stats.CompletionWaitCycles += now - e.done.ReadyCycle
	delete(w.ids, id)
	for i := range w.active {
		if w.active[i].entry == e {
			w.active[i].entry = nil
			return nil
		}
	}
	for i, candidate := range w.buffer {
		if candidate == e {
			copy(w.buffer[i:], w.buffer[i+1:])
			w.buffer[len(w.buffer)-1] = nil
			w.buffer = w.buffer[:len(w.buffer)-1]
			return nil
		}
	}
	return fmt.Errorf("completed request %s lost its storage", id)
}

func (w *Walker) Buffered() []BufferedRequest {
	out := make([]BufferedRequest, len(w.buffer))
	for i, e := range w.buffer {
		out[i] = e.state
	}
	return out
}

func (w *Walker) Active() []ActiveWalk {
	out := make([]ActiveWalk, len(w.active))
	for i, a := range w.active {
		out[i].Walker = i
		if a.entry != nil {
			out[i] = ActiveWalk{Valid: true, Inflight: a.inflight && a.entry.done == nil,
				Completed: a.entry.done != nil, Walker: i, CurrentLevel: a.level, Request: a.entry.state.Request, NodeAddress: a.node}
		}
	}
	return out
}

func (w *Walker) Snapshot() Stats { return w.stats }
