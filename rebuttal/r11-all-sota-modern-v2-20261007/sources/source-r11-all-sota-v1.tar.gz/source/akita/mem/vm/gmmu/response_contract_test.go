package gmmu

import (
	"fmt"
	"reflect"
	"strings"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

func responseFixture(t *testing.T, demandOnly bool, mapped []int) (*GMMU, vm.PageTable) {
	t.Helper()
	translationtrace.Configure(false, "", 100000)
	t.Cleanup(func() { translationtrace.Configure(false, "", 100000) })
	pt := vm.NewPageTable(12)
	for _, bit := range mapped {
		for _, pid := range []vm.PID{1, 2} {
			pt.Insert(vm.Page{PID: pid, VAddr: uint64(bit) * 4096, PAddr: uint64(pid)*0x100000 + uint64(bit)*4096,
				PageSize: 4096, Valid: true, DeviceID: 1})
		}
	}
	m := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithPageTable(pt).WithDemandPTEOnly(demandOnly).Build("ResponseContract")
	return m, pt
}

func TestPageWalkResponsesPreserveDenseOrderAndSparseDemands(t *testing.T) {
	cases := []struct {
		name       string
		demandOnly bool
		mapped     []int
		bitmap     [8]bool
		address    uint64
		want       []int
	}{
		{"dense-plain", false, []int{0, 1, 2, 3, 4, 5, 6, 7}, [8]bool{}, 4096, []int{1, 0, 1, 2, 3, 4, 5, 6, 7}},
		{"dense-bitmap", false, []int{0, 1, 2, 3, 4, 5, 6, 7}, [8]bool{2: true, 4: true}, 0, []int{0, 0, 1, 2, 3, 4, 5, 6, 7}},
		{"formal-bitmap20", false, []int{2, 4}, [8]bool{2: true, 4: true}, 0, []int{2, 2, 4}},
		{"formal-bitmap224", false, []int{5, 6, 7}, [8]bool{5: true, 6: true, 7: true}, 0, []int{5, 5, 6, 7}},
		{"only-one-mapped", false, []int{3}, [8]bool{3: true}, 0, []int{3, 3}},
		{"demand-plain", true, []int{1}, [8]bool{}, 4096, []int{1}},
		{"demand-bitmap", true, []int{3}, [8]bool{3: true}, 0, []int{3}},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			m, pt := responseFixture(t, c.demandOnly, c.mapped)
			for _, pid := range []vm.PID{1, 2} {
				r := vm.TranslationReqBuilder{}.WithPID(pid).WithVAddr(c.address).WithBitMap(c.bitmap).Build()
				pages := m.pageWalkResponses(r)
				var bits []int
				for _, page := range pages {
					want, found := pt.Find(pid, page.VAddr)
					if !found || !page.Valid || page != want {
						t.Fatal("unmapped/fabricated/cross-PID page in response batch")
					}
					bits = append(bits, int(page.VAddr/4096))
				}
				if !reflect.DeepEqual(bits, c.want) {
					t.Fatalf("wrong response order: got %v want %v", bits, c.want)
				}
				if r.VAddr != c.address || r.BitMap != c.bitmap {
					t.Fatal("response preparation mutated original request")
				}
			}
		})
	}
}

func TestResponseBatchRetainsWalkerUntilAllRepliesFit(t *testing.T) {
	for _, dense := range []bool{false, true} {
		t.Run(fmt.Sprint(dense), func(t *testing.T) {
			mapped, wantCount := []int{2, 4}, 3
			if dense {
				mapped, wantCount = []int{0, 1, 2, 3, 4, 5, 6, 7}, 9
			}
			m, pt := responseFixture(t, false, mapped)
			buffer := sim.NewBuffer("ResponseContract.BoundedReplies", 9)
			m.topSender = sim.NewBufferedSender(m.topPort, buffer)
			source := sim.NewLimitNumMsgPort(nil, 16, "ResponseContract.Requester")
			r := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(0).WithBitMap([8]bool{2: true, 4: true}).
				WithSrc(source).WithDst(m.topPort).WithOriginPort(source).WithTaskID("original-demand").Build()
			m.startWalking(r, 0)
			fill := 10 - wantCount
			for i := 0; i < fill; i++ {
				buffer.Push(vm.TranslationRspBuilder{}.Build())
			}
			for i := 0; i < 3; i++ {
				if m.walkPageTable(sim.VTimeInSec(i)*1e-9) || buffer.Size() != fill || m.PTWInflight() != 1 {
					t.Fatal("partial response escaped or walker retired while batch did not fit")
				}
			}
			for buffer.Size() > 0 {
				buffer.Pop()
			}
			if !m.walkPageTable(4e-9) || buffer.Size() != wantCount || m.PTWInflight() != 0 {
				t.Fatal("whole batch did not retire after space became available")
			}
			if m.walkPageTable(5e-9) || buffer.Size() != wantCount {
				t.Fatal("retired walker duplicated the response batch")
			}
			for i := 0; buffer.Size() > 0; i++ {
				rsp := buffer.Pop().(*vm.TranslationRsp)
				page, found := pt.Find(1, rsp.Page.VAddr)
				if !found || rsp.Page != page || rsp.RespondTo != r.ID || rsp.Dst != source || rsp.Src != m.topPort ||
					rsp.OriginPort != source || (i == 0 && rsp.TaskID != r.TaskID) {
					t.Fatal("batch lost original routing or mapping")
				}
			}
			t.Logf("GMMU_RESPONSE dense=%v batch_messages=%d backpressure_retries=3 retired_once=true", dense, wantCount)
		})
	}
}

func TestUnmappedDemandFailsBeforeAnySuccessResponse(t *testing.T) {
	for _, invalidPage := range []bool{false, true} {
		t.Run(fmt.Sprint(invalidPage), func(t *testing.T) {
			m, pt := responseFixture(t, false, []int{2})
			if invalidPage {
				pt.Insert(vm.Page{PID: 1, VAddr: 4 * 4096, PageSize: 4096, Valid: false})
			}
			buffer := sim.NewBuffer("ResponseContract.FaultBuffer", 16)
			m.topSender = sim.NewBufferedSender(m.topPort, buffer)
			r := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(0).WithBitMap([8]bool{2: true, 4: true}).Build()
			m.startWalking(r, 0)
			defer func() {
				err := recover()
				if err == nil || !strings.Contains(fmt.Sprint(err), "unsupported unmapped demand") || buffer.Size() != 0 || m.PTWInflight() != 1 {
					t.Fatal("faulting demand was accepted or partially returned")
				}
			}()
			m.walkPageTable(1e-9)
		})
	}
	for _, demandOnly := range []bool{false, true} {
		t.Run(fmt.Sprintf("plain/%v", demandOnly), func(t *testing.T) {
			m, _ := responseFixture(t, demandOnly, nil)
			defer func() {
				if recover() == nil {
					t.Fatal("ordinary unmapped demand accepted")
				}
			}()
			m.pageWalkResponses(vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(4096).Build())
		})
	}
}

func TestDemandOnlyRejectsMultiSectorPacket(t *testing.T) {
	m, _ := responseFixture(t, true, []int{2, 4})
	defer func() {
		if recover() == nil {
			t.Fatal("demand-only local walker silently lost a sector")
		}
	}()
	m.pageWalkResponses(vm.TranslationReqBuilder{}.WithPID(1).WithBitMap([8]bool{2: true, 4: true}).Build())
}
