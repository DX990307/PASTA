package mmu

import (
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
)

func TestWalkObservationCopiesStateWithoutChangingService(t *testing.T) {
	translationtrace.Configure(false, "", 100000)
	m := MakeBuilder().WithFixedWalkLatency(500).WithWalkCoalescing(false).Build("ObservedMMU")
	req := vm.TranslationReqBuilder{}.WithPID(7).WithVAddr(0x1000).WithTaskID("logical-request").Build()
	m.startWalking(req, 400, 0)
	m.PWqueue = append(m.PWqueue, PWqueue{req: req})
	m.mockBuffer = append(m.mockBuffer, req)
	before := append([]transaction(nil), m.walkingTranslations...)
	walks, queued, backlog := m.ObserveWalks()
	if len(walks) != 1 || queued != 1 || backlog != 1 || walks[0].RequestID != req.ID ||
		walks[0].TaskID != req.TaskID || walks[0].PID != 7 || walks[0].VAddr != 0x1000 || walks[0].CyclesLeft != 500 {
		t.Fatal("wrong walker snapshot")
	}
	walks[0].CyclesLeft = 0
	walks[0].TaskID = "changed-copy"
	if !reflect.DeepEqual(before, m.walkingTranslations) || len(m.PWqueue) != 1 || len(m.mockBuffer) != 1 {
		t.Fatal("observation exposed mutable walker state")
	}
	m.walkPageTable(0)
	next, _, _ := m.ObserveWalks()
	if next[0].CyclesLeft != 499 || next[0].TaskID != req.TaskID {
		t.Fatal("observation changed subsequent countdown")
	}
}
