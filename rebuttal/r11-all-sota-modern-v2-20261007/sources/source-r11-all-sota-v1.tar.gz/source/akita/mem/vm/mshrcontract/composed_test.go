package mshrcontract_test

import (
	"fmt"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/downstreamstats"
	"github.com/sarchlab/akita/v3/mem/vm/mmu"
	"github.com/sarchlab/akita/v3/mem/vm/mmuCache"
	"github.com/sarchlab/akita/v3/mem/vm/mmuTLB"
	"github.com/sarchlab/akita/v3/mem/vm/tlb_gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

type scheduledDemand struct {
	cycle uint64
	req   *vm.TranslationReq
}

type demandClient struct {
	*sim.TickingComponent
	t                             *testing.T
	port                          sim.Port
	pt                            vm.PageTable
	requests                      []scheduledDemand
	completed                     map[string]bool
	next, sendFailures            int
	heldResponseCycles, lastCycle uint64
}

func (c *demandClient) Tick(now sim.VTimeInSec) bool {
	cycle := c.Freq.Cycle(now)
	if cycle > 12000 {
		c.t.Fatalf("composed MSHR flow timed out: %s sent=%d returned=%d", c.Name(), c.next, len(c.completed))
	}
	for c.next < len(c.requests) && c.requests[c.next].cycle <= cycle {
		r := c.requests[c.next].req
		r.SendTime = now
		if c.port.Send(r) != nil {
			c.sendFailures++
			break
		}
		c.next++
	}
	if c.port.Peek() != nil && cycle < 1500 {
		c.heldResponseCycles++
	}
	if cycle >= 1500 {
		if msg := c.port.Retrieve(now); msg != nil {
			rsp := msg.(*vm.TranslationRsp)
			var original *vm.TranslationReq
			for _, item := range c.requests {
				if item.req.ID == rsp.RespondTo {
					original = item.req
				}
			}
			if original == nil || c.completed[rsp.RespondTo] {
				c.t.Fatal("lost or duplicated original requester identity")
			}
			page, found := c.pt.Find(original.PID, original.VAddr)
			if !found || rsp.Page != page || rsp.Dst != original.Src || rsp.Src != original.Dst ||
				rsp.TaskID != original.TaskID || rsp.OriginPort != original.OriginPort {
				c.t.Fatal("response crossed source, task, address space, or mapping")
			}
			c.completed[rsp.RespondTo] = true
		}
	}
	c.lastCycle = cycle
	return len(c.completed) != len(c.requests)
}

type demandWireHook struct {
	t                   *testing.T
	pt                  vm.PageTable
	requests, responses int
	pages               map[[2]uint64]int
}

func (h *demandWireHook) Func(ctx sim.HookCtx) {
	if ctx.Pos != sim.HookPosPortMsgSend {
		return
	}
	switch msg := ctx.Item.(type) {
	case *vm.TranslationReq:
		count, bit := 0, 0
		for i, needed := range msg.BitMap {
			if needed {
				count++
				bit = i
			}
		}
		address := (msg.VAddr &^ uint64(32767)) + uint64(bit)*4096
		page, found := h.pt.Find(msg.PID, address)
		if count != 1 || !found || !page.Valid || msg.IsPrefetch {
			h.t.Fatalf("non-demand or lost-sector packet: pid=%d va=%d bitmap=%v", msg.PID, msg.VAddr, msg.BitMap)
		}
		h.pages[[2]uint64{uint64(msg.PID), address}]++
		h.requests++
	case *vm.TranslationRsp:
		page, found := h.pt.Find(msg.Page.PID, msg.Page.VAddr)
		if !found || msg.Page != page {
			h.t.Fatal("fabricated or nonpresent physical response")
		}
		h.responses++
	}
}

func TestComposedDemandMSHRControls(t *testing.T) {
	for _, limited := range []bool{false, true} {
		for _, l2Coalescing := range []bool{false, true} {
			for _, ioCoalescing := range []bool{false, true} {
				name := fmt.Sprintf("limited=%v/l2=%v/iotlb=%v", limited, l2Coalescing, ioCoalescing)
				t.Run(name, func(t *testing.T) { runDemandContract(t, limited, l2Coalescing, ioCoalescing) })
			}
		}
	}
}

func runDemandContract(t *testing.T, limited, l2Coalescing, ioCoalescing bool) {
	translationtrace.Configure(false, "", 100000)
	t.Cleanup(func() { translationtrace.Configure(false, "", 100000) })
	engine := sim.NewSerialEngine()
	pt := vm.NewPageTable(12)
	for _, spec := range []struct {
		pid vm.PID
		bit uint64
	}{{1, 1}, {1, 3}, {1, 7}, {1, 9}, {2, 3}} {
		pt.Insert(vm.Page{Valid: true, PID: spec.pid, VAddr: spec.bit * 4096,
			PAddr: uint64(spec.pid)*0x100000 + spec.bit*4096, PageSize: 4096, DeviceID: 3})
	}
	l2Capacity, ioCapacity := 16, 64
	if limited {
		l2Capacity, ioCapacity = 1, 1
	}
	walker := mmu.MakeBuilder().WithEngine(engine).WithPageTable(pt).WithLog2PageSize(12).
		WithMaxNumReqInFlight(16).WithFixedWalkLatency(500).WithPageWalkingLatency(500).
		WithWalkCoalescing(false).WithDemandPTEOnly(true).Build("Contract.MMU")
	upper := mmuCache.MakeBuilder().WithEngine(engine).WithNumWays(1).WithNumSets(32).
		WithNumMSHREntry(64).WithMSHREntryDepth(64).WithNumReqPerCycle(256).
		WithLog2PageSize(12).WithLowModule(walker.GetPortByName("Top")).Build("Contract.Upper")
	iotlb := mmuTLB.MakeBuilder().WithEngine(engine).WithNumSets(64).WithNumWays(32).
		WithNumMSHREntry(ioCapacity).WithMSHREntryDepth(64).WithNumReqPerCycle(32).
		WithPageSize(4096).WithLog2PageSize(12).WithPageTable(pt).WithSetAsLineTLB(false).
		WithPerVPNMSHRBaseline(!ioCoalescing).WithDemandPTEOnly(true).
		WithLookupLatencyCycles(80).WithLowModule(upper.GetPortByName("Top")).Build("Contract.IOTLB")
	upper.UpModule, walker.TopModule = iotlb.GetPortByName("Bottom"), upper.GetPortByName("Bottom")
	connect := func(name string, ports ...sim.Port) {
		c := sim.NewDirectConnection(name, engine, sim.GHz)
		for _, p := range ports {
			c.PlugIn(p, 1)
		}
	}
	connect("Contract.UpperLink", iotlb.GetPortByName("Bottom"), upper.GetPortByName("Top"))
	connect("Contract.WalkLink", upper.GetPortByName("Bottom"), walker.GetPortByName("Top"))
	newHook := func(port sim.Port) *demandWireHook {
		h := &demandWireHook{t: t, pt: pt, pages: make(map[[2]uint64]int)}
		port.AcceptHook(h)
		return h
	}
	iowire, walkwire, returnwire := newHook(iotlb.GetPortByName("Bottom")), newHook(upper.GetPortByName("Bottom")), newHook(walker.GetPortByName("Top"))
	var caches []*tlb_gmmu.GMMUTLB
	var observers []*downstreamstats.Observer
	var clients []*demandClient
	sharedPorts := []sim.Port{iotlb.GetPortByName("Top")}
	for index := 0; index < 2; index++ {
		name := fmt.Sprintf("Contract.GPM%d", index+1)
		l2 := tlb_gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(uint64(index+1)).WithPageTable(pt).
			WithNumSets(16).WithNumWays(16).WithNumReqPerCycle(128).WithNumMSHREntry(l2Capacity).
			WithLog2PageSize(12).WithPageSize(4096).WithPTELookupSlots(8).WithPTELookupLatencyCycles(32).
			WithPTCLLineSize(8).WithFlexTLB(false).WithPerVPNMSHRBaseline(!l2Coalescing).
			WithInitialPTCLMode(true).WithPTCLModeThresholds(0, 0).WithIdleIOMMUAssist(false).
			WithIOMMUPort(iotlb.GetPortByName("Top")).Build(name + ".L2")
		caches = append(caches, l2)
		outside := l2.OutsidePort
		sharedPorts = append(sharedPorts, outside)
		o := downstreamstats.New(engine, 12, sim.GHz)
		outside.AcceptHook(o.Hook(outside, false))
		observers = append(observers, o)
		newHook(outside)
		c := &demandClient{t: t, pt: pt, completed: make(map[string]bool)}
		c.TickingComponent = sim.NewTickingComponent(name+".Client", engine, sim.GHz, c)
		c.port = sim.NewLimitNumMsgPort(c, 1, name+".Client.Port")
		c.AddPort("Port", c.port)
		connect(name+".SourceLink", c.port, l2.GetPortByName("Top"))
		for n, spec := range []struct {
			cycle uint64
			pid   vm.PID
			bit   uint64
		}{{0, 1, 1}, {0, 1, 3}, {0, 1, 1}, {0, 2, 3}, {180, 1, 7}, {2500, 1, 9}, {4000, 1, 1}} {
			r := vm.TranslationReqBuilder{}.WithSrc(c.port).WithDst(l2.GetPortByName("Top")).
				WithPID(spec.pid).WithVAddr(spec.bit * 4096).WithOriginPort(c.port).
				WithDeviceID(uint64(index + 1)).WithTaskID(fmt.Sprintf("%s.request%d", name, n)).Build()
			c.requests = append(c.requests, scheduledDemand{spec.cycle, r})
		}
		clients = append(clients, c)
		c.TickNow(0)
	}
	connect("Contract.SharedLink", sharedPorts...)
	if err := engine.Run(); err != nil {
		t.Fatal(err)
	}
	if !iotlb.DemandPTEOnlyEnabled() || iotlb.VPNMSHRBaselineEnabled() == ioCoalescing || iotlb.LookupLatencyCycles() != 80 {
		t.Fatal("IOTLB control changed")
	}
	line, _, _, _, _, _, fills, _, rows := iotlb.SetAsLineStats()
	if line || fills != 0 || rows != 0 || iotlb.IncomingRequestCount() != 10 || len(iowire.pages) != 5 ||
		iotlb.DownstreamRequestCount() != iowire.requests || iowire.requests != walkwire.requests ||
		walkwire.requests != returnwire.responses {
		t.Fatalf("shared demand path lost work or used line fills: incoming=%d downstream=%d walk=%d returns=%d", iotlb.IncomingRequestCount(), iowire.requests, walkwire.requests, returnwire.responses)
	}
	if !limited && iowire.requests != 5 {
		t.Fatal("overlapping cross-GPM same-VPN requests did not share the five demanded walks")
	}
	for i, l2 := range caches {
		c, s := clients[i], observers[i].Snapshot()
		total, local, outside := l2.DownstreamRequestCounts()
		enabled, issued, _, _ := l2.IdleIOMMUAssistStats()
		toPTCL, toPTE := l2.ModeSwitchCounts()
		peak := 4.0
		if l2Coalescing {
			peak = 2
		}
		if limited {
			peak = 1
		}
		m := l2.MSHRAdmissionStats()
		if len(c.completed) != 7 || c.sendFailures == 0 || c.heldResponseCycles == 0 ||
			total != 5 || outside != 5 || local != 0 || enabled || issued != 0 ||
			l2.PLTStudyStats()["plt_total_rows"] != 0 || l2.PTCLModeEnabled() != l2Coalescing || toPTCL != 0 || toPTE != 0 ||
			m["mshr_entries_peak"] != peak || m["mshr_entries_at_stop"] != 0 ||
			s.Diagnostics != (downstreamstats.Diagnostics{}) || s.Paths["native"].Completed != 5 ||
			s.Paths["native"].Inflight != 0 || s.Ports["outside"].Consumed != 5 {
			t.Fatalf("composed control did not preserve demands: client=%d complete=%d retry=%d held=%d total=%d stats=%+v observation=%+v", i, len(c.completed), c.sendFailures, c.heldResponseCycles, total, m, s)
		}
	}
	t.Logf("MSHR_COMPOSED limited=%v l2_coalescing=%v iotlb_coalescing=%v requests=14 replies=14 l2_issues=10 shared_walks=%d original_mappings_correct=true invalid_responses=0 sparse_unmapped_base=true cycles=%d",
		limited, l2Coalescing, ioCoalescing, walkwire.requests, clients[0].lastCycle)
}
