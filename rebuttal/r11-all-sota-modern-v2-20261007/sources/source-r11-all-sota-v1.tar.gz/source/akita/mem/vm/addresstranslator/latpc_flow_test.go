package addresstranslator

import (
	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
	"testing"
)

func TestLATPCMetadataThroughTranslator(t *testing.T) {
	for _, write := range []bool{false, true} {
		engine := sim.NewSerialEngine()
		source := sim.NewLimitNumMsgPort(nil, 128, "AT.Source")
		lower := sim.NewLimitNumMsgPort(nil, 128, "AT.TLB")
		at := MakeBuilder().WithEngine(engine).WithTranslationProvider(lower).Build("AT")
		link := sim.NewDirectConnection("AT.Link", engine, sim.GHz)
		for _, p := range []sim.Port{source, lower, at.topPort, at.translationPort} {
			link.PlugIn(p, 128)
		}
		info := vm.DetectLATPC([]uint64{8, 10})[1]
		var request sim.Msg
		if write {
			request = mem.WriteReqBuilder{}.WithSrc(source).WithDst(at.topPort).WithAddress((10 << 12) + 32).WithPID(1).WithData([]byte{1}).WithInfo(info).Build()
		} else {
			request = mem.ReadReqBuilder{}.WithSrc(source).WithDst(at.topPort).WithAddress((10 << 12) + 32).WithPID(1).WithByteSize(4).WithInfo(info).Build()
		}
		if source.Send(request) != nil {
			t.Fatal("send failed")
		}
		if err := engine.Run(); err != nil {
			t.Fatal(err)
		}
		msg := lower.Retrieve(engine.CurrentTime())
		req, ok := msg.(*vm.TranslationReq)
		if !ok || req.LATPC != info || req.VAddr != 10<<12 {
			t.Fatal("translator lost metadata or page alignment")
		}
	}
}
