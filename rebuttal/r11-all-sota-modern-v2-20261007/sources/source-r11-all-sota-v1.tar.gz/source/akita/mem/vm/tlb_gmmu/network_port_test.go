package tlb_gmmu

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

type routeTestPort struct {
	sim.Port
	sent   []sim.Msg
	reject bool
}

func (p *routeTestPort) Send(msg sim.Msg) *sim.SendError {
	if p.reject {
		return sim.NewSendError()
	}
	p.sent = append(p.sent, msg)
	return nil
}

type routeTestFreePTW struct{}

func (routeTestFreePTW) HasFreePTW() bool { return true }
func (routeTestFreePTW) PTWInflight() int { return 0 }
func (routeTestFreePTW) PTWCapacity() int { return 16 }

func TestIOMMURequestsUseSourcePortAndItsBackpressure(t *testing.T) {
	for _, test := range []struct {
		name  string
		owner uint64
		force bool
		path  string
	}{
		{"native", 2, false, "native"}, {"assist", 1, false, "assist"}, {"forced", 1, true, "native"},
	} {
		t.Run(test.name, func(t *testing.T) {
			pt := vm.NewPageTable(12)
			pt.Insert(vm.Page{PID: 1, VAddr: 4096, PAddr: 0x100000, PageSize: 4096, Valid: true, DeviceID: test.owner})
			destination := &routeTestPort{Port: sim.NewLimitNumMsgPort(nil, 8, "IOMMU.Top")}
			tlb := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithDeviceID(1).
				WithLog2PageSize(12).WithPageTable(pt).WithIOMMUPort(destination).
				WithIdleIOMMUAssist(true).WithSharedPTWStateProvider(routeTestFreePTW{}).Build("SourceL2")
			source := &routeTestPort{Port: tlb.OutsidePort, reject: true}
			tlb.OutsidePort = source
			req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(4096).Build()
			req.StartGPUID = 7
			bitmap := [8]bool{false, true}
			issue := func() (*vm.TranslationReq, bool) {
				if test.force {
					return tlb.sendDownstreamToIOMMU(0, req, bitmap)
				}
				return tlb.sendDownstream(0, req, bitmap, true)
			}
			if translated, ok := issue(); ok || translated != nil {
				t.Fatal("source backpressure was bypassed")
			}
			if tlb.iommuReqCount != 0 || len(destination.sent) != 0 {
				t.Fatal("rejected request was counted or sent from destination")
			}
			source.reject = false
			translated, ok := issue()
			if !ok || len(source.sent) != 1 || source.sent[0] != translated || len(destination.sent) != 0 {
				t.Fatal("request did not use its own source connection")
			}
			if translated.Src != source || translated.Dst != destination || translated.TracePath != test.path ||
				translated.PID != 1 || translated.VAddr != 4096 || translated.BitMap != bitmap || translated.StartGPUID != 7 {
				t.Fatal("request metadata changed")
			}
			if tlb.iommuReqCount != 1 || (test.path == "assist" && tlb.idleIOMMUAssistIssued != 1) {
				t.Fatal("issue counters incorrect")
			}
		})
	}
}
