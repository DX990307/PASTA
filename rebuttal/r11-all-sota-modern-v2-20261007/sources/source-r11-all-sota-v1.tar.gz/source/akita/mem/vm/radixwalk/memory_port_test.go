package radixwalk

import (
	"encoding/binary"
	"testing"

	"github.com/sarchlab/akita/v3/mem/idealmemcontroller"
	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/sim"
)

type memoryClient struct {
	*sim.TickingComponent
	t           *testing.T
	w           *Walker
	bridge      *MemoryPort
	completed   map[string]Completion
	acceptAfter uint64
	maxCycle    uint64
}

func (c *memoryClient) Tick(now sim.VTimeInSec) bool {
	cycle := c.Freq.Cycle(now)
	if cycle > 10000 {
		c.t.Fatal("memory-port component sequence timed out")
	}
	_, err := c.bridge.Receive(now)
	ok(c.t, err)
	if cycle >= c.acceptAfter {
		if done, ready := c.w.PeekCompletion(); ready {
			if _, duplicate := c.completed[done.Request.ID]; duplicate {
				c.t.Fatal("duplicate result")
			}
			c.completed[done.Request.ID] = done
			ok(c.t, c.w.ConsumeCompletion(cycle, done.Request.ID))
		}
	}
	ok(c.t, c.w.Schedule(cycle))
	_, err = c.bridge.Issue(now)
	ok(c.t, err)
	// Repeated calls cannot multiply the physical interface width.
	_, err = c.bridge.Issue(now)
	ok(c.t, err)
	c.maxCycle = cycle
	return len(c.w.ids) > 0
}

func TestActualReadPortUsesCachelineBytesAndBackpressure(t *testing.T) {
	for _, neighbor := range []bool{false, true} {
		c := fullConfig()
		c.Walkers = 4
		c.LeafCoalescing = neighbor
		c.UpperCoalescing = neighbor
		c.AwareScheduling = neighbor
		engine := sim.NewSerialEngine()
		w := newWalker(t, c)
		m := memory(4)
		for i, va := range []uint64{0, 4096, 8192, 3 * 4096} {
			r := request(string(rune('a'+i)), va)
			enqueue(t, w, r)
			m.mapPage(r.Root, va, 0x900000+va)
		}
		storage := mem.NewStorage(16 * mem.MB)
		for address, page := range m.pages {
			data := make([]byte, 4096)
			for i, pte := range page {
				binary.LittleEndian.PutUint64(data[i*8:(i+1)*8], pte)
			}
			ok(t, storage.Write(address, data))
		}
		backend := idealmemcontroller.MakeBuilder().WithEngine(engine).WithStorage(storage).
			WithLatency(11).WithWidth(1).WithTopBufSize(1).Build("RadixBackend")
		client := &memoryClient{t: t, w: w, completed: make(map[string]Completion), acceptAfter: 100}
		client.TickingComponent = sim.NewTickingComponent("RadixClient", engine, sim.GHz, client)
		port := sim.NewLimitNumMsgPort(client, 1, "RadixClient.Memory")
		client.AddPort("Memory", port)
		connection := sim.NewDirectConnection("RadixLink", engine, sim.GHz)
		connection.PlugIn(port, 1)
		connection.PlugIn(backend.GetPortByName("Top"), 1)
		low := &mem.SingleLowModuleFinder{LowModule: backend.GetPortByName("Top")}
		var err error
		client.bridge, err = NewMemoryPort(w, port, low, sim.GHz, 2)
		ok(t, err)
		client.TickNow(0)
		ok(t, engine.Run())
		if len(client.completed) != 4 || len(client.bridge.inflight) != 0 || len(client.bridge.pending) != 0 {
			t.Fatal("memory port did not drain")
		}
		for _, done := range client.completed {
			if done.Fault != NoFault || done.PAddr != 0x900000+done.Request.VAddr {
				t.Fatal("memory read returned wrong PTE")
			}
		}
		want := uint64(16)
		if neighbor {
			want = 4
		}
		s := client.bridge.Snapshot()
		if s.ReadRequests != want || s.ReadResponses != want || s.ReturnedDataBytes != 64*want ||
			s.DeclaredRequestBytes != 12*want || s.DeclaredResponseBytes != 68*want {
			t.Fatalf("wrong actual memory traffic: %+v", s)
		}
		if !neighbor && s.SendFailures == 0 {
			t.Fatal("sequence failed to exercise real send backpressure")
		}
		if w.Snapshot().CompletionWaitCycles == 0 {
			t.Fatal("response sink backpressure not retained")
		}
		t.Logf("RADIX_MEMORY neighbor=%v reads=%d data_bytes=%d request_declared_bytes=%d response_declared_bytes=%d send_failures=%d cycles=%d",
			neighbor, s.ReadRequests, s.ReturnedDataBytes, s.DeclaredRequestBytes, s.DeclaredResponseBytes, s.SendFailures, client.maxCycle)
	}
}

type recordingMemoryPort struct {
	sim.Port
	messages []sim.Msg
	reject   bool
}

func (p *recordingMemoryPort) Send(msg sim.Msg) *sim.SendError {
	p.messages = append(p.messages, msg)
	if p.reject {
		return sim.NewSendError()
	}
	return nil
}

func TestMemoryPortRejectsBadDataAndPreservesRetryIdentity(t *testing.T) {
	w := newWalker(t, fullConfig())
	enqueue(t, w, request("a", 0))
	ok(t, w.Schedule(0))
	p := &recordingMemoryPort{Port: sim.NewLimitNumMsgPort(nil, 4, "MemoryPort"), reject: true}
	dst := sim.NewLimitNumMsgPort(nil, 4, "MemoryDestination")
	b, err := NewMemoryPort(w, p, &mem.SingleLowModuleFinder{LowModule: dst}, sim.GHz, 1)
	ok(t, err)
	_, err = b.Issue(0)
	ok(t, err)
	if b.Snapshot().ReadRequests != 0 || w.Snapshot().MemoryAccesses[4] != 0 {
		t.Fatal("rejected issue advanced walker")
	}
	p.reject = false
	_, err = b.Issue(1e-9)
	ok(t, err)
	if len(p.messages) != 2 || p.messages[0] != p.messages[1] {
		t.Fatal("retry changed request identity")
	}
	r := p.messages[1].(*mem.ReadReq)
	bad := mem.DataReadyRspBuilder{}.WithSrc(dst).WithDst(p).WithRspTo(r.ID).WithData(make([]byte, 8)).Build()
	if p.Recv(bad) != nil {
		t.Fatal("fixture port unexpectedly full")
	}
	if _, err = b.Receive(2e-9); err == nil || p.Peek() != bad || w.Snapshot().CachelineReturns[4] != 0 {
		t.Fatal("malformed response consumed or decoded")
	}
	p.Retrieve(2e-9)
	data := make([]byte, 64)
	binary.LittleEndian.PutUint64(data, 0x2000|7)
	good := mem.DataReadyRspBuilder{}.WithSrc(dst).WithDst(p).WithRspTo(r.ID).WithData(data).Build()
	p.Recv(good)
	_, err = b.Receive(3e-9)
	ok(t, err)
	if a := onlyAccess(t, w); a.Level != 3 || a.NodeAddress != 0x2000 {
		t.Fatal("PTE bytes did not drive next address")
	}
	p.Recv(good)
	if _, err = b.Receive(4e-9); err == nil {
		t.Fatal("duplicate physical response accepted")
	}
}
