package downstreamstats_test

import (
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/downstreamstats"
	"github.com/sarchlab/akita/v3/mem/vm/gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/tlb_gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

type localOutcome struct {
	Page              vm.Page
	Returned, Drained sim.VTimeInSec
	Responses         int
}

// This executes real GMMU/L2 ports and the event engine, including the existing
// demand-plus-eight response protocol. It is not a reduced GPU benchmark.
func TestActualLocalGMMUResponsePopulationAndNoninterference(t *testing.T) {
	for _, demandOnly := range []bool{false, true} {
		var outcomes [2]localOutcome
		for observed := 0; observed < 2; observed++ {
			translationtrace.Configure(false, "", 100)
			engine := sim.NewSerialEngine()
			pt := vm.NewPageTable(12)
			for bit := uint64(0); bit < 8; bit++ {
				pt.Insert(vm.Page{Valid: true, PID: 1, VAddr: bit * 4096, PAddr: 0x100000 + bit*4096, PageSize: 4096, DeviceID: 1})
			}
			local := gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(1).WithPageTable(pt).
				WithMaxNumReqInFlight(4).WithPageWalkingLatency(500).WithDemandPTEOnly(demandOnly).Build("LocalFlow.GMMU")
			l2 := tlb_gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(1).WithPageTable(pt).
				WithNumSets(16).WithNumWays(16).WithNumReqPerCycle(128).WithNumMSHREntry(16).
				WithLog2PageSize(12).WithPageSize(4096).WithPTELookupSlots(8).WithPTELookupLatencyCycles(32).
				WithPTCLLineSize(8).WithFlexTLB(true).WithInitialPTCLMode(true).
				WithLowModule(local.GetPortByName("Top")).Build("LocalFlow.L2")
			bottom, top := l2.GetPortByName("Bottom"), l2.GetPortByName("Top")
			c := sim.NewDirectConnection("LocalFlow.WalkLink", engine, sim.GHz)
			c.PlugIn(bottom, 640)
			c.PlugIn(local.GetPortByName("Top"), 640)
			source := sim.NewLimitNumMsgPort(nil, 16, "LocalFlow.Source")
			up := sim.NewDirectConnection("LocalFlow.SourceLink", engine, sim.GHz)
			up.PlugIn(source, 16)
			up.PlugIn(top, 64)
			stats := downstreamstats.New(engine, 12, sim.GHz)
			if observed == 1 {
				bottom.AcceptHook(stats.Hook(bottom, true))
			}
			req := vm.TranslationReqBuilder{}.WithSrc(source).WithDst(top).WithPID(1).WithVAddr(0).
				WithOriginPort(source).WithTaskID("local-demand").Build()
			if source.Send(req) != nil {
				t.Fatal("initial send rejected")
			}
			if err := engine.Run(); err != nil {
				t.Fatal(err)
			}
			outcomes[observed].Drained = engine.CurrentTime()
			for msg := source.Retrieve(engine.CurrentTime()); msg != nil; msg = source.Retrieve(engine.CurrentTime()) {
				rsp := msg.(*vm.TranslationRsp)
				if rsp.RespondTo != req.ID {
					t.Fatal("incorrect original response ID")
				}
				outcomes[observed].Page, outcomes[observed].Returned = rsp.Page, rsp.RecvTime
				outcomes[observed].Responses++
			}
			if outcomes[observed].Responses != 1 {
				t.Fatal("original demand returned incorrectly")
			}
			if observed == 1 {
				s := stats.Snapshot()
				count := s.Paths["local"]
				wantMessages := uint64(9)
				if demandOnly {
					wantMessages = 1
				}
				if count.Started != 1 || count.Completed != 1 || count.Inflight != 0 || count.ExpectedPages != 1 ||
					s.Ports["local"].Received != wantMessages || s.Ports["local"].Consumed != wantMessages ||
					s.Diagnostics.InvalidIssue != 0 || s.Diagnostics.InvalidResponse != 0 || s.Diagnostics.InvalidTime != 0 {
					t.Fatalf("wrong actual GMMU response population (demand-only=%v): %+v", demandOnly, s)
				}
				t.Logf("R6_LOCAL_RETURN demand_only=%v physical_requests=%d raw_return_messages=%d completed=%d diagnostics=%+v",
					demandOnly, count.Started, s.Ports["local"].Received, count.Completed, s.Diagnostics)
			}
		}
		if !reflect.DeepEqual(outcomes[0], outcomes[1]) {
			t.Fatal("observer changed real event-engine return/drain times or page")
		}
	}
}
