package gmmu

import (
	"log"
	"reflect"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

type transaction struct {
	req           *vm.TranslationReq
	page          vm.Page
	cycleLeft     int
	migration     *vm.PageMigrationReqToDriver
	latpcBatch    *vm.LATPCBatch
	transFWRemote bool
}

// gmmu is the default gmmu implementation. It is also an akita Component.
type GMMU struct {
	sim.TickingComponent

	deviceID uint64

	topPort    sim.Port
	bottomPort sim.Port

	LowModule sim.Port

	log2PageSize uint64

	MigrationServiceProvider sim.Port

	topSender    sim.BufferedSender
	bottomSender sim.BufferedSender

	pageTable           vm.PageTable
	latency             int
	maxRequestsInFlight int

	walkingTranslations []transaction
	remoteMemReqs       map[uint64]transaction

	toRemoveFromPTW        []int
	PageAccessedByDeviceID map[uint64][]uint64

	isRecording     bool
	gpuIDList       []uint64
	isPrediction    bool
	demandPTEOnly   bool
	latpcEnabled    bool
	latpcMerged     uint64
	simpleSOTA      SimpleSOTAConfig
	simpleSOTAStats SimpleSOTAStats
}

func (g *GMMU) LATPCStats() (bool, uint64) { return g.latpcEnabled, g.latpcMerged }

func (g *GMMU) mergeLATPC(now sim.VTimeInSec, req *vm.TranslationReq) bool {
	if !g.latpcEnabled {
		return false
	}
	for i := range g.walkingTranslations {
		t := &g.walkingTranslations[i]
		if !t.latpcBatch.Add(req) {
			continue
		}
		t.cycleLeft++
		g.latpcMerged++
		if !req.IsPrefetch {
			translationtrace.EndStage(req.ID, "local_gmmu_ptw_queue_wait", now)
			translationtrace.AddStageCycles(req.ID, "local_gmmu_ptw_service", uint64(t.cycleLeft))
		}
		tracing.TraceReqReceive(req, g)
		return true
	}
	return false
}

func (gmmu *GMMU) HasFreePTW() bool {
	return len(gmmu.walkingTranslations) < gmmu.effectivePTWCapacity()
}

func (gmmu *GMMU) PTWInflight() int {
	return len(gmmu.walkingTranslations)
}

func (gmmu *GMMU) PTWCapacity() int {
	return gmmu.effectivePTWCapacity()
}

// Tick defines how the gmmu update state each cycle
func (gmmu *GMMU) Tick(now sim.VTimeInSec) bool {
	madeProgress := false

	for i := 0; i < 8; i++ {
		madeProgress = gmmu.topSender.Tick(now) || madeProgress
	}
	madeProgress = gmmu.parseFromTop(now) || madeProgress
	madeProgress = gmmu.walkPageTable(now) || madeProgress
	madeProgress = gmmu.fetchFromBottom(now) || madeProgress

	translationtrace.ObserveLocalGMMU(
		now,
		gmmu.Name(),
		len(gmmu.walkingTranslations),
		gmmu.effectivePTWCapacity(),
		len(gmmu.walkingTranslations) >= gmmu.effectivePTWCapacity(),
	)

	return madeProgress
}

func (gmmu *GMMU) parseFromTop(now sim.VTimeInSec) bool {
	if gmmu.latpcEnabled {
		if req, ok := gmmu.topPort.Peek().(*vm.TranslationReq); ok && gmmu.mergeLATPC(now, req) {
			gmmu.topPort.Retrieve(now)
			return true
		}
	}
	if len(gmmu.walkingTranslations) >= gmmu.effectivePTWCapacity() {
		msg := gmmu.topPort.Peek()
		if req, ok := msg.(*vm.TranslationReq); ok && req != nil && !req.IsPrefetch {
			translationtrace.BeginStage(req.ID, "local_gmmu_ptw_queue_wait", now)
		}
		return false
	}

	req := gmmu.topPort.Retrieve(now)
	if req == nil {
		return false
	}

	tracing.TraceReqReceive(req, gmmu)

	switch req := req.(type) {
	case *vm.TranslationReq:
		if !req.IsPrefetch {
			translationtrace.EndStage(req.ID, "local_gmmu_ptw_queue_wait", now)
		}
		gmmu.startWalking(req, now)
		tracing.StartTask(req.TaskID, "", gmmu, "GMMU", "TranslationReq", req)

	default:
		log.Panicf("gmmu canot handle request of type %s", reflect.TypeOf(req))
	}

	return true
}

func (gmmu *GMMU) startWalking(req *vm.TranslationReq, now sim.VTimeInSec) {
	remote := gmmu.isTransFWRemote(req)
	cycles := gmmu.latency
	if remote {
		cycles = 0
	}
	translationInPipeline := transaction{
		req:           req,
		cycleLeft:     cycles,
		transFWRemote: remote,
	}
	if gmmu.latpcEnabled {
		translationInPipeline.latpcBatch = vm.NewLATPCBatch(req)
	}

	gmmu.walkingTranslations = append(gmmu.walkingTranslations, translationInPipeline)
	gmmu.observeSimpleSOTAStart(uint64(cycles), remote)
	if req != nil && !req.IsPrefetch {
		translationtrace.AddStageCycles(
			req.ID,
			"local_gmmu_ptw_service",
			uint64(cycles),
		)
	}
}

func (gmmu *GMMU) sendReqToBottomPort(now sim.VTimeInSec) {
	lastTranslation := gmmu.walkingTranslations[len(gmmu.walkingTranslations)-1]
	req := lastTranslation.req

	page, _ := gmmu.pageTable.Find(req.PID, req.VAddr)

	if page.DeviceID == gmmu.deviceID {
		return
	}

	gmmu.processRemoteMemReq(now, len(gmmu.walkingTranslations)-1)

	tmp := gmmu.walkingTranslations[:0]
	for i := 0; i < len(gmmu.walkingTranslations); i++ {
		if !gmmu.toRemove(i) {
			tmp = append(tmp, gmmu.walkingTranslations[i])
		}
	}
	gmmu.walkingTranslations = tmp
	gmmu.toRemoveFromPTW = nil
}

func (gmmu *GMMU) walkPageTable(now sim.VTimeInSec) bool {
	madeProgress := false
	for i := 0; i < len(gmmu.walkingTranslations); i++ {
		if gmmu.walkingTranslations[i].cycleLeft > 0 {
			gmmu.walkingTranslations[i].cycleLeft--
			madeProgress = true
			continue
		}
		// req := gmmu.walkingTranslations[i].req

		// page, _ := gmmu.pageTable.Find(req.PID, req.VAddr)

		// if page.DeviceID == gmmu.deviceID {
		if gmmu.walkingTranslations[i].transFWRemote {
			madeProgress = gmmu.processRemoteMemReq(now, i) || madeProgress
		} else {
			madeProgress = gmmu.finalizePageWalk(now, i) || madeProgress
		}
		// } else {
		// 	madeProgress = gmmu.processRemoteMemReq(now, i) || madeProgress
		// }
	}

	tmp := gmmu.walkingTranslations[:0]
	for i := 0; i < len(gmmu.walkingTranslations); i++ {
		if !gmmu.toRemove(i) {
			tmp = append(tmp, gmmu.walkingTranslations[i])
		}
	}
	gmmu.walkingTranslations = tmp
	gmmu.toRemoveFromPTW = nil

	return madeProgress
}

func (gmmu *GMMU) processRemoteMemReq(now sim.VTimeInSec, walkingIndex int) bool {
	walking := gmmu.walkingTranslations[walkingIndex].req

	gmmu.remoteMemReqs[uint64(walking.VAddr)] = gmmu.walkingTranslations[walkingIndex]

	req := vm.TranslationReqBuilder{}.
		WithLATPC(walking.LATPC).
		WithSendTime(now).
		WithSrc(gmmu.bottomPort).
		WithDst(gmmu.LowModule).
		WithPID(walking.PID).
		WithVAddr(walking.VAddr).
		WithDeviceID(walking.DeviceID).
		WithTaskID(walking.TaskID).
		WithOriginPort(walking.OriginPort).
		WithPrefetch(walking.IsPrefetch).
		Build()
	translationtrace.LinkRequest(req.ID, walking.ID)

	err := gmmu.bottomPort.Send(req)

	if err != nil {
		return false
	}

	gmmu.toRemoveFromPTW = append(gmmu.toRemoveFromPTW, walkingIndex)

	return true
}

func (gmmu *GMMU) finalizePageWalk(
	now sim.VTimeInSec,
	walkingIndex int,
) bool {
	req := gmmu.walkingTranslations[walkingIndex].req
	pages := gmmu.pageWalkResponses(req)
	gmmu.walkingTranslations[walkingIndex].page = pages[0]

	return gmmu.doPageWalkHit(now, walkingIndex, pages)
}

func (gmmu *GMMU) pageNeedMigrate(walking transaction) bool {
	if walking.req.DeviceID == walking.page.DeviceID {
		return false
	}

	if !walking.page.Unified {
		return false
	}

	if walking.page.IsPinned {
		return false
	}

	return true
}

func (gmmu *GMMU) doPageWalkHit(
	now sim.VTimeInSec,
	walkingIndex int,
	pages []vm.Page,
) bool {
	// The existing 4096-message buffer must hold the complete (at most nine)
	// response batch before retirement; partial enqueue would lose siblings.
	walking := gmmu.walkingTranslations[walkingIndex]
	var members []*vm.TranslationReq
	var memberPages []vm.Page
	if walking.latpcBatch != nil {
		members = walking.latpcBatch.Members
		for _, req := range members {
			returned := gmmu.pageWalkResponses(req)
			if len(returned) != 1 || returned[0].VAddr>>12 != req.LATPC.VPN {
				panic("LATPC batch returned unexpected VPN")
			}
			memberPages = append(memberPages, returned[0])
		}
	}
	if !gmmu.topSender.CanSend(len(pages) + len(members)) {
		return false
	}
	for i, page := range pages {
		taskID := walking.req.TaskID
		if i > 0 {
			taskID = sim.GetIDGenerator().Generate()
		}
		rsp := vm.TranslationRspBuilder{}.
			WithSendTime(now).
			WithSrc(gmmu.topPort).
			WithDst(walking.req.Src).
			WithRspTo(walking.req.ID).
			WithPage(page).
			WithTaskID(taskID).
			WithOriginPort(walking.req.OriginPort).
			WithPrefetch(walking.req.IsPrefetch).
			Build()
		gmmu.topSender.Send(rsp)
	}
	for i, req := range members {
		gmmu.topSender.Send(vm.TranslationRspBuilder{}.WithSendTime(now).WithSrc(gmmu.topPort).
			WithDst(req.Src).WithRspTo(req.ID).WithPage(memberPages[i]).WithTaskID(req.TaskID).
			WithOriginPort(req.OriginPort).WithPrefetch(req.IsPrefetch).Build())
		tracing.TraceReqComplete(req, gmmu)
	}
	gmmu.toRemoveFromPTW = append(gmmu.toRemoveFromPTW, walkingIndex)
	gmmu.simpleSOTAStats.CompletedWalks++
	tracing.TraceReqComplete(walking.req, gmmu)
	return true
}

func (gmmu *GMMU) toRemove(index int) bool {
	for i := 0; i < len(gmmu.toRemoveFromPTW); i++ {
		remove := gmmu.toRemoveFromPTW[i]
		if remove == index {
			return true
		}
	}
	return false
}

func (gmmu *GMMU) fetchFromBottom(now sim.VTimeInSec) bool {
	if !gmmu.topSender.CanSend(1) {
		return false
	}

	rsp := gmmu.bottomPort.Retrieve(now)
	if rsp == nil {
		return false
	}

	tracing.TraceReqReceive(rsp, gmmu)

	switch rsp := rsp.(type) {
	case *vm.TranslationRsp:
		return gmmu.handleTranslationRsp(now, rsp)
	default:
		log.Panicf("gmmu canot handle request of type %s", reflect.TypeOf(rsp))
	}

	return true
}

func (gmmu *GMMU) handleTranslationRsp(now sim.VTimeInSec, rsponse *vm.TranslationRsp) bool {
	reqTransaction := gmmu.remoteMemReqs[uint64(rsponse.Page.VAddr)]

	rsp := vm.TranslationRspBuilder{}.
		WithSendTime(now).
		WithSrc(gmmu.topPort).
		WithDst(reqTransaction.req.Src).
		WithRspTo(reqTransaction.req.ID).
		WithPage(rsponse.Page).
		WithTaskID(reqTransaction.req.TaskID).
		WithOriginPort(reqTransaction.req.OriginPort).
		WithPrefetch(reqTransaction.req.IsPrefetch || rsponse.IsPrefetch).
		Build()

	gmmu.topSender.Send(rsp)

	delete(gmmu.remoteMemReqs, uint64(rsponse.Page.VAddr))
	gmmu.simpleSOTAStats.CompletedWalks++
	return true
}

func (gmmu *GMMU) GetDeviceID() uint64 {
	return gmmu.deviceID
}

func (gmmu *GMMU) presentPage(pid vm.PID, address uint64) (vm.Page, bool) {
	page, found := gmmu.pageTable.Find(pid, address)
	return page, found && page.Valid && page.PID == pid && page.VAddr == address
}

func (gmmu *GMMU) pageWalkResponses(req *vm.TranslationReq) []vm.Page {
	base := (req.VAddr >> gmmu.log2PageSize) &^ uint64(7)
	var demanded []vm.Page
	for bit, needed := range req.BitMap {
		if !needed {
			continue
		}
		address := (base + uint64(bit)) << gmmu.log2PageSize
		page, present := gmmu.presentPage(req.PID, address)
		if !present {
			log.Panicf("GMMU %s: unsupported unmapped demand pid=%d vaddr=%#x", gmmu.Name(), req.PID, address)
		}
		demanded = append(demanded, page)
	}
	if len(demanded) == 0 {
		page, present := gmmu.presentPage(req.PID, req.VAddr)
		if !present {
			log.Panicf("GMMU %s: unsupported unmapped demand pid=%d vaddr=%#x", gmmu.Name(), req.PID, req.VAddr)
		}
		demanded = append(demanded, page)
	}
	if gmmu.demandPTEOnly {
		if len(demanded) != 1 {
			panic("multi-sector packet on demand-only local GMMU path")
		}
		return demanded
	}
	// Preserve the legacy order for present base pages, including its repeated
	// primary. An unmapped cacheline base is not itself a demanded translation.
	primary, present := gmmu.presentPage(req.PID, req.VAddr)
	if !present {
		primary = demanded[0]
	}
	pages := []vm.Page{primary}
	for _, vpn := range gmmu.getCacheLine(req.VAddr) {
		if page, present := gmmu.presentPage(req.PID, vpn<<gmmu.log2PageSize); present {
			pages = append(pages, page)
		}
	}
	return pages
}

func (gmmu *GMMU) getCacheLine(vaddr uint64) []uint64 {
	currentVPN := vaddr >> gmmu.log2PageSize
	baseVPN := currentVPN &^ 0x7 // 8 entries per cache line
	return []uint64{baseVPN, baseVPN + 1, baseVPN + 2, baseVPN + 3, baseVPN + 4, baseVPN + 5, baseVPN + 6, baseVPN + 7}
}
