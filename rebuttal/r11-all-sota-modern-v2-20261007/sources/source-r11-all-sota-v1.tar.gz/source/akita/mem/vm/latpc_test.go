package vm

import "testing"

func TestLATPCPaperFigure12(t *testing.T) {
	input := []uint64{0x1000, 0x1004, 0x1008, 0x100c, 0x1011, 0x1028, 0x1025, 0x1022}
	stride := []uint16{0, 4, 4, 4, 0, 23, 0, 509}
	index := []uint8{0, 1, 2, 3, 0, 1, 0, 1}
	for n, i := range DetectLATPC(input) {
		if !i.Matches(input[n]) || i.Stride != stride[n] || i.Index != index[n] {
			t.Fatalf("Fig.12 mismatch at %d: %+v", n, i)
		}
	}
}

func TestLATPCBoundaryAndMaskLimit(t *testing.T) {
	var input []uint64
	for n := 0; n < 65; n++ {
		input = append(input, uint64(n))
	}
	for n, i := range DetectLATPC(input) {
		if !i.Matches(input[n]) || i.Index != uint8(n%32) {
			t.Fatalf("mask limit: %+v", i)
		}
	}
	boundary := DetectLATPC([]uint64{510, 511, 512, 513})
	if boundary[2].Index != 0 || boundary[2].BaseVPN != 512 {
		t.Fatal("group crossed 512-page boundary")
	}
}

func TestLATPCBatchPIDStrideAndDuplicate(t *testing.T) {
	infos := DetectLATPC([]uint64{8, 10, 12, 14})
	req := func(n int) *TranslationReq {
		return TranslationReqBuilder{}.WithPID(1).WithVAddr(infos[n].VPN << 12).WithLATPC(infos[n]).Build()
	}
	b := NewLATPCBatch(req(0))
	if !b.Add(req(1)) || !b.Add(req(2)) || b.Add(req(2)) {
		t.Fatal("incorrect group matching")
	}
	other := req(3)
	other.PID = 2
	if b.Add(other) {
		t.Fatal("cross-PID batch")
	}
	if b.Mask != 7 || len(b.Members) != 2 {
		t.Fatal("invalid mask or members")
	}
}
