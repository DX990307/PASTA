package downstreamstats_test

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/downstreamstats"
	"github.com/sarchlab/akita/v3/mem/vm/gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/tlb_gmmu"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

// A multi-bit demand addresses the PTCL base, which need not itself be mapped.
// The historical failing version is retained in the immutable v10 archive.
func TestSparseLocalBitmapReturnsOnlyMappedPages(t *testing.T) {
	translationtrace.Configure(false, "", 100)
	t.Cleanup(func() { translationtrace.Configure(false, "", 100) })
	engine := sim.NewSerialEngine()
	pt := vm.NewPageTable(12)
	for _, address := range []uint64{4096, 8192} {
		pt.Insert(vm.Page{PID: 1, VAddr: address, PAddr: 0x100000 + address,
			PageSize: 4096, Valid: true, DeviceID: 1})
	}
	local := gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(1).WithPageTable(pt).
		WithMaxNumReqInFlight(4).WithPageWalkingLatency(500).WithDemandPTEOnly(false).Build("Sparse.GMMU")
	l2 := tlb_gmmu.MakeBuilder().WithEngine(engine).WithDeviceID(1).WithPageTable(pt).
		WithNumSets(16).WithNumWays(16).WithNumReqPerCycle(128).WithNumMSHREntry(16).
		WithLog2PageSize(12).WithPageSize(4096).WithPTELookupSlots(8).WithPTELookupLatencyCycles(32).
		WithPTCLLineSize(8).WithFlexTLB(true).WithInitialPTCLMode(false).WithPTCLModeThresholds(4, 16).
		WithLowModule(local.GetPortByName("Top")).Build("Sparse.L2")
	bottom, top := l2.GetPortByName("Bottom"), l2.GetPortByName("Top")
	c := sim.NewDirectConnection("Sparse.WalkLink", engine, sim.GHz)
	c.PlugIn(bottom, 640)
	c.PlugIn(local.GetPortByName("Top"), 640)
	source := sim.NewLimitNumMsgPort(nil, 16, "Sparse.Source")
	up := sim.NewDirectConnection("Sparse.SourceLink", engine, sim.GHz)
	up.PlugIn(source, 16)
	up.PlugIn(top, 64)
	stats := downstreamstats.New(engine, 12, sim.GHz)
	bottom.AcceptHook(stats.Hook(bottom, true))
	requests := map[string]uint64{}
	for _, address := range []uint64{4096, 8192} {
		req := vm.TranslationReqBuilder{}.WithSrc(source).WithDst(top).WithPID(1).WithVAddr(address).
			WithOriginPort(source).WithTaskID("sparse-demand").Build()
		requests[req.ID] = address
		if source.Send(req) != nil {
			t.Fatal("initial send rejected")
		}
	}
	if err := engine.Run(); err != nil {
		t.Fatal(err)
	}
	for msg := source.Retrieve(engine.CurrentTime()); msg != nil; msg = source.Retrieve(engine.CurrentTime()) {
		rsp := msg.(*vm.TranslationRsp)
		address, found := requests[rsp.RespondTo]
		page, mapped := pt.Find(1, address)
		if !found || !mapped || rsp.Page != page {
			t.Fatal("original demand did not return its mapped page")
		}
		delete(requests, rsp.RespondTo)
	}
	s := stats.Snapshot()
	if len(requests) != 0 || s.Paths["local"].Started != 1 || s.Paths["local"].Completed != 1 ||
		s.Paths["local"].ExpectedPages != 2 || s.Diagnostics.InvalidResponse != 0 ||
		s.Diagnostics.NonDemandSector != 0 || len(s.RejectedSamples) != 0 || s.Ports["local"].Received != 3 {
		t.Fatalf("sparse-line demands were not correctly completed: %+v", s)
	}
	t.Logf("R6_SPARSE_LOCAL expected_bitmap=6 demanded_pages=2 returned_demands=2 invalid_primary_events=%d raw_returns=%d sparse_response_fixed=true",
		s.Diagnostics.InvalidResponse, s.Ports["local"].Received)
}
