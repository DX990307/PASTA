package radixwalk

import (
	"fmt"
	"math/rand"
	"testing"
)

func TestNonconcurrentRequestsDoNotReuseAnOldReturnedLine(t *testing.T) {
	w := newWalker(t, fullConfig())
	m := memory(4)
	m.mapPage(0x1000, 0, 0x900000)
	m.mapPage(0x1000, 4096, 0x901000)
	for pass := uint64(0); pass < 2; pass++ {
		id := fmt.Sprint(pass)
		base := pass * 5
		ok(t, w.Enqueue(base, request(id, pass*4096)))
		ok(t, w.Schedule(base))
		for level := uint64(0); level < 4; level++ {
			a := onlyAccess(t, w)
			ok(t, w.CommitAccess(base+level, a.Token))
			ok(t, w.Return(base+level+1, m.response(a)))
		}
		done, ready := w.PeekCompletion()
		if !ready || done.Coalesced {
			t.Fatal("nonconcurrent translation coalesced")
		}
		ok(t, w.ConsumeCompletion(base+4, id))
	}
	if w.Snapshot().Started != 2 || w.Snapshot().MemoryAccesses[1] != 2 {
		t.Fatal("old leaf line retained as an undocumented cache")
	}
}

func TestDeterministicDifferentialRequestPopulations(t *testing.T) {
	random := rand.New(rand.NewSource(1725))
	for trial := 0; trial < 100; trial++ {
		c := fullConfig()
		c.Levels = 4 + trial%2
		c.Walkers = 1 + trial%4
		m := memory(c.Levels)
		var reqs []Request
		for i := 0; i < 8; i++ {
			va := uint64(random.Intn(4))*2*1024*1024 + uint64(random.Intn(16))*4096
			root := uint64(0x1000 + random.Intn(2)*4096)
			r := request(fmt.Sprintf("trial%d-req%d", trial, i), va)
			r.Root = root
			r.PID = 1 + root/4096
			r.Generation = uint64(random.Intn(2))
			r.Access = AccessKind(random.Intn(3))
			m.mapPage(root, va, 0x900000+va)
			reqs = append(reqs, r)
		}
		for _, r := range reqs {
			switch random.Intn(8) {
			case 0:
				*m.pte(r.Root, r.VAddr, 1) = 0
			case 1:
				*m.pte(r.Root, r.VAddr, 1) &= ^uint64(2)
			case 2:
				*m.pte(r.Root, r.VAddr, 2) |= uint64(1) << 63
			}
		}
		baseline := c
		baseline.LeafCoalescing = false
		baseline.UpperCoalescing = false
		baseline.AwareScheduling = false
		b := run(t, baseline, reqs, m)
		for _, mode := range []string{"leaf", "full-nosched", "full"} {
			variant := c
			if mode == "leaf" {
				variant.UpperCoalescing = false
			}
			if mode == "full-nosched" {
				variant.AwareScheduling = false
			}
			n := run(t, variant, reqs, m)
			if len(n.accesses) > len(b.accesses) {
				t.Fatalf("trial %d %s added page-table work", trial, mode)
			}
			for _, r := range reqs {
				x, y := b.completions[r.ID], n.completions[r.ID]
				if x.Fault != y.Fault || x.PAddr != y.PAddr || x.Permissions != y.Permissions || x.Request != y.Request {
					t.Fatalf("trial %d %s differs for %s: B=%+v N=%+v", trial, mode, r.ID, x, y)
				}
			}
		}
	}
}
