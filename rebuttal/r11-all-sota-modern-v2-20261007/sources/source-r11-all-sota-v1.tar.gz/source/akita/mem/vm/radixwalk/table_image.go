package radixwalk

import (
	"encoding/binary"
	"errors"
	"fmt"
	"sort"

	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/mem/vm"
)

const tablePageBytes uint64 = 1 << pageShift

// AddressSpace identifies a static root image, not an invalidation protocol.
type AddressSpace struct{ PID, Generation uint64 }

type Mapping struct {
	Space        AddressSpace
	VAddr, PAddr uint64
	Permissions  Permissions
}

type PhysicalRange struct{ Base, Size uint64 }

// TableArena supplies physical page slots already reserved by the caller.
// Pages retains the caller's placement order. ProtectedRanges must include
// non-mapped allocations; mapped data pages are protected automatically.
type TableArena struct {
	MemoryBytes     uint64
	Pages           []uint64
	ProtectedRanges []PhysicalRange
}

type TableImageStats struct {
	AddressSpaces, Mappings  uint64
	NodePagesByLevel         [6]uint64
	UsedBytes, ReservedBytes uint64
	MemoryBytes              uint64
}

// TableImage is an immutable, base-page-only initialization image. It does
// not add timed writes, warm caches, or service translation requests.
type TableImage struct {
	roots     map[AddressSpace]uint64
	pages     map[uint64]*[4096]byte
	addresses []uint64
	stats     TableImageStats
}

func canonicalAddress(va uint64, levels int) bool {
	if levels != 4 && levels != 5 {
		return false
	}
	width := uint(pageShift + 9*levels)
	high := va >> width
	want := uint64(0)
	if (va>>(width-1))&1 != 0 {
		want = (uint64(1) << (64 - width)) - 1
	}
	return high == want
}

func validExtent(base, size, capacity uint64) bool {
	return size > 0 && base < capacity && size <= capacity-base
}

func spaceLess(a, b AddressSpace) bool {
	return a.PID < b.PID || (a.PID == b.PID && a.Generation < b.Generation)
}

// MappingFromVMPage requires explicit permissions because vm.Page has none.
// It rejects invalid/migrating/large pages rather than fabricating a PTE.
func MappingFromVMPage(page vm.Page, generation uint64, permissions Permissions) (Mapping, error) {
	if !page.Valid || page.IsMigrating || page.PageSize != tablePageBytes ||
		page.VAddr%tablePageBytes != 0 || page.PAddr&addressMask != page.PAddr {
		return Mapping{}, errors.New("mapping requires a valid static aligned 4KB page")
	}
	return Mapping{AddressSpace{uint64(page.PID), generation}, page.VAddr, page.PAddr, permissions}, nil
}

// BuildTableImage validates the entire reservation and mapping set before
// returning an image. Input order does not change the image, except for the
// explicit physical slot order. No guest storage is accessed here.
func BuildTableImage(levels int, spaces []AddressSpace, mappings []Mapping, arena TableArena) (*TableImage, error) {
	if (levels != 4 && levels != 5) || len(spaces) == 0 || arena.MemoryBytes == 0 ||
		arena.MemoryBytes > addressMask+tablePageBytes {
		return nil, errors.New("invalid table levels, address spaces, or memory capacity")
	}
	orderedSpaces := append([]AddressSpace(nil), spaces...)
	sort.Slice(orderedSpaces, func(i, j int) bool { return spaceLess(orderedSpaces[i], orderedSpaces[j]) })
	known := make(map[AddressSpace]bool, len(spaces))
	for _, space := range orderedSpaces {
		if known[space] {
			return nil, errors.New("duplicate address space")
		}
		known[space] = true
	}
	reserved := make(map[uint64]bool, len(arena.Pages))
	orderedSlots := append([]uint64(nil), arena.Pages...)
	sort.Slice(orderedSlots, func(i, j int) bool { return orderedSlots[i] < orderedSlots[j] })
	for _, address := range orderedSlots {
		if address&addressMask != address || !validExtent(address, tablePageBytes, arena.MemoryBytes) || reserved[address] {
			return nil, errors.New("invalid, duplicate, or out-of-range table slot")
		}
		reserved[address] = true
	}
	// Binary search avoids scanning every reserved node for each protected span.
	for _, span := range arena.ProtectedRanges {
		if !validExtent(span.Base, span.Size, arena.MemoryBytes) {
			return nil, errors.New("invalid protected physical range")
		}
		first := sort.Search(len(orderedSlots), func(i int) bool { return orderedSlots[i]+tablePageBytes > span.Base })
		if first < len(orderedSlots) && orderedSlots[first] < span.Base+span.Size {
			return nil, errors.New("table reservation overlaps protected physical memory")
		}
	}
	orderedMappings := append([]Mapping(nil), mappings...)
	sort.Slice(orderedMappings, func(i, j int) bool {
		a, b := orderedMappings[i], orderedMappings[j]
		return spaceLess(a.Space, b.Space) || (a.Space == b.Space && a.VAddr < b.VAddr)
	})
	for i, mapping := range orderedMappings {
		if !known[mapping.Space] || !canonicalAddress(mapping.VAddr, levels) || mapping.VAddr%tablePageBytes != 0 ||
			mapping.PAddr&addressMask != mapping.PAddr || !validExtent(mapping.PAddr, tablePageBytes, arena.MemoryBytes) {
			return nil, errors.New("invalid mapping context or address")
		}
		if reserved[mapping.PAddr] {
			return nil, errors.New("table reservation overlaps mapped data page")
		}
		if i > 0 && orderedMappings[i-1].Space == mapping.Space && orderedMappings[i-1].VAddr == mapping.VAddr {
			return nil, errors.New("duplicate virtual mapping")
		}
	}
	image := &TableImage{roots: make(map[AddressSpace]uint64), pages: make(map[uint64]*[4096]byte)}
	image.stats = TableImageStats{AddressSpaces: uint64(len(spaces)), Mappings: uint64(len(mappings)),
		ReservedBytes: uint64(len(arena.Pages)) * tablePageBytes, MemoryBytes: arena.MemoryBytes}
	allocate := func(level int) (uint64, error) {
		if len(image.addresses) == len(arena.Pages) {
			return 0, errors.New("insufficient reserved physical table pages")
		}
		address := arena.Pages[len(image.addresses)]
		image.addresses = append(image.addresses, address)
		image.pages[address] = new([4096]byte)
		image.stats.NodePagesByLevel[level]++
		image.stats.UsedBytes += tablePageBytes
		return address, nil
	}
	for _, space := range orderedSpaces {
		root, err := allocate(levels)
		if err != nil {
			return nil, err
		}
		image.roots[space] = root
	}
	for _, mapping := range orderedMappings {
		address := image.roots[mapping.Space]
		for level := levels; level > 1; level-- {
			page := image.pages[address]
			offset := ((mapping.VAddr >> uint(pageShift+9*(level-1))) & 511) * 8
			pte := binary.LittleEndian.Uint64(page[offset : offset+8])
			if pte&1 == 0 {
				next, err := allocate(level - 1)
				if err != nil {
					return nil, err
				}
				pte = next | 7 // Ancestors impose no additional permission restriction.
				binary.LittleEndian.PutUint64(page[offset:offset+8], pte)
			}
			address = pte & addressMask
		}
		page := image.pages[address]
		offset := ((mapping.VAddr >> pageShift) & 511) * 8
		pte := mapping.PAddr | 1
		if mapping.Permissions.Writable {
			pte |= 2
		}
		if mapping.Permissions.User {
			pte |= 4
		}
		if !mapping.Permissions.Executable {
			pte |= uint64(1) << 63
		}
		binary.LittleEndian.PutUint64(page[offset:offset+8], pte)
	}
	return image, nil
}

func (i *TableImage) Root(space AddressSpace) (uint64, bool) {
	root, found := i.roots[space]
	return root, found
}

func (i *TableImage) PageAddresses() []uint64 { return append([]uint64(nil), i.addresses...) }
func (i *TableImage) Stats() TableImageStats  { return i.stats }

func (i *TableImage) PageBytes(address uint64) ([]byte, bool) {
	page, found := i.pages[address]
	if !found {
		return nil, false
	}
	return append([]byte(nil), page[:]...), true
}

// WriteTo initializes previously reserved zero-filled guest storage BEFORE
// simulation starts. Reservation cannot be inferred from zero contents: the
// caller must exclude these pages from its data allocator. Preflight covers
// every target before any write. This is not a concurrent update transaction.
func (i *TableImage) WriteTo(storage *mem.Storage) error {
	if storage == nil || storage.Capacity != i.stats.MemoryBytes {
		return errors.New("table image and target storage capacity must match")
	}
	for _, address := range i.addresses {
		if !validExtent(address, tablePageBytes, storage.Capacity) {
			return errors.New("table write exceeds physical storage capacity")
		}
		data, err := storage.Read(address, tablePageBytes)
		if err != nil {
			return err
		}
		for _, value := range data {
			if value != 0 {
				return fmt.Errorf("physical table target %#x is not empty", address)
			}
		}
	}
	for _, address := range i.addresses {
		if err := storage.Write(address, i.pages[address][:]); err != nil {
			return err
		}
	}
	return nil
}
