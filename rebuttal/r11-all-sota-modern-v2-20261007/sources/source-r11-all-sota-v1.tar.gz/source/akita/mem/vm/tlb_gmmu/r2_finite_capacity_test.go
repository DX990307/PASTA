package tlb_gmmu

import (
	"fmt"
	"os"
	"strconv"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
)

func TestR2FiniteCapacityAdmissionAndRetirement(t *testing.T) {
	capacity, err := strconv.Atoi(os.Getenv("R2_FINITE_CAPACITY"))
	if err != nil || capacity < 16 {
		t.Fatal("missing finite capacity", err)
	}
	for _, vpn := range []bool{true, false} {
		t.Run(fmt.Sprintf("entries%d_vpn%t", capacity, vpn), func(t *testing.T) {
			tlb := MakeBuilder().WithNumMSHREntry(capacity).WithPerVPNMSHRBaseline(vpn).Build("R2Capacity")
			for i := 0; i < capacity; i++ {
				if tlb.mshr.IsFull() {
					t.Fatalf("early full after %d entries", i)
				}
				tlb.mshr.Add(vm.PID(1), uint64(i)*32768, 0, 0)
			}
			entries, limit := tlb.mshr.Occupancy()
			if entries != capacity || limit != capacity || !tlb.mshr.IsFull() {
				t.Fatal("finite admission not enforced")
			}
			stats := tlb.MSHRAdmissionStats()
			if stats["mshr_entry_capacity"] != float64(capacity) || stats["mshr_entry_capacity_unbounded"] != 0 {
				t.Fatal("incorrect capacity metrics")
			}
			tlb.mshr.Remove(vm.PID(1), 0)
			if tlb.mshr.IsFull() {
				t.Fatal("retirement did not release slot")
			}
			t.Logf("R2_CAPACITY entries=%d vpn=%t full_then_retired=true", capacity, vpn)
		})
	}
}
