package mmu

const (
	SimpleSOTAOff        = "off"
	SimpleSOTAMPW        = "mpw"
	SimpleSOTASoftWalker = "softwalker"
	SimpleSOTATransFW    = "transfw"
	SimpleSOTAPWS        = "pws"
)

// SimpleSOTAConfig describes deliberately coarse page-walker models.
type SimpleSOTAConfig struct {
	Mode                  string
	MPWBatchSize          int
	SoftWalkerSlots       int
	PWSCapacityMultiplier int
	TransFWRemoteCycles   int
}

// SimpleSOTAStats separates modeled capacity/latency effects from real traffic.
type SimpleSOTAStats struct {
	WalkStarts, CompletedWalks, LogicalPTAccesses, ServiceCycles   uint64
	MPWConcurrentRequests, SoftWalkerRequests, PWSBorrowedRequests uint64
	TransFWForwarded, TransFWSavedCycles                           uint64
}

func normalizeSimpleSOTAConfig(c SimpleSOTAConfig) SimpleSOTAConfig {
	if c.Mode == "" {
		c.Mode = SimpleSOTAOff
	}
	if c.MPWBatchSize == 0 {
		c.MPWBatchSize = 8
	}
	if c.SoftWalkerSlots == 0 {
		c.SoftWalkerSlots = 32
	}
	if c.PWSCapacityMultiplier == 0 {
		c.PWSCapacityMultiplier = 2
	}
	if c.TransFWRemoteCycles == 0 {
		c.TransFWRemoteCycles = 100
	}
	if c.MPWBatchSize < 1 || c.SoftWalkerSlots < 0 || c.PWSCapacityMultiplier < 1 || c.TransFWRemoteCycles < 1 {
		panic("invalid simple SOTA configuration")
	}
	switch c.Mode {
	case SimpleSOTAOff, SimpleSOTAMPW, SimpleSOTASoftWalker, SimpleSOTATransFW, SimpleSOTAPWS:
	default:
		panic("unsupported simple SOTA mode")
	}
	return c
}

func (m *MMU) SimpleSOTAStats() (SimpleSOTAConfig, SimpleSOTAStats) {
	return m.simpleSOTA, m.simpleSOTAStats
}

func (m *MMU) effectivePTWCapacity() int {
	switch m.simpleSOTA.Mode {
	case SimpleSOTAMPW:
		return m.maxRequestsInFlight * m.simpleSOTA.MPWBatchSize
	case SimpleSOTAPWS:
		return m.maxRequestsInFlight * m.simpleSOTA.PWSCapacityMultiplier
	default:
		return m.maxRequestsInFlight
	}
}

func (m *MMU) simpleSOTALatency(original uint64) uint64 {
	if m.simpleSOTA.Mode != SimpleSOTATransFW || len(m.PWqueue) <= m.maxRequestsInFlight/2 {
		return original
	}
	replacement := uint64(m.simpleSOTA.TransFWRemoteCycles)
	if replacement >= original {
		return original
	}
	m.simpleSOTAStats.TransFWForwarded++
	m.simpleSOTAStats.TransFWSavedCycles += original - replacement
	return replacement
}

func (m *MMU) observeSimpleSOTAStart(serviceCycles uint64) {
	s := &m.simpleSOTAStats
	s.WalkStarts++
	s.ServiceCycles += serviceCycles
	s.LogicalPTAccesses += (serviceCycles + 99) / 100
	if len(m.walkingTranslations) < m.maxRequestsInFlight {
		return
	}
	switch m.simpleSOTA.Mode {
	case SimpleSOTAMPW:
		s.MPWConcurrentRequests++
	case SimpleSOTAPWS:
		s.PWSBorrowedRequests++
	}
}
