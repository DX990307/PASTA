package gmmu

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

func TestLocalWalkerControlRespectsCapacityAndService(t *testing.T) {
	for _, capacity := range []int{4, 8} {
		m := MakeBuilder().WithEngine(sim.NewSerialEngine()).
			WithMaxNumReqInFlight(capacity).WithPageWalkingLatency(500).Build("LocalCapacity")
		for i := 0; i < capacity+1; i++ {
			req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(uint64(i) * 4096).Build()
			if err := m.topPort.Recv(req); err != nil {
				t.Fatal(err)
			}
		}
		for i := 0; i < capacity; i++ {
			if !m.parseFromTop(0) {
				t.Fatal("local walker admission stopped before capacity")
			}
		}
		if m.parseFromTop(0) || m.PTWInflight() != capacity || m.HasFreePTW() || m.topPort.Peek() == nil {
			t.Fatal("local capacity/backpressure not enforced")
		}
		for cycle := 0; cycle < 500; cycle++ {
			m.walkPageTable(sim.VTimeInSec(cycle) * 1e-9)
		}
		for _, walk := range m.walkingTranslations {
			if walk.cycleLeft != 0 {
				t.Fatal("local service was not 500 countdown cycles")
			}
		}
		m.walkingTranslations = m.walkingTranslations[1:]
		if !m.HasFreePTW() || !m.parseFromTop(1) || m.PTWInflight() != capacity || m.topPort.Peek() != nil {
			t.Fatal("local queued request did not enter the released walker")
		}
		if m.walkingTranslations[capacity-1].cycleLeft != 500 {
			t.Fatal("new local request did not receive the same service time")
		}
	}
}
