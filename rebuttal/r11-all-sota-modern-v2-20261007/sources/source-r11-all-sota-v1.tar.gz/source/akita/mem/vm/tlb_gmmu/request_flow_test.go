package tlb_gmmu

import (
	"encoding/json"
	"fmt"
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

// These are clock-stepped component tests. Recording ports supply controlled
// backpressure; they do not replace the separate event-engine/mesh tests.
type requestFlow struct {
	t                    *testing.T
	tlb                  *GMMUTLB
	top, bottom, outside *routeTestPort
	requests             []*vm.TranslationReq
	cycle                int
}

func newRequestFlow(t *testing.T, owners [8]uint64, assist, observed bool) *requestFlow {
	t.Helper()
	translationtrace.Configure(observed, "", 100)
	t.Cleanup(func() { translationtrace.Configure(false, "", 100) })
	pt := vm.NewPageTable(12)
	for pid := vm.PID(1); pid <= 2; pid++ {
		for bit, owner := range owners {
			pt.Insert(vm.Page{PID: pid, VAddr: uint64(bit) * 4096,
				PAddr:    uint64(pid)*0x100000 + uint64(bit)*4096,
				PageSize: 4096, Valid: true, DeviceID: owner})
		}
	}
	tlb := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithDeviceID(1).
		WithNumSets(16).WithNumWays(16).WithNumReqPerCycle(128).
		WithNumMSHREntry(16).WithLog2PageSize(12).WithPageSize(4096).
		WithPageTable(pt).WithPTELookupSlots(8).WithPTELookupLatencyCycles(32).
		WithFlexTLB(true).WithInitialPTCLMode(true).WithPTCLModeThresholds(2, 6).
		WithIOMMUPort(sim.NewLimitNumMsgPort(nil, 1280, "IOMMU.Top")).
		WithLowModule(sim.NewLimitNumMsgPort(nil, 1280, "GMMU.Top")).
		WithIdleIOMMUAssist(assist).WithSharedPTWStateProvider(routeTestFreePTW{}).
		WithPLTStudy(0, observed, false).WithPTCLResidencyProfile(observed).
		WithPTCLMSHRLifetimeProfile(observed).Build("RequestFlow.L2")
	h := &requestFlow{t: t, tlb: tlb}
	h.top = &routeTestPort{Port: tlb.topPort}
	h.bottom = &routeTestPort{Port: tlb.bottomPort}
	h.outside = &routeTestPort{Port: tlb.OutsidePort}
	tlb.topPort, tlb.bottomPort, tlb.OutsidePort = h.top, h.bottom, h.outside
	return h
}

func (h *requestFlow) now() sim.VTimeInSec {
	return h.tlb.Freq.NCyclesLater(h.cycle, 0)
}

func (h *requestFlow) request(pid vm.PID, bit int, requester string) *vm.TranslationReq {
	h.t.Helper()
	source := sim.NewLimitNumMsgPort(nil, 1280, requester)
	r := vm.TranslationReqBuilder{}.WithPID(pid).WithVAddr(uint64(bit) * 4096).
		WithSrc(source).WithDst(h.top).WithOriginPort(source).
		WithTaskID(fmt.Sprintf("request-%d", len(h.requests))).Build()
	r.StartGPUID = len(h.requests)%48 + 1
	r.RecvTime = h.now()
	h.requests = append(h.requests, r)
	return r
}

func (h *requestFlow) enqueue(r *vm.TranslationReq) {
	h.t.Helper()
	if err := h.top.Recv(r); err != nil {
		h.t.Fatal("test input port unexpectedly full")
	}
}

func (h *requestFlow) admit(pid vm.PID, bit int, requester string) *vm.TranslationReq {
	h.t.Helper()
	r := h.request(pid, bit, requester)
	h.enqueue(r)
	if !h.tlb.lookupFromTopPort(h.now()) || h.top.Peek() != nil {
		h.t.Fatalf("request %s not consumed", r.TaskID)
	}
	return r
}

func (h *requestFlow) until(cycle int) {
	h.t.Helper()
	if cycle < h.cycle {
		h.t.Fatal("test clock moved backwards")
	}
	for h.cycle < cycle {
		h.cycle++
		h.tlb.Tick(h.now())
	}
}

func (h *requestFlow) walks() []*vm.TranslationReq {
	var result []*vm.TranslationReq
	for _, port := range []*routeTestPort{h.bottom, h.outside} {
		for _, msg := range port.sent {
			result = append(result, msg.(*vm.TranslationReq))
		}
	}
	return result
}

func (h *requestFlow) returnWalk(r *vm.TranslationReq) {
	h.t.Helper()
	page, ok := h.tlb.pageTable.Find(r.PID, r.VAddr)
	if !ok {
		h.t.Fatal("no static mapping for controlled response")
	}
	rsp := vm.TranslationRspBuilder{}.WithSrc(r.Dst).WithDst(r.Src).
		WithRspTo(r.ID).WithPage(page).Build()
	rsp.RecvTime = h.now()
	if err := r.Src.Recv(rsp); err != nil {
		h.t.Fatal("test response port unexpectedly full")
	}
	// Outside responses are parsed after the reply stage in Tick.
	h.until(h.cycle + 2)
}

type flowMessage struct {
	Task, Source, Destination, Origin, Path string
	PID                                     vm.PID
	VAddr                                   uint64
	Page                                    vm.Page
	Bitmap                                  [8]bool
	Time                                    sim.VTimeInSec
}

func (h *requestFlow) messages() []flowMessage {
	var messages []flowMessage
	for _, req := range h.walks() {
		messages = append(messages, flowMessage{Task: req.TaskID, Source: req.Src.Name(),
			Destination: req.Dst.Name(), Origin: req.OriginPort.Name(), Path: req.TracePath,
			PID: req.PID, VAddr: req.VAddr, Bitmap: req.BitMap, Time: req.SendTime})
	}
	for _, msg := range h.top.sent {
		rsp := msg.(*vm.TranslationRsp)
		messages = append(messages, flowMessage{Task: rsp.TaskID, Source: rsp.Src.Name(),
			Destination: rsp.Dst.Name(), Origin: rsp.OriginPort.Name(), Page: rsp.Page,
			Time: rsp.SendTime})
	}
	return messages
}

func (h *requestFlow) checkpoint(phase string) {
	h.t.Helper()
	var entries []map[string]interface{}
	for pid := vm.PID(1); pid <= 2; pid++ {
		if e := h.tlb.mshr.GetEntry(pid, 0); e != nil {
			var tasks []string
			for _, r := range e.Requests {
				tasks = append(tasks, r.TaskID)
			}
			entries = append(entries, map[string]interface{}{
				"pid": pid, "tasks": tasks, "demand": e.UplevelBitMap,
				"issued": e.IssuedBitMap, "returned": e.ResponseBitMap,
			})
		}
	}
	state := map[string]interface{}{"phase": phase, "cycle": h.cycle, "entries": entries,
		"lookup_waiting":     len(h.tlb.pteLookupWaitingQueue),
		"lookup_active":      len(h.tlb.pteLookupInflight),
		"ready_groups":       len(h.tlb.pteLookupReadyToIssue),
		"representatives":    len(h.tlb.ptclRepresentativeMiss),
		"responding_entries": len(h.tlb.respondingMSHREntry), "messages": h.messages()}
	data, err := json.Marshal(state)
	if err != nil {
		h.t.Fatal(err)
	}
	h.t.Log("P1_STATE " + string(data))
}

func (h *requestFlow) checkReplies() {
	h.t.Helper()
	if len(h.top.sent) != len(h.requests) {
		h.t.Fatalf("got %d responses for %d requests", len(h.top.sent), len(h.requests))
	}
	byID := make(map[string]*vm.TranslationReq)
	for _, req := range h.requests {
		byID[req.ID] = req
	}
	for _, msg := range h.top.sent {
		rsp := msg.(*vm.TranslationRsp)
		req := byID[rsp.RespondTo]
		if req == nil {
			h.t.Fatal("unknown or duplicate response identity")
		}
		page, ok := h.tlb.pageTable.Find(req.PID, req.VAddr)
		if !ok || !rsp.Page.Valid || rsp.Page != page || rsp.Dst != req.Src ||
			rsp.TaskID != req.TaskID || rsp.OriginPort != req.OriginPort || rsp.Src != h.top {
			h.t.Fatalf("incorrect response for %s: %+v", req.TaskID, rsp)
		}
		delete(byID, req.ID)
	}
	if len(byID) != 0 || len(h.tlb.respondingMSHREntry) != 0 {
		h.t.Fatal("requests left after all responses")
	}
	if entries, _ := h.tlb.mshr.Occupancy(); entries != 0 {
		h.t.Fatal("MSHR entry leaked")
	}
}

func TestRequestFlowCrossOwnerLateArrivalAndRequesterIdentity(t *testing.T) {
	for _, tc := range []struct {
		name   string
		owners [8]uint64
		assist bool
		path   string
		bit    int
	}{
		{"mixed-owner-local", [8]uint64{2, 1, 3, 1, 2, 1, 3, 1}, false, "", 1},
		{"mixed-owner-assist", [8]uint64{2, 1, 3, 1, 2, 1, 3, 1}, true, "assist", 1},
		{"native-remote", [8]uint64{2, 2, 3, 2, 2, 2, 3, 2}, true, "native", 0},
	} {
		t.Run(tc.name, func(t *testing.T) {
			h := newRequestFlow(t, tc.owners, tc.assist, false)
			h.admit(1, 0, "GPM2.L1")
			h.admit(1, 1, "GPM7.L1")
			h.admit(1, 0, "GPM48.L1")
			h.checkpoint("before-lookup")
			h.until(70)
			walks := h.walks()
			if len(walks) != 1 || walks[0].VAddr != uint64(tc.bit)*4096 ||
				walks[0].TracePath != tc.path || h.tlb.bitmapCount(walks[0].BitMap) != 1 {
				t.Fatalf("incorrect representative or path: %+v", h.messages())
			}
			if tc.path == "" && (walks[0].Src != h.bottom || walks[0].Dst != h.tlb.LowModule) {
				t.Fatal("local representative used the wrong route")
			}
			if tc.path != "" && (walks[0].Src != h.outside || walks[0].Dst != h.tlb.IOMMUPort) {
				t.Fatal("IOMMU representative used the wrong route")
			}
			h.admit(1, 2, "GPM19.L1")
			h.until(90)
			entry := h.tlb.mshr.GetEntry(1, 0)
			if entry == nil || len(entry.Requests) != 4 || len(h.walks()) != 1 ||
				entry.UplevelBitMap != ([8]bool{0: true, 1: true, 2: true}) {
				t.Fatal("late demand duplicated a walk or lost requester state")
			}
			h.checkpoint("late-after-issue")
			h.top.reject = true
			h.returnWalk(walks[0])
			if h.tlb.mshr.GetEntry(1, 0) != nil || len(h.tlb.respondingMSHREntry) != 1 ||
				len(h.tlb.respondingMSHREntry[0].Requests) != 4 || len(h.top.sent) != 0 {
				t.Fatal("response backpressure lost, duplicated, or failed to retire the entry")
			}
			h.checkpoint("ready-but-reply-blocked")
			h.until(100)
			h.top.reject = false
			h.until(101)
			h.checkReplies()
			h.returnWalk(walks[0])
			h.checkReplies()
			h.checkpoint("all-requesters-returned")
		})
	}
}

func TestRequestFlowPIDIsolationAndOutOfOrderReturns(t *testing.T) {
	h := newRequestFlow(t, [8]uint64{1, 1, 1, 1, 1, 1, 1, 1}, false, false)
	h.admit(1, 0, "GPM2.L1")
	h.admit(2, 0, "GPM3.L1")
	h.admit(1, 3, "GPM4.L1")
	h.admit(2, 3, "GPM5.L1")
	if entries, _ := h.tlb.mshr.Occupancy(); entries != 2 {
		t.Fatal("different address spaces merged")
	}
	h.until(70)
	if len(h.walks()) != 2 {
		t.Fatal("expected one representative per address space")
	}
	walks := h.walks()
	h.returnWalk(walks[1])
	if len(h.top.sent) != 2 || h.top.sent[0].(*vm.TranslationRsp).Page.PID != 2 ||
		h.tlb.mshr.GetEntry(1, 0) == nil {
		t.Fatal("out-of-order return affected the other address space")
	}
	h.returnWalk(walks[0])
	h.checkReplies()
	h.checkpoint("two-address-spaces-returned")
}

func TestRequestFlowLateArrivalWhileIssueBlocked(t *testing.T) {
	h := newRequestFlow(t, [8]uint64{2, 2, 2, 2, 2, 2, 2, 2}, false, false)
	h.outside.reject = true
	h.admit(1, 0, "GPM2.L1")
	h.until(70)
	if len(h.walks()) != 0 || h.tlb.downstreamReqCount != 0 ||
		len(h.tlb.pteLookupReadyToIssue) != 1 || len(h.tlb.ptclRepresentativeMiss) != 0 {
		t.Fatal("failed sends advanced representative state")
	}
	h.admit(1, 7, "GPM3.L1")
	h.checkpoint("late-after-lookup-before-issue")
	h.outside.reject = false
	h.until(71)
	if len(h.walks()) != 1 || h.tlb.downstreamReqCount != 1 {
		t.Fatal("issue retry duplicated or dropped the walk")
	}
	h.returnWalk(h.walks()[0])
	h.checkReplies()
	h.checkpoint("blocked-issue-returned")
}

func TestRequestFlowNewLifetimeWhileOldRepliesBlocked(t *testing.T) {
	for _, assist := range []bool{false, true} {
		t.Run(fmt.Sprintf("assist-%v", assist), func(t *testing.T) {
			h := newRequestFlow(t, [8]uint64{1, 1, 1, 1, 1, 1, 1, 1}, assist, false)
			h.admit(1, 0, "GPM2.L1")
			h.until(70)
			h.top.reject = true
			h.returnWalk(h.walks()[0])
			h.admit(1, 7, "GPM3.L1")
			newEntry := h.tlb.mshr.GetEntry(1, 0)
			if newEntry == nil || len(newEntry.Requests) != 1 || len(h.tlb.respondingMSHREntry) != 1 ||
				h.tlb.respondingMSHREntry[0] == newEntry {
				t.Fatal("new demand reused the retired response entry")
			}
			h.until(150)
			if len(h.walks()) != 2 {
				t.Fatal("undemanded offset was treated as a free resident fill")
			}
			h.checkpoint("new-lifetime-issued")
			h.returnWalk(h.walks()[1])
			if assist {
				if len(h.tlb.respondingMSHREntry) != 2 || h.tlb.mshr.GetEntry(1, 0) != nil {
					t.Fatal("outside response lost an overlapping lifetime")
				}
			} else {
				// The existing local return gate retains the response at bottom.
				if len(h.tlb.respondingMSHREntry) != 1 || h.bottom.Peek() == nil ||
					h.tlb.mshr.GetEntry(1, 0) != newEntry {
					t.Fatal("local blocked response or its MSHR was lost")
				}
			}
			h.checkpoint("new-lifetime-response-blocked")
			h.top.reject = false
			h.until(h.cycle + 3)
			h.checkReplies()
			h.checkpoint("both-lifetimes-returned")
		})
	}
}

func TestRequestFlowRequesterLimitRetainsBlockedInput(t *testing.T) {
	h := newRequestFlow(t, [8]uint64{1, 1, 1, 1, 1, 1, 1, 1}, false, false)
	for i := 0; i < 64; i++ {
		h.admit(1, 0, fmt.Sprintf("GPM%d.L1", i%48+1))
	}
	blocked := h.request(1, 0, "GPM3.L1")
	h.enqueue(blocked)
	if h.tlb.lookupFromTopPort(h.now()) || h.top.Peek() != blocked ||
		len(h.tlb.mshr.GetEntry(1, 0).Requests) != 64 {
		t.Fatal("per-entry requester limit did not retain the blocked input")
	}
	h.until(70)
	if len(h.walks()) != 1 || h.top.Peek() != blocked {
		t.Fatal("blocked requester was dropped or issued separately")
	}
	h.returnWalk(h.walks()[0])
	h.until(150)
	h.checkReplies()
	if len(h.walks()) != 1 {
		t.Fatal("cache-resident retry issued a redundant downstream walk")
	}
}

func TestRequestFlowObservationNoninterference(t *testing.T) {
	run := func(observed bool) *requestFlow {
		h := newRequestFlow(t, [8]uint64{2, 1, 3, 1, 2, 1, 3, 1}, true, observed)
		h.tlb.installPage(vm.Page{PID: 1, VAddr: 3 * 4096, PAddr: 0x103000,
			PageSize: 4096, Valid: true, DeviceID: 1})
		// Missing locator metadata makes the read-only shadow exercise a false miss.
		h.tlb.pcd = newPTCLCoverageDirectory(16, 16, 0, 12, 8)
		h.admit(1, 0, "GPM2.L1")
		h.admit(1, 3, "GPM7.L1")
		h.until(70)
		h.admit(1, 2, "GPM48.L1")
		h.top.reject = true
		h.returnWalk(h.walks()[0])
		h.until(90)
		h.top.reject = false
		h.until(91)
		h.checkReplies()
		h.checkpoint(fmt.Sprintf("observation-%v", observed))
		return h
	}
	a, b := run(false), run(true)
	if !reflect.DeepEqual(a.messages(), b.messages()) || !reflect.DeepEqual(a.tlb.Sets, b.tlb.Sets) ||
		!reflect.DeepEqual(a.tlb.pcd, b.tlb.pcd) || a.tlb.ptclMode != b.tlb.ptclMode ||
		a.tlb.coalescingCounter != b.tlb.coalescingCounter ||
		a.tlb.downstreamReqCount != b.tlb.downstreamReqCount ||
		a.tlb.pteLookupDelayCycles != b.tlb.pteLookupDelayCycles {
		t.Fatal("observation changed response time/order, cache/replacement state, or work")
	}
	if b.tlb.PLTStudyStats()["plt_false_miss_bits"] != 1 ||
		b.tlb.PTCLMSHRLifetimeStats().CompletedEntries != 1 {
		t.Fatal("observation was enabled but did not exercise the expected counters")
	}
}

func TestRequestFlowPLTAliasValidatesFullTags(t *testing.T) {
	for _, mismatch := range []string{"vpn", "pid", "invalid"} {
		t.Run(mismatch, func(t *testing.T) {
			h := newRequestFlow(t, [8]uint64{1, 1, 1, 1, 1, 1, 1, 1}, false, false)
			page, _ := h.tlb.pageTable.Find(1, 0)
			h.tlb.installPage(page)
			setID := h.tlb.vAddrToSetIDForPID(1, 0)
			way, _, ok := h.tlb.Sets[setID].Lookup(1, 0)
			if !ok {
				t.Fatal("fixture page not resident")
			}
			wrong := page
			switch mismatch {
			case "vpn":
				wrong.VAddr += 16 * 4096
			case "pid":
				wrong.PID = 2
			case "invalid":
				wrong.Valid = false
			}
			// Deliberately retain the old tagless locator after a PTE-way change.
			h.tlb.Sets[setID].Update(way, wrong)
			h.admit(1, 0, "GPM2.L1")
			h.until(70)
			if len(h.top.sent) != 0 || len(h.walks()) != 1 || h.tlb.pcdStaleBits != 1 {
				t.Fatal("alias returned the wrong translation or skipped stale validation")
			}
			h.returnWalk(h.walks()[0])
			h.checkReplies()
			h.checkpoint("alias-" + mismatch)
		})
	}
}
