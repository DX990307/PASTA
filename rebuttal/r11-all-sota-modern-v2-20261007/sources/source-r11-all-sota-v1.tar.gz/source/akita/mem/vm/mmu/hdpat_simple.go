package mmu

import (
	"container/list"

	"github.com/sarchlab/akita/v3/mem/vm"
)

// HDPATSimple models only the paper-specified 1024-entry LRU redirection
// table and four-PTE proactive delivery. Peer probes, placement, filters,
// access-count selection, and their network timing are intentionally absent.
type HDPATSimple struct {
	capacity int
	lru      *list.List
	entries  map[hdpatKey]*list.Element
	stats    HDPATSimpleStats
}

type hdpatKey struct {
	pid vm.PID
	vpn uint64
}

type hdpatEntry struct {
	key  hdpatKey
	page vm.Page
}

type HDPATSimpleStats struct {
	Requests, Hits, Misses, Installs, ProactiveInstalls, Evictions uint64
}

func NewHDPATSimple(capacity int) *HDPATSimple {
	if capacity <= 0 {
		panic("HDPAT-Simple redirection capacity must be positive")
	}
	return &HDPATSimple{capacity: capacity, lru: list.New(), entries: make(map[hdpatKey]*list.Element)}
}

func (h *HDPATSimple) lookup(req *vm.TranslationReq, pageTable vm.PageTable, log2PageSize uint64) (vm.Page, bool) {
	h.stats.Requests++
	key := hdpatKey{pid: req.PID, vpn: req.VAddr >> log2PageSize}
	element := h.entries[key]
	if element == nil {
		h.stats.Misses++
		return vm.Page{}, false
	}
	entry := element.Value.(hdpatEntry)
	current, found := pageTable.Find(req.PID, req.VAddr)
	if !found || current != entry.page || !current.Valid || current.IsMigrating {
		h.lru.Remove(element)
		delete(h.entries, key)
		h.stats.Misses++
		return vm.Page{}, false
	}
	h.lru.MoveToFront(element)
	h.stats.Hits++
	return entry.page, true
}

func (h *HDPATSimple) install(page vm.Page, proactive bool, log2PageSize uint64) {
	if !page.Valid || page.IsMigrating {
		return
	}
	key := hdpatKey{pid: page.PID, vpn: page.VAddr >> log2PageSize}
	if element := h.entries[key]; element != nil {
		element.Value = hdpatEntry{key: key, page: page}
		h.lru.MoveToFront(element)
		return
	}
	element := h.lru.PushFront(hdpatEntry{key: key, page: page})
	h.entries[key] = element
	h.stats.Installs++
	if proactive {
		h.stats.ProactiveInstalls++
	}
	if h.lru.Len() <= h.capacity {
		return
	}
	victim := h.lru.Back()
	delete(h.entries, victim.Value.(hdpatEntry).key)
	h.lru.Remove(victim)
	h.stats.Evictions++
}

func (m *MMU) hdpatLookup(req *vm.TranslationReq) (vm.Page, bool) {
	if m.hdpatSimple == nil || req == nil || req.IsPrefetch || m.hasBitmap(req.BitMap) {
		return vm.Page{}, false
	}
	return m.hdpatSimple.lookup(req, m.pageTable, m.log2PageSize)
}

func (m *MMU) hdpatInstall(req *vm.TranslationReq) {
	if m.hdpatSimple == nil || req == nil || req.IsPrefetch || m.hasBitmap(req.BitMap) {
		return
	}
	base := (req.VAddr >> m.log2PageSize) << m.log2PageSize
	for offset := uint64(0); offset < 4; offset++ {
		page, found := m.pageTable.Find(req.PID, base+(offset<<m.log2PageSize))
		if found {
			m.hdpatSimple.install(page, offset != 0, m.log2PageSize)
		}
	}
}

func (m *MMU) HDPATSimpleStats() (bool, int, HDPATSimpleStats) {
	if m.hdpatSimple == nil {
		return false, 0, HDPATSimpleStats{}
	}
	return true, m.hdpatSimple.capacity, m.hdpatSimple.stats
}
