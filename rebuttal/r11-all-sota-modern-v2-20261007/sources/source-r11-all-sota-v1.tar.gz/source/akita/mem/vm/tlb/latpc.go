package tlb

import (
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

type latpcEntry struct {
	pid    vm.PID
	base   uint64
	stride uint16
	mask   uint32
	slots  [32]*latpcSlot
}

type latpcSlot struct {
	entry    *latpcEntry
	index    uint8
	down     *vm.TranslationReq
	requests []*vm.TranslationReq
}

type LATPCStats struct {
	Allocated, CompressedMisses, HitUnderMiss, FullObservations, PeakEntries uint64
}

func (t *TLB) LATPCStats() (bool, int, LATPCStats) {
	return t.latpcEnabled, t.latpcCapacity, t.latpcStats
}

func (t *TLB) findLATPC(req *vm.TranslationReq) *latpcEntry {
	i := req.LATPC
	for _, e := range t.latpcEntries {
		if e.pid == req.PID && e.base == i.BaseVPN && (e.stride == i.Stride || e.stride == 0) {
			return e
		}
	}
	return nil
}

func (t *TLB) lookupLATPC(now sim.VTimeInSec, req *vm.TranslationReq) bool {
	if !req.LATPC.Matches(req.VAddr >> 12) {
		panic("LATPC metadata does not describe the demanded VPN")
	}
	// Two pipeline cycles for detector and compressed tagging, without a DRAM model.
	if t.latpcDelayID != req.ID {
		t.latpcDelayID, t.latpcReadyAt = req.ID, t.Freq.NCyclesLater(2, now)
		return true
	}
	if now+1e-15 < t.latpcReadyAt {
		return true
	}
	e := t.findLATPC(req)
	index := req.LATPC.Index
	if e != nil && e.mask&(uint32(1)<<index) != 0 {
		e.slots[index].requests = append(e.slots[index].requests, req)
		t.topPort.Retrieve(now)
		t.latpcDelayID = ""
		t.latpcStats.HitUnderMiss++
		tracing.TraceReqReceive(req, t)
		tracing.AddTaskStep(tracing.MsgIDAtReceiver(req, t), t, "mshr-hit")
		return true
	}
	setID := t.vAddrToSetID(req.VAddr)
	way, page, hit := t.Sets[setID].Lookup(req.PID, req.VAddr)
	if hit && page.Valid {
		ok := t.handleTranslationHit(now, req, setID, way, page)
		if ok {
			t.latpcDelayID = ""
		}
		return ok
	}
	if e == nil && len(t.latpcEntries)+len(t.mshr.AllEntries()) >= t.latpcCapacity {
		t.latpcStats.FullObservations++
		return false
	}
	down := vm.TranslationReqBuilder{}.WithSendTime(now).WithSrc(t.bottomPort).WithDst(t.LowModule).
		WithPID(req.PID).WithVAddr(req.VAddr).WithLATPC(req.LATPC).WithDeviceID(uint64(t.DeviceID)).
		WithTaskID(req.TaskID).WithOriginPort(t.bottomPort).Build()
	if t.bottomPort.Send(down) != nil {
		return false
	}
	if e == nil {
		e = &latpcEntry{pid: req.PID, base: req.LATPC.BaseVPN, stride: req.LATPC.Stride}
		t.latpcEntries = append(t.latpcEntries, e)
		t.latpcStats.Allocated++
		if uint64(len(t.latpcEntries)) > t.latpcStats.PeakEntries {
			t.latpcStats.PeakEntries = uint64(len(t.latpcEntries))
		}
	} else {
		t.latpcStats.CompressedMisses++
	}
	e.stride = req.LATPC.Stride
	slot := &latpcSlot{entry: e, index: index, down: down, requests: []*vm.TranslationReq{req}}
	e.mask |= uint32(1) << index
	e.slots[index] = slot
	t.latpcPending[down.ID] = slot
	t.topPort.Retrieve(now)
	t.latpcDelayID = ""
	tracing.TraceReqReceive(req, t)
	tracing.AddTaskStep(tracing.MsgIDAtReceiver(req, t), t, "miss")
	tracing.TraceReqInitiate(down, t, tracing.MsgIDAtReceiver(req, t))
	return true
}

func (t *TLB) returnLATPC(now sim.VTimeInSec, rsp *vm.TranslationRsp, slot *latpcSlot) bool {
	page := rsp.Page
	if !page.Valid || page.PID != slot.down.PID || page.VAddr != slot.down.VAddr {
		panic("LATPC response context mismatch")
	}
	set := t.Sets[t.vAddrToSetID(page.VAddr)]
	way, ok := set.Evict()
	if !ok {
		return false
	}
	set.Update(way, page)
	set.Visit(way)
	t.respondingMSHREntry = &mshrEntry{pid: page.PID, vAddr: page.VAddr, page: page,
		Requests: slot.requests, reqToBottom: slot.down}
	e := slot.entry
	e.mask &^= uint32(1) << slot.index
	e.slots[slot.index] = nil
	delete(t.latpcPending, slot.down.ID)
	if e.mask == 0 {
		for n, existing := range t.latpcEntries {
			if existing == e {
				t.latpcEntries = append(t.latpcEntries[:n], t.latpcEntries[n+1:]...)
				break
			}
		}
	}
	t.bottomPort.Retrieve(now)
	tracing.TraceReqFinalize(slot.down, t)
	return true
}
