package mmu

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

func hdpatTestPage(vpn uint64) vm.Page {
	return vm.Page{
		PID: 1, VAddr: vpn << 12, PAddr: (vpn + 1024) << 12,
		PageSize: 4096, Valid: true, DeviceID: 1,
	}
}

func TestHDPATSimpleLRUCapacityAndMappingValidation(t *testing.T) {
	table := vm.NewPageTable(12)
	h := NewHDPATSimple(2)
	for vpn := uint64(1); vpn <= 3; vpn++ {
		page := hdpatTestPage(vpn)
		table.Insert(page)
		h.install(page, vpn != 1, 12)
	}
	if len(h.entries) != 2 || h.stats.Evictions != 1 || h.stats.ProactiveInstalls != 2 {
		t.Fatalf("unexpected LRU state: entries=%d stats=%+v", len(h.entries), h.stats)
	}
	req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(2 << 12).Build()
	if page, ok := h.lookup(req, table, 12); !ok || page.VAddr != 2<<12 {
		t.Fatal("resident mapping did not hit")
	}
	changed := hdpatTestPage(2)
	changed.PAddr += 4096
	table.Update(changed)
	if _, ok := h.lookup(req, table, 12); ok {
		t.Fatal("stale redirection mapping was returned")
	}
}

func TestHDPATSimpleFourPTEDeliveryServesAdjacentRequest(t *testing.T) {
	table := vm.NewPageTable(12)
	for vpn := uint64(8); vpn < 12; vpn++ {
		table.Insert(hdpatTestPage(vpn))
	}
	m := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithPageTable(table).
		WithPageWalkingLatency(400).WithMaxNumReqInFlight(1).
		WithWalkCoalescing(false).WithDemandPTEOnly(true).
		WithHDPATSimple(true).Build("HDPAT.MMU")
	first := vm.TranslationReqBuilder{}.WithPID(1).WithDeviceID(1).WithVAddr(8 << 12).Build()
	m.hdpatInstall(first)
	adjacent := vm.TranslationReqBuilder{}.WithPID(1).WithDeviceID(1).WithVAddr(11 << 12).Build()
	m.startWalking(adjacent, 400, 0)
	if len(m.walkingTranslations) != 1 || !m.walkingTranslations[0].hdpatHit ||
		m.walkingTranslations[0].cycleLeft != 1 {
		t.Fatal("adjacent delivered PTE did not bypass the page walk")
	}
	enabled, capacity, stats := m.HDPATSimpleStats()
	if !enabled || capacity != 1024 || stats.Misses != 0 || stats.Hits != 1 ||
		stats.Installs != 4 || stats.ProactiveInstalls != 3 {
		t.Fatalf("unexpected HDPAT-Simple behavior: enabled=%v capacity=%d stats=%+v", enabled, capacity, stats)
	}
}
