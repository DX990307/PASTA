package radixwalk

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/idealmemcontroller"
	"github.com/sarchlab/akita/v3/mem/mem"
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

func imageArena() TableArena {
	arena := TableArena{MemoryBytes: 32 * mem.MB}
	for n := uint64(0); n < 64; n++ {
		arena.Pages = append(arena.Pages, 0x80000-n*8192)
	}
	return arena
}

func imagePTE(t *testing.T, image *TableImage, space AddressSpace, va uint64, levels int) uint64 {
	t.Helper()
	node, found := image.Root(space)
	if !found {
		t.Fatal("missing root")
	}
	for level := levels; level >= 1; level-- {
		page, found := image.PageBytes(node)
		if !found || len(page) != 4096 {
			t.Fatal("missing node bytes")
		}
		index := (va >> uint(12+9*(level-1))) & 511
		pte := binary.LittleEndian.Uint64(page[8*index : 8*(index+1)])
		if level == 1 || pte&1 == 0 {
			return pte
		}
		if pte&7 != 7 || pte>>63 != 0 {
			t.Fatal("builder added unexpected ancestor permissions")
		}
		node = pte & addressMask
	}
	panic("unreachable")
}

func TestTableImageDeterministicAndIsolated(t *testing.T) {
	for _, levels := range []int{4, 5} {
		t.Run(fmt.Sprint(levels), func(t *testing.T) {
			spaces := []AddressSpace{{2, 1}, {1, 2}, {1, 1}}
			high := ^uint64(0) << uint(12+9*levels-1)
			mappings := []Mapping{
				{spaces[0], 0, 0x900000, allPermissions},
				{spaces[1], 0, 0xa00000, Permissions{}},
				{spaces[2], 0, 0xb00000, allPermissions},
				{spaces[2], 4096, 0xb00000, allPermissions}, // Physical alias is legal.
				{spaces[2], 2 << 20, 0xc00000, Permissions{User: true}},
				{spaces[2], high, 0xd00000, Permissions{Executable: true}},
			}
			arena := imageArena()
			arena.ProtectedRanges = []PhysicalRange{{0x8fffff, 0x500002}}
			image, err := BuildTableImage(levels, spaces, mappings, arena)
			ok(t, err)
			for _, mapping := range mappings {
				pte := imagePTE(t, image, mapping.Space, mapping.VAddr, levels)
				if pte&addressMask != mapping.PAddr || pte&1 == 0 ||
					(pte&2 != 0) != mapping.Permissions.Writable || (pte&4 != 0) != mapping.Permissions.User ||
					(pte>>63 == 0) != mapping.Permissions.Executable {
					t.Fatalf("wrong PTE for %+v: %#x", mapping, pte)
				}
			}
			if imagePTE(t, image, spaces[2], 8192, levels) != 0 {
				t.Fatal("unmapped page became present")
			}
			if _, found := image.Root(AddressSpace{99, 0}); found {
				t.Fatal("unknown root found")
			}
			if _, found := image.PageBytes(123); found {
				t.Fatal("unknown node found")
			}
			stats := image.Stats()
			wantNodes := uint64(4 * levels)
			if stats.AddressSpaces != 3 || stats.Mappings != 6 || stats.NodePagesByLevel[levels] != 3 ||
				stats.NodePagesByLevel[1] != 5 || stats.UsedBytes != wantNodes*4096 ||
				stats.ReservedBytes != 64*4096 || stats.MemoryBytes != arena.MemoryBytes {
				t.Fatalf("incorrect shared-prefix node accounting: %+v", stats)
			}
			for left, right := 0, len(spaces)-1; left < right; left, right = left+1, right-1 {
				spaces[left], spaces[right] = spaces[right], spaces[left]
			}
			for left, right := 0, len(mappings)-1; left < right; left, right = left+1, right-1 {
				mappings[left], mappings[right] = mappings[right], mappings[left]
			}
			other, err := BuildTableImage(levels, spaces, mappings, arena)
			ok(t, err)
			if !reflect.DeepEqual(image, other) {
				t.Fatal("mapping input order changed physical image")
			}
			addresses := image.PageAddresses()
			page, _ := image.PageBytes(addresses[0])
			addresses[0], page[0], stats.UsedBytes = 0, 255, 0
			arena.Pages[0], mappings[0].PAddr, spaces[0].PID = 0, 0, 0
			if !reflect.DeepEqual(image, other) {
				t.Fatal("caller mutated image through a retained input or output")
			}
		})
	}
}

func TestTableImageRejectsInvalidReservationsAndMappings(t *testing.T) {
	type input struct {
		levels int
		spaces []AddressSpace
		maps   []Mapping
		arena  TableArena
	}
	cases := []struct {
		name string
		bad  func(*input)
	}{
		{"levels", func(i *input) { i.levels = 3 }},
		{"no-spaces", func(i *input) { i.spaces = nil }},
		{"duplicate-space", func(i *input) { i.spaces = append(i.spaces, i.spaces[0]) }},
		{"zero-capacity", func(i *input) { i.arena.MemoryBytes = 0 }},
		{"physical-width", func(i *input) { i.arena.MemoryBytes = 1<<52 + 1 }},
		{"unknown-space", func(i *input) { i.maps[0].Space.PID++ }},
		{"duplicate-mapping", func(i *input) { i.maps = append(i.maps, i.maps[0]) }},
		{"noncanonical", func(i *input) { i.maps[0].VAddr = 1 << 47 }},
		{"unaligned-va", func(i *input) { i.maps[0].VAddr++ }},
		{"unaligned-pa", func(i *input) { i.maps[0].PAddr++ }},
		{"data-pa-width", func(i *input) { i.maps[0].PAddr = 1 << 52 }},
		{"data-pa-end", func(i *input) { i.maps[0].PAddr = i.arena.MemoryBytes }},
		{"partial-data-page", func(i *input) { i.arena.MemoryBytes = i.maps[0].PAddr + 4095 }},
		{"unaligned-slot", func(i *input) { i.arena.Pages[0]++ }},
		{"slot-end", func(i *input) { i.arena.Pages[0] = i.arena.MemoryBytes }},
		{"partial-slot", func(i *input) { i.arena.Pages[0] = i.arena.MemoryBytes - 4096; i.arena.MemoryBytes-- }},
		{"duplicate-slot", func(i *input) { i.arena.Pages[1] = i.arena.Pages[0] }},
		{"no-slots", func(i *input) { i.arena.Pages = nil }},
		{"insufficient-slots", func(i *input) { i.arena.Pages = i.arena.Pages[:3] }},
		{"mapped-data-overlap", func(i *input) { i.maps[0].PAddr = i.arena.Pages[0] }},
		{"unused-slot-overlap", func(i *input) { i.maps[0].PAddr = i.arena.Pages[63] }},
		{"protected-start", func(i *input) { i.arena.ProtectedRanges = []PhysicalRange{{i.arena.Pages[0], 1}} }},
		{"protected-end", func(i *input) { i.arena.ProtectedRanges = []PhysicalRange{{i.arena.Pages[0] + 4095, 1}} }},
		{"protected-crossing", func(i *input) { i.arena.ProtectedRanges = []PhysicalRange{{i.arena.Pages[0] - 1, 2}} }},
		{"protected-zero", func(i *input) { i.arena.ProtectedRanges = []PhysicalRange{{0, 0}} }},
		{"protected-overflow", func(i *input) { i.arena.ProtectedRanges = []PhysicalRange{{1, ^uint64(0)}} }},
		{"protected-end-capacity", func(i *input) { i.arena.ProtectedRanges = []PhysicalRange{{i.arena.MemoryBytes, 1}} }},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			i := input{4, []AddressSpace{{1, 0}}, []Mapping{{AddressSpace{1, 0}, 0, 0x900000, allPermissions}}, imageArena()}
			test.bad(&i)
			image, err := BuildTableImage(i.levels, i.spaces, i.maps, i.arena)
			if err == nil || image != nil {
				t.Fatal("invalid input returned a usable image")
			}
		})
	}
}

func TestTableImageBoundaryPagesAndEmptyAddressSpace(t *testing.T) {
	arena := TableArena{MemoryBytes: 6 * 4096, Pages: []uint64{0, 4096, 8192, 3 * 4096, 4 * 4096},
		ProtectedRanges: []PhysicalRange{{5 * 4096, 4096}}}
	spaces := []AddressSpace{{0, 0}, {0, 1}}
	image, err := BuildTableImage(4, spaces, []Mapping{{spaces[0], ^uint64(4095), 5 * 4096, allPermissions}}, arena)
	ok(t, err)
	if root, found := image.Root(spaces[0]); !found || root != 0 {
		t.Fatal("physical root zero treated as absent")
	}
	if imagePTE(t, image, spaces[1], 0, 4) != 0 || image.Stats().UsedBytes != 5*4096 {
		t.Fatal("empty address space was not isolated")
	}
	ok(t, image.WriteTo(mem.NewStorage(arena.MemoryBytes)))
}

func TestVMPageConversionRequiresValidStaticBasePage(t *testing.T) {
	page := vm.Page{PID: 7, PAddr: 0x900000, VAddr: 4096, PageSize: 4096, Valid: true}
	permissions := Permissions{User: true}
	mapping, err := MappingFromVMPage(page, 3, permissions)
	ok(t, err)
	if mapping != (Mapping{AddressSpace{7, 3}, 4096, 0x900000, permissions}) {
		t.Fatal("conversion changed explicit context or permissions")
	}
	for _, change := range []func(*vm.Page){
		func(p *vm.Page) { p.Valid = false }, func(p *vm.Page) { p.IsMigrating = true },
		func(p *vm.Page) { p.PageSize = 2 << 20 }, func(p *vm.Page) { p.PAddr++ },
		func(p *vm.Page) { p.VAddr++ }, func(p *vm.Page) { p.PAddr = 1 << 52 },
	} {
		bad := page
		change(&bad)
		if _, err := MappingFromVMPage(bad, 3, permissions); err == nil {
			t.Fatal("invalid functional mapping became a present PTE")
		}
	}
}

func TestTableImagePreflightDoesNotOverwriteGuestMemory(t *testing.T) {
	arena := imageArena()
	space := AddressSpace{1, 0}
	image, err := BuildTableImage(4, []AddressSpace{space}, []Mapping{{space, 0, 0x900000, allPermissions}}, arena)
	ok(t, err)
	for _, storage := range []*mem.Storage{nil, mem.NewStorage(arena.MemoryBytes - 1), mem.NewStorage(arena.MemoryBytes + 1)} {
		if image.WriteTo(storage) == nil {
			t.Fatal("mismatched physical capacity accepted")
		}
	}
	storage := mem.NewStorage(arena.MemoryBytes)
	addresses := image.PageAddresses()
	last := addresses[len(addresses)-1]
	ok(t, storage.Write(last+4095, []byte{99}))
	if image.WriteTo(storage) == nil {
		t.Fatal("occupied late target overwritten")
	}
	firstData, err := storage.Read(addresses[0], 4096)
	ok(t, err)
	if !bytes.Equal(firstData, make([]byte, 4096)) {
		t.Fatal("earlier page modified before complete preflight")
	}
	lastByte, err := storage.Read(last+4095, 1)
	ok(t, err)
	if lastByte[0] != 99 {
		t.Fatal("occupied byte changed")
	}
	ok(t, storage.Write(last+4095, []byte{0}))
	ok(t, storage.Write(0x900000, []byte{17, 31, 41}))
	ok(t, image.WriteTo(storage))
	for _, address := range addresses {
		actual, err := storage.Read(address, 4096)
		ok(t, err)
		want, _ := image.PageBytes(address)
		if !bytes.Equal(actual, want) {
			t.Fatal("stored image differs from physical page bytes")
		}
	}
	data, err := storage.Read(0x900000, 3)
	ok(t, err)
	if !bytes.Equal(data, []byte{17, 31, 41}) || image.WriteTo(storage) == nil {
		t.Fatal("data changed or already initialized image accepted")
	}
}

func TestGeneratedTableImageThroughActualMemoryPorts(t *testing.T) {
	for _, levels := range []int{4, 5} {
		var baselineReads uint64
		for _, neighbor := range []bool{false, true} {
			t.Run(fmt.Sprintf("levels-%d-neighbor-%v", levels, neighbor), func(t *testing.T) {
				space, other, next := AddressSpace{1, 1}, AddressSpace{2, 1}, AddressSpace{1, 2}
				maps := []Mapping{}
				type expected struct {
					req         Request
					pa          uint64
					fault       Fault
					permissions Permissions
				}
				var requests []expected
				add := func(s AddressSpace, va, pa uint64, permissions Permissions, access AccessKind, user bool, fault Fault) {
					maps = append(maps, Mapping{s, va, pa, permissions})
					requests = append(requests, expected{Request{ID: fmt.Sprint(len(requests)), PID: s.PID,
						Generation: s.Generation, VAddr: va + 123, Access: access, User: user}, pa + 123, fault, permissions})
				}
				for n := uint64(0); n < 4; n++ {
					add(space, n*4096, 0x900000+n*4096, allPermissions, Read, true, NoFault)
				}
				add(space, 4*4096, 0xa00000, Permissions{User: true}, Write, true, PermissionFault)
				add(space, 5*4096, 0xa01000, Permissions{User: true}, Execute, true, PermissionFault)
				add(space, 6*4096, 0xa02000, Permissions{Writable: true}, Read, true, PermissionFault)
				add(other, 0, 0xb00000, allPermissions, Write, true, NoFault)
				add(next, 0, 0xc00000, allPermissions, Execute, true, NoFault)
				add(space, ^uint64(0)<<uint(12+9*levels-1), 0xd00000, Permissions{Executable: true}, Execute, false, NoFault)
				requests = append(requests, expected{req: Request{ID: "absent", PID: space.PID,
					Generation: space.Generation, VAddr: 7 * 4096, User: true}, fault: NotPresent})
				arena := imageArena()
				image, err := BuildTableImage(levels, []AddressSpace{space, other, next}, maps, arena)
				ok(t, err)
				storage := mem.NewStorage(arena.MemoryBytes)
				ok(t, image.WriteTo(storage))
				c := Config{Levels: levels, Walkers: 4, BufferEntries: 16,
					LeafCoalescing: neighbor, UpperCoalescing: neighbor, AwareScheduling: neighbor}
				w := newWalker(t, c)
				for n := range requests {
					r := &requests[n].req
					r.Root, _ = image.Root(AddressSpace{r.PID, r.Generation})
					enqueue(t, w, *r)
				}
				engine := sim.NewSerialEngine()
				backend := idealmemcontroller.MakeBuilder().WithEngine(engine).WithStorage(storage).
					WithLatency(11).WithWidth(1).WithTopBufSize(1).Build("ImageBackend")
				client := &memoryClient{t: t, w: w, completed: make(map[string]Completion), acceptAfter: 300}
				client.TickingComponent = sim.NewTickingComponent("ImageClient", engine, sim.GHz, client)
				port := sim.NewLimitNumMsgPort(client, 1, "ImageClient.Memory")
				client.AddPort("Memory", port)
				link := sim.NewDirectConnection("ImageLink", engine, sim.GHz)
				link.PlugIn(port, 1)
				link.PlugIn(backend.GetPortByName("Top"), 1)
				client.bridge, err = NewMemoryPort(w, port, &mem.SingleLowModuleFinder{LowModule: backend.GetPortByName("Top")}, sim.GHz, 2)
				ok(t, err)
				client.TickNow(0)
				ok(t, engine.Run())
				if len(client.completed) != len(requests) || w.Snapshot().CompletionWaitCycles == 0 ||
					len(client.bridge.inflight) != 0 || len(client.bridge.pending) != 0 {
					t.Fatal("requests lost or completion backpressure bypassed")
				}
				for _, want := range requests {
					done, found := client.completed[want.req.ID]
					if !found || done.Request != want.req || done.Fault != want.fault {
						t.Fatalf("wrong completion: %+v, want %+v", done, want)
					}
					if done.Fault == NoFault && (done.PAddr != want.pa || done.Permissions != want.permissions) {
						t.Fatal("physical PTE bytes gave wrong mapping or permissions")
					}
					if done.Fault != NoFault && (done.PAddr != 0 || done.Permissions != (Permissions{})) {
						t.Fatal("fault exposed a successful translation")
					}
				}
				stats := client.bridge.Snapshot()
				if !neighbor {
					baselineReads = stats.ReadRequests
				} else if stats.ReadRequests >= baselineReads || w.Snapshot().LeafCoalesced == 0 {
					t.Fatal("generated image did not exercise coalesced leaf returns")
				}
				t.Logf("RADIX_IMAGE levels=%d neighbor=%v translations=%d reads=%d table_bytes=%d reserved_bytes=%d cycles=%d",
					levels, neighbor, len(requests), stats.ReadRequests, image.Stats().UsedBytes, image.Stats().ReservedBytes, client.maxCycle)
			})
		}
	}
}
