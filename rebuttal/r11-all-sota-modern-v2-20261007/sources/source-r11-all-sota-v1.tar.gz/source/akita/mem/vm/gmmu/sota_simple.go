package gmmu

import "github.com/sarchlab/akita/v3/mem/vm"

const (
	SimpleSOTAOff        = "off"
	SimpleSOTAMPW        = "mpw"
	SimpleSOTASoftWalker = "softwalker"
	SimpleSOTATransFW    = "transfw"
	SimpleSOTAPWS        = "pws"
)

type SimpleSOTAConfig struct {
	Mode                  string
	MPWBatchSize          int
	SoftWalkerSlots       int
	PWSCapacityMultiplier int
	TransFWRemoteCycles   int
}

type SimpleSOTAStats struct {
	WalkStarts, CompletedWalks, LogicalPTAccesses, ServiceCycles   uint64
	MPWConcurrentRequests, SoftWalkerRequests, PWSBorrowedRequests uint64
	TransFWForwarded, TransFWSavedCycles                           uint64
}

func normalizeSimpleSOTAConfig(c SimpleSOTAConfig) SimpleSOTAConfig {
	if c.Mode == "" {
		c.Mode = SimpleSOTAOff
	}
	if c.MPWBatchSize == 0 {
		c.MPWBatchSize = 8
	}
	if c.SoftWalkerSlots == 0 {
		c.SoftWalkerSlots = 32
	}
	if c.PWSCapacityMultiplier == 0 {
		c.PWSCapacityMultiplier = 2
	}
	if c.TransFWRemoteCycles == 0 {
		c.TransFWRemoteCycles = 100
	}
	if c.MPWBatchSize < 1 || c.SoftWalkerSlots < 0 || c.PWSCapacityMultiplier < 1 || c.TransFWRemoteCycles < 1 {
		panic("invalid simple SOTA configuration")
	}
	switch c.Mode {
	case SimpleSOTAOff, SimpleSOTAMPW, SimpleSOTASoftWalker, SimpleSOTATransFW, SimpleSOTAPWS:
	default:
		panic("unsupported simple SOTA mode")
	}
	return c
}

func (g *GMMU) SimpleSOTAStats() (SimpleSOTAConfig, SimpleSOTAStats) {
	return g.simpleSOTA, g.simpleSOTAStats
}

func (g *GMMU) effectivePTWCapacity() int {
	switch g.simpleSOTA.Mode {
	case SimpleSOTAMPW:
		return g.maxRequestsInFlight * g.simpleSOTA.MPWBatchSize
	case SimpleSOTASoftWalker:
		return g.maxRequestsInFlight + g.simpleSOTA.SoftWalkerSlots
	case SimpleSOTAPWS:
		return g.maxRequestsInFlight * g.simpleSOTA.PWSCapacityMultiplier
	default:
		return g.maxRequestsInFlight
	}
}

func (g *GMMU) isTransFWRemote(req *vm.TranslationReq) bool {
	if g.simpleSOTA.Mode != SimpleSOTATransFW || req == nil {
		return false
	}
	page, found := g.pageTable.Find(req.PID, req.VAddr)
	return found && page.Valid && page.DeviceID != g.deviceID
}

func (g *GMMU) observeSimpleSOTAStart(cycles uint64, remote bool) {
	s := &g.simpleSOTAStats
	s.WalkStarts++
	s.ServiceCycles += cycles
	if remote {
		s.TransFWForwarded++
		s.TransFWSavedCycles += uint64(g.latency)
		return
	}
	s.LogicalPTAccesses += (cycles + 99) / 100
	if len(g.walkingTranslations) <= g.maxRequestsInFlight {
		return
	}
	switch g.simpleSOTA.Mode {
	case SimpleSOTAMPW:
		s.MPWConcurrentRequests++
	case SimpleSOTASoftWalker:
		s.SoftWalkerRequests++
	case SimpleSOTAPWS:
		s.PWSBorrowedRequests++
	}
}
