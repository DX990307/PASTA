package tlb_gmmu

import (
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm/downstreamstats"
	"github.com/sarchlab/akita/v3/sim"
)

type flowClock struct{ h *requestFlow }

func (c flowClock) CurrentTime() sim.VTimeInSec { return c.h.now() }

type flowObservedPort struct {
	*routeTestPort
	hook sim.Hook
}

func (p *flowObservedPort) Send(msg sim.Msg) *sim.SendError {
	if err := p.routeTestPort.Send(msg); err != nil {
		return err
	}
	p.hook.Func(sim.HookCtx{Domain: p, Pos: sim.HookPosPortMsgSend, Item: msg})
	return nil
}

func TestDownstreamObserverDoesNotChangeL2RequestFlow(t *testing.T) {
	for _, tc := range []struct {
		name   string
		owner  uint64
		assist bool
	}{
		{"local", 1, false}, {"native", 2, false}, {"assist", 1, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var outcomes [2][]flowMessage
			for observed := 0; observed < 2; observed++ {
				owners := [8]uint64{}
				for i := range owners {
					owners[i] = tc.owner
				}
				h := newRequestFlow(t, owners, tc.assist, false)
				stats := downstreamstats.New(flowClock{h}, 12, h.tlb.Freq)
				if observed == 1 {
					bottom, outside := &flowObservedPort{routeTestPort: h.bottom}, &flowObservedPort{routeTestPort: h.outside}
					bottom.hook, outside.hook = stats.Hook(bottom, true), stats.Hook(outside, false)
					bottom.AcceptHook(bottom.hook)
					outside.AcceptHook(outside.hook)
					h.tlb.bottomPort, h.tlb.OutsidePort = bottom, outside
				}
				h.admit(1, 0, "Source1")
				h.admit(1, 1, "Source2")
				h.admit(2, 0, "Source3")
				h.until(70)
				walks := h.walks()
				if len(walks) != 2 {
					t.Fatalf("expected two physical requests, got %d", len(walks))
				}
				h.admit(1, 3, "LateSource")
				h.top.reject = true
				h.returnWalk(walks[1])
				h.returnWalk(walks[0])
				h.until(80)
				h.top.reject = false
				h.until(85)
				h.checkReplies()
				outcomes[observed] = h.messages()
				if observed == 1 {
					s := stats.Snapshot()
					c := s.Paths[tc.name]
					if c.Started != 2 || c.Completed != 2 || c.ExpectedPages != 2 || c.Inflight != 0 ||
						c.Received.Count != 2 || c.Consumed.Count != 2 || s.Diagnostics != (downstreamstats.Diagnostics{}) {
						t.Fatalf("observer incorrectly counted inferred sibling fills/requesters: %+v", s)
					}
				}
			}
			if !reflect.DeepEqual(outcomes[0], outcomes[1]) {
				t.Fatalf("observer changed actual L2 messages/timing: %v vs %v", outcomes[0], outcomes[1])
			}
		})
	}
}
