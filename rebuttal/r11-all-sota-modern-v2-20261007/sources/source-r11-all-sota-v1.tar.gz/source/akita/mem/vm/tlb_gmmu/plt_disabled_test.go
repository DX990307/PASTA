package tlb_gmmu

import (
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/tlb_gmmu/internal"
	"github.com/sarchlab/akita/v3/sim"
)

func newPLTTestTLB(disabled bool) *GMMUTLB {
	pt := vm.NewPageTable(12)
	for bit := 0; bit < 8; bit++ {
		pt.Insert(pltTestPage(1, uint64(bit)*4096))
	}
	return MakeBuilder().WithEngine(sim.NewSerialEngine()).WithNumSets(16).
		WithNumWays(4).WithLog2PageSize(12).WithPageTable(pt).
		WithPTELookupSlots(2).WithPTELookupLatencyCycles(32).
		WithFlexTLB(true).WithInitialPTCLMode(true).
		WithIdleIOMMUAssist(true).WithPLTDisabled(disabled).Build("PLTTest")
}

func pltTestPage(pid vm.PID, addr uint64) vm.Page {
	return vm.Page{PID: pid, VAddr: addr, PAddr: addr + 0x100000, PageSize: 4096, Valid: true}
}

func enqueuePLTTestRequest(tlb *GMMUTLB, addr uint64) (*vm.TranslationReq, *mshrEntry) {
	req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(addr).Build()
	entry := tlb.mshr.Add(req.PID, req.VAddr, 0, 0)
	entry.Requests = append(entry.Requests, req)
	tlb.enqueuePTELookupJobs(0, req, entry)
	return req, entry
}

func TestPLTDisabledPreservesGroupingAndAssist(t *testing.T) {
	withPLT, withoutPLT := newPLTTestTLB(false), newPLTTestTLB(true)
	if withPLT.pcd == nil || withoutPLT.pcd != nil {
		t.Fatal("PLT allocation does not match configuration")
	}
	_, a := enqueuePLTTestRequest(withPLT, 0)
	r, b := enqueuePLTTestRequest(withoutPLT, 0)
	g := withoutPLT.pteLookupGroups[withoutPLT.pteLookupGroupKey(r.PID, r.VAddr)]
	if !withoutPLT.flexTLBEnabled || !withoutPLT.idleIOMMUAssistEnabled ||
		!withoutPLT.shouldCoalescePTCLDownstream(g) || withoutPLT.shouldSplitPTCLDownstream(g) {
		t.Fatal("PLT-only removal disabled a separate mechanism")
	}
	if a.IssuedBitMap != b.IssuedBitMap || b.IssuedBitMap != withoutPLT.fullBitmap() {
		t.Fatal("PLT-only removal changed the group coverage")
	}
	if len(withPLT.pteLookupWaitingQueue) != 1 || len(withoutPLT.pteLookupWaitingQueue) != 8 || g.remainingJobs != 8 {
		t.Fatal("expected one PLT job versus eight per-sector full-way jobs")
	}
	for bit, job := range withoutPLT.pteLookupWaitingQueue {
		if !job.fullWayLookup || job.ptclSetLookup || job.bit != bit || job.vAddr != uint64(bit)*4096 {
			t.Fatalf("incorrect full-way job: %+v", job)
		}
	}
	stats := withoutPLT.PLTStudyStats()
	if stats["plt_total_rows"] != 0 || stats["plt_lookup_disabled"] != 1 {
		t.Fatalf("incorrect PLT-disabled statistics: %v", stats)
	}
}

// The wrapper fails if a functional tag index replaces physical way inspection.
type fullWayOnlySet struct {
	internal.Set
	peeks int
}

func (s *fullWayOnlySet) Lookup(vm.PID, uint64) (int, vm.Page, bool) {
	panic("full-way lookup used the software tag index")
}

func (s *fullWayOnlySet) Peek(way int) (vm.Page, bool) {
	s.peeks++
	return s.Set.Peek(way)
}

func TestPLTDisabledInspectsAllWaysAndExactTags(t *testing.T) {
	tlb := newPLTTestTLB(true)
	s := &fullWayOnlySet{Set: internal.NewSet(4)}
	want := pltTestPage(1, 0)
	s.Update(0, want)
	s.Update(1, pltTestPage(2, 0))
	s.Update(2, pltTestPage(1, 0x10000))
	invalid := pltTestPage(3, 0)
	invalid.Valid = false
	s.Update(3, invalid)
	tlb.Sets[0] = s
	for _, tc := range []struct {
		pid   vm.PID
		addr  uint64
		found bool
	}{{1, 0, true}, {2, 0, true}, {3, 0, false}, {1, 0x20000, false}} {
		before := s.peeks
		_, page, found := tlb.lookupPTEFullWays(tc.pid, tc.addr)
		if found != tc.found || s.peeks-before != 4 {
			t.Fatalf("pid=%d addr=%x: found=%v, reads=%d", tc.pid, tc.addr, found, s.peeks-before)
		}
		if found && (!page.Valid || page.PID != tc.pid || page.VAddr != tc.addr) {
			t.Fatal("wrong address space or invalid page returned")
		}
	}
	if tlb.fullWayLookupJobs != 4 || tlb.fullWayTagComparisons != 16 {
		t.Fatal("comparison counters did not count all ways")
	}
}

func TestPLTDisabledKeepsEntryUntilAllSectorsFinish(t *testing.T) {
	tlb := newPLTTestTLB(true)
	tlb.installPage(pltTestPage(1, 0))
	r, entry := enqueuePLTTestRequest(tlb, 0)
	jobs := append([]pteLookupJob(nil), tlb.pteLookupWaitingQueue...)
	tlb.pteLookupWaitingQueue = nil
	tlb.processReadyPTELookupJob(1, jobs[0])
	if !entry.ResponseBitMap[0] || tlb.mshr.GetEntry(1, 0) != entry || len(tlb.respondingMSHREntry) != 0 {
		t.Fatal("first sector prematurely retired the entry")
	}
	// The normal late-arrival path also invokes scheduleReadyMSHREntry.
	late := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(0).Build()
	entry.Requests = append(entry.Requests, late)
	tlb.mshr.UpdateUpLevelBitMap(1, 0, 1, 0)
	tlb.enqueuePTELookupJobs(1, late, entry)
	if tlb.scheduleReadyMSHREntry(1, entry, false) {
		t.Fatal("late same-VPN request retired an entry with sector jobs in flight")
	}
	for _, job := range jobs[1:] {
		tlb.processReadyPTELookupJob(2, job)
	}
	if tlb.mshr.GetEntry(1, 0) != nil || len(tlb.respondingMSHREntry) != 1 || tlb.respondingMSHREntry[0] != entry {
		t.Fatal("entry did not retire exactly once after the last sector")
	}
	if len(tlb.pteLookupReadyToIssue) != 0 || tlb.pteLookupGroups[tlb.pteLookupGroupKey(r.PID, r.VAddr)] != nil {
		t.Fatal("speculative missing offsets generated an undemanded walk")
	}
}

func TestPLTDisabledLateDifferentOffsetKeepsOneRepresentative(t *testing.T) {
	tlb := newPLTTestTLB(true)
	tlb.installPage(pltTestPage(1, 0))
	r, entry := enqueuePLTTestRequest(tlb, 0)
	jobs := append([]pteLookupJob(nil), tlb.pteLookupWaitingQueue...)
	tlb.pteLookupWaitingQueue = nil
	for _, job := range jobs[:4] {
		tlb.processReadyPTELookupJob(1, job)
	}
	// Offset two was already probed as a speculative miss; seven has not been probed.
	for _, bit := range []int{2, 7} {
		late := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(uint64(bit) * 4096).Build()
		tlb.mshr.UpdateUpLevelBitMap(1, late.VAddr, 1, 0)
		entry.Requests = append(entry.Requests, late)
		tlb.enqueuePTELookupJobs(1, late, entry)
	}
	for _, job := range jobs[4:] {
		tlb.processReadyPTELookupJob(2, job)
	}
	g := tlb.pteLookupGroups[tlb.pteLookupGroupKey(r.PID, r.VAddr)]
	if g == nil || g.missBitmap != ([8]bool{2: true, 7: true}) || len(tlb.pteLookupReadyToIssue) != 1 {
		t.Fatalf("late demands were lost or speculative misses became demands: %+v", g)
	}
	if tlb.bitmapCount(tlb.downstreamBitmapForLookupGroup(g)) != 1 || tlb.shouldSplitPTCLDownstream(g) ||
		tlb.ptclCoveredBitmapForLookupGroup(g) != tlb.fullBitmap() {
		t.Fatal("PLT-only removal changed representative downstream grouping")
	}
	if len(tlb.pteLookupWaitingQueue) != 0 || tlb.mshr.GetEntry(1, 0) != entry {
		t.Fatal("late request duplicated sector work or lost its entry")
	}
}

func TestPLTDisabledRespectsLookupSlotsAndLatency(t *testing.T) {
	tlb := newPLTTestTLB(true)
	tlb.installPage(pltTestPage(1, 0))
	_, entry := enqueuePLTTestRequest(tlb, 0)
	start := tlb.Freq.NCyclesLater(1, 0)
	tlb.advancePTELookups(start)
	tlb.advancePTELookups(start)
	if len(tlb.pteLookupInflight) != 2 || len(tlb.pteLookupWaitingQueue) != 6 {
		t.Fatal("two finite lookup slots were not respected")
	}
	if tlb.advancePTELookups(start) || tlb.advancePTELookups(tlb.Freq.NCyclesLater(31, start)) || entry.ResponseBitMap[0] {
		t.Fatal("lookup bypassed finite slots or completed before its latency")
	}
	if !tlb.advancePTELookups(tlb.Freq.NCyclesLater(32, start)) || !entry.ResponseBitMap[0] {
		t.Fatal("lookup failed to complete after 32 cycles")
	}
}

func TestPLTShadowDoesNotRepairFalseMissOrChangeCache(t *testing.T) {
	a, b := newPLTTestTLB(false), newPLTTestTLB(false)
	b.pltShadow = true
	for _, tlb := range []*GMMUTLB{a, b} {
		tlb.installPage(pltTestPage(1, 0))
		// Model loss of locator metadata without loss of the resident PTE.
		tlb.pcd = newPTCLCoverageDirectory(16, 4, 0, 12, 8)
	}
	bits := [8]bool{0: true}
	x := a.lookupPTCLWithPCD(1, 0, bits, bits)
	y := b.lookupPTCLWithPCD(1, 0, bits, bits)
	if !reflect.DeepEqual(x, y) || y.HitBitmap[0] || !y.MissBitmap[0] {
		t.Fatal("shadow observation changed the lookup result")
	}
	if !reflect.DeepEqual(a.Sets, b.Sets) || !reflect.DeepEqual(a.pcd, b.pcd) {
		t.Fatal("shadow observation changed contents or replacement state")
	}
	s := b.PLTStudyStats()
	if s["plt_false_miss_bits"] != 1 || s["plt_demand_probes"] != 1 || s["plt_oracle_recovered_bits"] != 0 {
		t.Fatalf("incorrect shadow counts: %v", s)
	}
}

func TestPLTShadowExcludesUndemandedAndOutOfLookupOffsets(t *testing.T) {
	tlb := newPLTTestTLB(false)
	tlb.pltShadow = true
	lookup := [8]bool{0: true, 1: true}
	demand := [8]bool{0: true, 2: true}
	result := pcdLookupResult{HitBitmap: [8]bool{0: true}, MissBitmap: [8]bool{2: true}}
	tlb.observePLTLookup(1, 0, lookup, demand, &result)
	if tlb.pltMeasurements.DemandProbes != 1 || tlb.pltMeasurements.DemandHits != 1 || tlb.pltMeasurements.DemandMisses != 0 {
		t.Fatal("false-miss denominator included an undemanded or unprobed offset")
	}
}

func TestPLTDisabledRejectsIncompatibleControls(t *testing.T) {
	for name, b := range map[string]Builder{
		"no-flex":     MakeBuilder().WithPLTDisabled(true),
		"ideal":       MakeBuilder().WithFlexTLB(true).WithPLTDisabled(true).WithPLTStudy(0, false, true),
		"extra-delay": MakeBuilder().WithFlexTLB(true).WithPLTDisabled(true).WithPLTStudy(1, false, false),
	} {
		t.Run(name, func(t *testing.T) {
			defer func() {
				if recover() == nil {
					t.Fatal("incompatible PLT-only removal was accepted")
				}
			}()
			b.Build("InvalidPLTConfig")
		})
	}
}
