package mmuTLB

import (
	"fmt"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/translationtrace"
	"github.com/sarchlab/akita/v3/sim"
)

type demandTestPort struct {
	sim.Port
	sent   []sim.Msg
	reject bool
}

func (p *demandTestPort) Send(msg sim.Msg) *sim.SendError {
	if p.reject {
		return sim.NewSendError()
	}
	p.sent = append(p.sent, msg)
	return nil
}

func demandTestTLB(t *testing.T, coalescing bool) (*TLB, *demandTestPort, *demandTestPort) {
	t.Helper()
	translationtrace.Configure(false, "", 100000)
	t.Cleanup(func() { translationtrace.Configure(false, "", 100000) })
	pt := vm.NewPageTable(12)
	for pid := vm.PID(1); pid <= 2; pid++ {
		for bit := uint64(0); bit < 8; bit++ {
			pt.Insert(vm.Page{PID: pid, VAddr: bit * 4096, PAddr: uint64(pid)*0x100000 + bit*4096,
				PageSize: 4096, Valid: true, DeviceID: 3})
		}
	}
	tlb := MakeBuilder().WithEngine(sim.NewSerialEngine()).WithPageTable(pt).
		WithNumSets(64).WithNumWays(32).WithNumMSHREntry(64).WithMSHREntryDepth(64).
		WithNumReqPerCycle(32).WithLookupLatencyCycles(80).
		WithPerVPNMSHRBaseline(!coalescing).WithSetAsLineTLB(false).WithDemandPTEOnly(true).
		WithLowModule(sim.NewLimitNumMsgPort(nil, 64, "Demand.Upper")).Build("Demand.IOTLB")
	top := &demandTestPort{Port: tlb.topPort}
	bottom := &demandTestPort{Port: tlb.bottomPort}
	tlb.topPort, tlb.bottomPort = top, bottom
	return tlb, top, bottom
}

func TestMSHROnlyIOTLBRetainsEachSourceAndDemand(t *testing.T) {
	for _, coalescing := range []bool{false, true} {
		t.Run(fmt.Sprint(coalescing), func(t *testing.T) {
			tlb, top, bottom := demandTestTLB(t, coalescing)
			var requests []*vm.TranslationReq
			for n, spec := range []struct{ pid, bit, gpm int }{{1, 0, 1}, {1, 2, 1}, {1, 0, 2}, {2, 2, 2}} {
				src := sim.NewLimitNumMsgPort(nil, 8, fmt.Sprintf("GPM%d.Source%d", spec.gpm, n))
				bitmap := [8]bool{}
				bitmap[spec.bit] = true
				r := vm.TranslationReqBuilder{}.WithPID(vm.PID(spec.pid)).WithVAddr(uint64(spec.bit) * 4096).
					WithDeviceID(uint64(spec.gpm)).WithSrc(src).WithDst(top).WithOriginPort(src).
					WithTaskID(fmt.Sprintf("r%d", n)).WithBitMap(bitmap).Build()
				requests = append(requests, r)
				if top.Recv(r) != nil || !tlb.pushReqBuffer(0) {
					t.Fatal("request not buffered")
				}
			}
			if tlb.lookup(79e-9) {
				t.Fatal("lookup latency was bypassed")
			}
			bottom.reject = true
			if tlb.lookup(80e-9) || len(bottom.sent) != 0 {
				t.Fatal("rejected request was admitted as sent")
			}
			bottom.reject = false
			for range requests {
				if !tlb.lookup(81e-9) {
					t.Fatal("ready demand not admitted")
				}
			}
			wantEntries := 3
			if coalescing {
				wantEntries = 2
			}
			if n, _ := tlb.mshr.Occupancy(); n != wantEntries || tlb.pcd != nil || len(bottom.sent) != 3 {
				t.Fatal("wrong MSHR occupancy, hidden PLT, or duplicate same-VPN walk")
			}
			for i := len(bottom.sent) - 1; i >= 0; i-- {
				r := bottom.sent[i].(*vm.TranslationReq)
				bits := 0
				for bit, needed := range r.BitMap {
					if !needed {
						continue
					}
					bits++
					page, found := tlb.pageTable.Find(r.PID, r.VAddr+uint64(bit)*4096)
					if !found || !tlb.handleRsp(100e-9, vm.TranslationRspBuilder{}.WithRspTo(r.ID).WithPage(page).Build()) {
						t.Fatal("demand response failed")
					}
				}
				if bits != 1 {
					t.Fatal("IOTLB expanded a demand to undemanded PTEs")
				}
			}
			top.reject = true
			if tlb.respondMSHREntry(101e-9) || len(top.sent) != 0 {
				t.Fatal("response bypassed blocked requester")
			}
			top.reject = false
			for range requests {
				if !tlb.respondMSHREntry(102e-9) {
					t.Fatal("response was lost")
				}
			}
			seen := map[string]bool{}
			for _, msg := range top.sent {
				rsp := msg.(*vm.TranslationRsp)
				var original *vm.TranslationReq
				for _, r := range requests {
					if r.ID == rsp.RespondTo {
						original = r
					}
				}
				if original == nil || seen[rsp.RespondTo] {
					t.Fatal("response identity lost or duplicated")
				}
				page, _ := tlb.pageTable.Find(original.PID, original.VAddr)
				if rsp.Page != page || rsp.Dst != original.Src || rsp.TaskID != original.TaskID || rsp.OriginPort != original.OriginPort {
					t.Fatal("response crossed address space or GPM")
				}
				seen[rsp.RespondTo] = true
			}
			if len(seen) != 4 || len(tlb.reqBuffer) != 0 || len(tlb.respondingMSHREntry) != 0 {
				t.Fatal("requests left after draining")
			}
			if n, _ := tlb.mshr.Occupancy(); n != 0 {
				t.Fatal("MSHR leaked")
			}
			t.Logf("MSHR_ONLY iotlb_coalescing=%v requests=4 unique_demands=3 downstream=3 initial_entries=%d", coalescing, wantEntries)
		})
	}
}

func TestLegacyMultiBitPacketIsTruncatedByDemandOnlyIOTLB(t *testing.T) {
	tlb, top, _ := demandTestTLB(t, false)
	r := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(0).WithBitMap([8]bool{0: true, 2: true, 5: true}).Build()
	if top.Recv(r) != nil || !tlb.pushReqBuffer(0) {
		t.Fatal("request not buffered")
	}
	if r.BitMap != ([8]bool{0: true}) {
		t.Fatal("legacy demand-only contract changed; reassess candidate compatibility")
	}
	t.Log("MSHR_ONLY legacy_multi_bit_input=0,2,5 demand_only_buffered=0 incompatible_candidate=true")
}
