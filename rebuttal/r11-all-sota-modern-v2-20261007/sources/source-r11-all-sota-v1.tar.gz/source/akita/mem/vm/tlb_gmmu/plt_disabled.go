package tlb_gmmu

import "github.com/sarchlab/akita/v3/mem/vm"

// lookupPTEFullWays reads every way rather than consulting the software tag index.
func (tlb *GMMUTLB) lookupPTEFullWays(pid vm.PID, vAddr uint64) (int, vm.Page, bool) {
	set := tlb.Sets[tlb.vAddrToSetIDForPID(pid, vAddr)]
	wayID := 0
	page := vm.Page{}
	found := false
	tlb.fullWayLookupJobs++
	for way := 0; way < tlb.numWays; way++ {
		candidate, ok := set.Peek(way)
		tlb.fullWayTagComparisons++
		if ok && candidate.Valid && candidate.PID == pid && candidate.VAddr == vAddr && !found {
			wayID, page, found = way, candidate, true
		}
	}
	return wayID, page, found
}
