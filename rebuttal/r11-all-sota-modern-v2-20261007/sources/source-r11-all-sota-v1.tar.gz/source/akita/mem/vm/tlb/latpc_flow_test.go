package tlb

import (
	"fmt"
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
	"testing"
)

func TestLATPCCompressedForwardAndReturn(t *testing.T) {
	for _, capacity := range []int{1, 128} {
		t.Run(fmt.Sprint(capacity), func(t *testing.T) { testLATPCFlow(t, capacity) })
	}
}

func testLATPCFlow(t *testing.T, replyCapacity int) {
	engine := sim.NewSerialEngine()
	lower := sim.NewLimitNumMsgPort(nil, 128, "LATPC.Lower")
	source := sim.NewLimitNumMsgPort(nil, replyCapacity, "LATPC.Source")
	l1 := MakeBuilder().WithEngine(engine).WithDeviceID(1).WithNumMSHREntry(1).WithLATPC(true).WithLowModule(lower).Build("LATPC.L1")
	link := sim.NewDirectConnection("LATPC.Link", engine, sim.GHz)
	for _, p := range []sim.Port{source, lower, l1.topPort, l1.bottomPort} {
		link.PlugIn(p, 128)
	}
	infos := vm.DetectLATPC([]uint64{8, 10, 12, 14, 16, 18, 20, 22})
	requests := map[string]uint64{}
	// One duplicate waiter and a distinct group beyond the one-entry limit.
	inputs := append(append([]vm.LATPCInfo{}, infos...), infos[1], vm.DetectLATPC([]uint64{515})[0])
	for _, info := range inputs {
		r := vm.TranslationReqBuilder{}.WithSrc(source).WithDst(l1.topPort).WithPID(1).WithDeviceID(1).
			WithVAddr(info.VPN << 12).WithLATPC(info).WithOriginPort(source).WithTaskID("warp").Build()
		requests[r.ID] = r.VAddr
		if source.Send(r) != nil {
			t.Fatal("send failed")
		}
	}
	if err := engine.Run(); err != nil {
		t.Fatal(err)
	}
	if len(l1.latpcEntries) != 1 || l1.latpcEntries[0].mask != 255 || l1.latpcStats.CompressedMisses != 7 ||
		l1.latpcStats.FullObservations == 0 || l1.latpcStats.HitUnderMiss != 1 {
		t.Fatalf("not compressed: %+v", l1.latpcStats)
	}
	count := 0
	for phase := 0; phase < 64 && len(requests) != 0; phase++ {
		for msg := lower.Retrieve(engine.CurrentTime()); msg != nil; msg = lower.Retrieve(engine.CurrentTime()) {
			r := msg.(*vm.TranslationReq)
			if !r.LATPC.Matches(r.VAddr >> 12) {
				t.Fatal("metadata lost")
			}
			page := vm.Page{Valid: true, PID: 1, VAddr: r.VAddr, PAddr: 0x100000 + r.VAddr, PageSize: 4096, DeviceID: 1}
			if lower.Send(vm.TranslationRspBuilder{}.WithSendTime(sim.GHz.NextTick(engine.CurrentTime())).WithSrc(lower).WithDst(l1.bottomPort).WithRspTo(r.ID).WithPage(page).Build()) != nil {
				t.Fatal("reply send failed")
			}
			count++
		}
		if phase == 0 && count != 8 {
			t.Fatalf("L2 must receive all 8 VPN requests, received %d", count)
		}
		if err := engine.Run(); err != nil {
			t.Fatal(err)
		}
		// External consumers resume after the last processed event, just as
		// a ticking requester would, so a blocked connection is reawakened.
		resume := sim.GHz.NextTick(engine.CurrentTime())
		for msg := source.Retrieve(resume); msg != nil; msg = source.Retrieve(resume) {
			r := msg.(*vm.TranslationRsp)
			address, ok := requests[r.RespondTo]
			if !ok || r.Page.VAddr != address {
				t.Fatal("duplicate or wrong requester reply")
			}
			delete(requests, r.RespondTo)
		}
	}
	if count != 9 || l1.latpcStats.PeakEntries != 1 {
		t.Fatal("distinct-group capacity or ordinary VPN forwarding violated")
	}
	if len(requests) != 0 || len(l1.latpcEntries) != 0 || len(l1.latpcPending) != 0 {
		t.Fatalf("lost reply or unreleased entry: requests=%d entries=%d pending=%d responding=%v bottom=%v time=%g", len(requests), len(l1.latpcEntries), len(l1.latpcPending), l1.respondingMSHREntry, l1.bottomPort.Peek(), engine.CurrentTime())
	}
}
