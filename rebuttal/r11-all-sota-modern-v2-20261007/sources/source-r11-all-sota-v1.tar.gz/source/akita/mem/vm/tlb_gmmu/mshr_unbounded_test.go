package tlb_gmmu

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
)

func TestUnboundedMSHRAdmitsBeyondFiniteSweep(t *testing.T) {
	m := newMSHR(0, 64, 12, true, 8)
	for i := 0; i < 2049; i++ {
		if m.IsFull() {
			t.Fatalf("unbounded MSHR became full after %d entries", i)
		}
		m.Add(vm.PID(1), uint64(i)*4096, 0, 0)
	}
	entries, capacity := m.Occupancy()
	if entries != 2049 || capacity != 0 || m.IsFull() {
		t.Fatalf("occupancy=(%d,%d), full=%v", entries, capacity, m.IsFull())
	}
	tlb := &GMMUTLB{mshr: m}
	stats := tlb.MSHRAdmissionStats()
	if stats["mshr_entries_peak"] != 2049 || stats["mshr_entry_capacity_unbounded"] != 1 {
		t.Fatalf("incorrect unbounded statistics: %v", stats)
	}
	m.Remove(vm.PID(1), 0)
	if tlb.MSHRAdmissionStats()["mshr_entries_peak"] != 2049 {
		t.Fatal("retirement erased peak occupancy")
	}
}

func TestUnboundedMSHRKeepsPerEntryRequesterLimit(t *testing.T) {
	m := newMSHR(0, 64, 12, true, 8)
	e := m.Add(vm.PID(1), 0x1000, 0, 0)
	e.Requests = make([]*vm.TranslationReq, 64)
	if !m.IsEntryFull(vm.PID(1), 0x1000) || m.IsFull() {
		t.Fatal("entry-count diagnostic changed per-entry requester backpressure")
	}
}

func TestUnboundedMSHRPreservesVPNAndAddressSpaceKeys(t *testing.T) {
	m := newMSHR(0, 64, 12, true, 8)
	a := m.Add(vm.PID(1), 0x1000, 0, 0)
	if m.Add(vm.PID(1), 0x1008, 0, 0) != a {
		t.Fatal("same VPN allocated another entry")
	}
	b := m.Add(vm.PID(1), 0x2000, 0, 0)
	c := m.Add(vm.PID(2), 0x1000, 0, 0)
	if a == b || a == c || b == c {
		t.Fatal("distinct VPNs or address spaces merged")
	}
	if n, _ := m.Occupancy(); n != 3 {
		t.Fatalf("entry count=%d, want 3", n)
	}
}

func TestFiniteMSHRRetainsCapacityBackpressure(t *testing.T) {
	m := newMSHR(2, 64, 12, true, 8)
	m.Add(vm.PID(1), 0x1000, 0, 0)
	if m.IsFull() {
		t.Fatal("finite MSHR full too early")
	}
	m.Add(vm.PID(1), 0x2000, 0, 0)
	if !m.IsFull() {
		t.Fatal("finite capacity limit removed")
	}
	m.Remove(vm.PID(1), 0x1000)
	if m.IsFull() {
		t.Fatal("retired entry did not release capacity")
	}
	m.Add(vm.PID(1), 0x3000, 0, 0)
	if (&GMMUTLB{mshr: m}).MSHRAdmissionStats()["mshr_entry_capacity_unbounded"] != 0 {
		t.Fatal("finite MSHR mislabeled unbounded")
	}
}

func TestFiniteMSHROverflowStillPanics(t *testing.T) {
	m := newMSHR(1, 64, 12, true, 8)
	m.Add(vm.PID(1), 0x1000, 0, 0)
	defer func() {
		if recover() == nil {
			t.Fatal("finite overflow was accepted")
		}
	}()
	m.Add(vm.PID(1), 0x2000, 0, 0)
}

func TestNegativeMSHRCapacityRejected(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Fatal("negative capacity accepted")
		}
	}()
	newMSHR(-1, 64, 12, true, 8)
}

func TestBuilderPreservesUnboundedCapacity(t *testing.T) {
	tlb := MakeBuilder().WithNumMSHREntry(0).WithPerVPNMSHRBaseline(true).Build("IdealL2")
	_, capacity := tlb.mshr.Occupancy()
	if capacity != 0 || tlb.mshr.IsFull() {
		t.Fatal("builder did not preserve the entry-unbounded diagnostic")
	}
}
