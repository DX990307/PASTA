package gmmu

import (
	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
	"testing"
)

func TestLATPCLocalBatchReplies(t *testing.T) {
	for _, enabled := range []bool{false, true} {
		engine := sim.NewSerialEngine()
		source := sim.NewLimitNumMsgPort(nil, 128, "LATP.Source")
		table := vm.NewPageTable(12)
		g := MakeBuilder().WithEngine(engine).WithPageTable(table).WithDeviceID(1).
			WithPageWalkingLatency(500).WithMaxNumReqInFlight(1).WithDemandPTEOnly(true).WithLATPC(enabled).Build("LATP.GMMU")
		link := sim.NewDirectConnection("LATP.Link", engine, sim.GHz)
		link.PlugIn(source, 128)
		link.PlugIn(g.topPort, 128)
		vpns := []uint64{8, 10, 12, 14, 16, 18, 20, 22}
		requests := map[string]uint64{}
		for _, info := range vm.DetectLATPC(vpns) {
			table.Insert(vm.Page{Valid: true, PID: 1, VAddr: info.VPN << 12, PAddr: (info.VPN + 256) << 12, PageSize: 4096, DeviceID: 1})
			r := vm.TranslationReqBuilder{}.WithSrc(source).WithDst(g.topPort).WithPID(1).WithVAddr(info.VPN << 12).WithDeviceID(1).Build()
			if enabled {
				r.LATPC = info
			}
			requests[r.ID] = r.VAddr
			if source.Send(r) != nil {
				t.Fatal("send failed")
			}
		}
		if err := engine.Run(); err != nil {
			t.Fatal(err)
		}
		for msg := source.Retrieve(engine.CurrentTime()); msg != nil; msg = source.Retrieve(engine.CurrentTime()) {
			r := msg.(*vm.TranslationRsp)
			va, ok := requests[r.RespondTo]
			if !ok || va != r.Page.VAddr {
				t.Fatal("wrong or duplicate response")
			}
			delete(requests, r.RespondTo)
		}
		if len(requests) != 0 || g.PTWInflight() != 0 {
			t.Fatal("unfinished requests")
		}
		if enabled && (g.latpcMerged != 7 || engine.CurrentTime() > 600e-9) {
			t.Fatal("batch not serviced")
		}
		if !enabled && engine.CurrentTime() < 4000e-9 {
			t.Fatal("baseline timing changed")
		}
	}
}
