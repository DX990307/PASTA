package tlb_gmmu

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/mem/vm/tlb_gmmu/internal"
	"github.com/sarchlab/akita/v3/sim"
)

type pltCostSet struct {
	internal.Set
	peeks, lookups, updates int
}

func (s *pltCostSet) Peek(way int) (vm.Page, bool) {
	s.peeks++
	return s.Set.Peek(way)
}

func (s *pltCostSet) Lookup(pid vm.PID, addr uint64) (int, vm.Page, bool) {
	s.lookups++
	return s.Set.Lookup(pid, addr)
}

func (s *pltCostSet) Update(way int, page vm.Page) {
	s.updates++
	s.Set.Update(way, page)
}

func newPLTCostTLB() *GMMUTLB {
	pt := vm.NewPageTable(12)
	for bit := 0; bit < 16; bit++ {
		pt.Insert(pltTestPage(1, uint64(bit)*4096))
	}
	return MakeBuilder().WithEngine(sim.NewSerialEngine()).WithNumSets(16).
		WithNumWays(16).WithLog2PageSize(12).WithPageTable(pt).
		WithPTELookupSlots(8).WithPTELookupLatencyCycles(32).
		WithFlexTLB(true).WithInitialPTCLMode(true).Build("PLTCost")
}

// Characterize the inherited countdown model, not a physical port budget.
func TestLegacyPLTCountdownDoesNotSerializeCandidateReads(t *testing.T) {
	tlb := newPLTCostTLB()
	sets := make([]*pltCostSet, len(tlb.Sets))
	for index, set := range tlb.Sets {
		addr := uint64(index) * 4096
		set.Update(0, pltTestPage(2, addr))
		set.Update(1, pltTestPage(1, addr))
		sets[index] = &pltCostSet{Set: set}
		tlb.Sets[index] = sets[index]
	}
	for _, base := range []uint64{0, 8 * 4096} {
		set := tlb.pcd.setForLine(1, base)
		if len(set.entries) != 2 {
			t.Fatal("default 16-way cache must have two locator rows per set")
		}
		for row := range set.entries {
			set.entries[row].valid = true
			for bit := 0; bit < 8; bit++ {
				set.entries[row].presentBitmap[bit] = true
				set.entries[row].locators[bit].wayID = row
			}
		}
		enqueuePLTTestRequest(tlb, base)
	}
	for i := 0; i < 2; i++ {
		if !tlb.advancePTELookups(0) {
			t.Fatal("lookup did not start")
		}
	}
	ready := tlb.Freq.NCyclesLater(64, 0)
	for _, job := range tlb.pteLookupInflight {
		if job.readyTime != ready {
			t.Fatal("inherited PLT latency was not 64 cycles")
		}
	}
	if tlb.advancePTELookups(tlb.Freq.NCyclesLater(63, 0)) {
		t.Fatal("lookup completed before its countdown")
	}
	for i := 0; i < 2; i++ {
		if !tlb.advancePTELookups(ready) {
			t.Fatal("same-cycle completion unexpectedly consumed another port cycle")
		}
	}
	peeks := 0
	for _, set := range sets {
		peeks += set.peeks
	}
	if peeks != 32 || tlb.pltMeasurements.CandidateValidations != 32 || tlb.pcdStaleBits != 16 {
		t.Fatalf("candidate/cleanup work: peeks=%d candidates=%d stale=%d", peeks,
			tlb.pltMeasurements.CandidateValidations, tlb.pcdStaleBits)
	}
	if len(tlb.pteLookupInflight) != 0 || len(tlb.respondingMSHREntry) != 2 {
		t.Fatal("two ready groups were not completed")
	}
	t.Log("Two 64-cycle PLT jobs performed 32 candidate reads and 16 stale-bit cleanups at one ready timestamp")
}

func TestLegacyPLTFillPerformsUntimedPTEValidation(t *testing.T) {
	tlb := newPLTCostTLB()
	for index, set := range tlb.Sets {
		addr := uint64(index) * 4096
		set.Update(0, pltTestPage(2, addr))
		set.Update(1, pltTestPage(1, addr))
		tlb.Sets[index] = &pltCostSet{Set: set}
	}
	rows := tlb.pcd.setForLine(1, 0)
	for index := range rows.entries {
		rows.entries[index].valid = true
		rows.entries[index].presentBitmap[0] = true
		rows.entries[index].locators[0].wayID = index
	}
	if !tlb.installPage(pltTestPage(1, 7*4096)) {
		t.Fatal("fill failed")
	}
	peeks, lookups, updates := 0, 0, 0
	for _, raw := range tlb.Sets {
		set := raw.(*pltCostSet)
		peeks += set.peeks
		lookups += set.lookups
		updates += set.updates
	}
	if peeks != 2 || lookups != 1 || updates != 1 || !rows.entries[1].presentBitmap[7] {
		t.Fatalf("fill work: peeks=%d lookups=%d updates=%d", peeks, lookups, updates)
	}
	if len(tlb.pteLookupWaitingQueue) != 0 || len(tlb.pteLookupInflight) != 0 {
		t.Fatal("inherited maintenance unexpectedly scheduled timed work")
	}
	t.Log("One fill performed one tag lookup, one PTE update, two locator-validation PTE reads, and a locator update without a timed maintenance job")
}
