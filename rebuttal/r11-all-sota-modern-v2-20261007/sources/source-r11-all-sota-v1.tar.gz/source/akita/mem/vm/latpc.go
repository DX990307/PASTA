package vm

// LATPCInfo describes one unique VPN in the lane-ordered instruction stream.
type LATPCInfo struct {
	Valid        bool
	VPN, BaseVPN uint64
	Stride       uint16
	Index        uint8
}

func (i LATPCInfo) Matches(vpn uint64) bool {
	return i.Valid && i.Index < 32 && i.Stride < 512 && i.VPN == vpn &&
		i.BaseVPN>>9 == vpn>>9 && ((i.BaseVPN&511)+uint64(i.Stride)*uint64(i.Index))&511 == vpn&511
}

// DetectLATPC implements Fig.12; callers supply unique VPNs in lane order.
// Native 64-lane waves are split at the 32-VPN mask limit, without sorting.
func DetectLATPC(vpns []uint64) []LATPCInfo {
	result := make([]LATPCInfo, len(vpns))
	var base, prev uint64
	var stride uint16
	var index uint8
	for n, vpn := range vpns {
		delta := uint16((vpn - prev) & 511)
		if n == 0 || n%32 == 0 || vpn>>9 != base>>9 ||
			(stride != 0 && delta != stride) || delta == 0 || index == 31 {
			base, stride, index = vpn, 0, 0
		} else {
			stride, index = delta, index+1
		}
		result[n] = LATPCInfo{Valid: true, VPN: vpn, BaseVPN: base, Stride: stride, Index: index}
		prev = vpn
	}
	return result
}

// LATPCBatch keeps at most 32 distinct VPNs in one abstract walker slot.
type LATPCBatch struct {
	PID     PID
	BaseVPN uint64
	Stride  uint16
	Mask    uint32
	Members []*TranslationReq
}

func NewLATPCBatch(req *TranslationReq) *LATPCBatch {
	i := req.LATPC
	if !i.Matches(i.VPN) {
		return nil
	}
	return &LATPCBatch{PID: req.PID, BaseVPN: i.BaseVPN, Stride: i.Stride, Mask: uint32(1) << i.Index}
}

func (b *LATPCBatch) Add(req *TranslationReq) bool {
	if b == nil {
		return false
	}
	i := req.LATPC
	if !i.Matches(i.VPN) || b.PID != req.PID || b.BaseVPN != i.BaseVPN ||
		(b.Stride != 0 && b.Stride != i.Stride) || b.Mask&(uint32(1)<<i.Index) != 0 {
		return false
	}
	b.Stride = i.Stride
	b.Mask |= uint32(1) << i.Index
	b.Members = append(b.Members, req)
	return true
}
