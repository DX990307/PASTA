package switching

import (
	"fmt"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/noc/networking/arbitration"
	"github.com/sarchlab/akita/v3/noc/networking/routing"
	"github.com/sarchlab/akita/v3/sim"
)

func TestInheritedSwitchLatencyAlsoChangesInFlightStorage(t *testing.T) {
	const width = 48
	for _, stages := range []int{16, 32, 64} {
		engine := sim.NewSerialEngine()
		sw := SwitchBuilder{}.WithEngine(engine).WithFreq(sim.GHz).
			WithRoutingTable(routing.NewTable()).WithArbiter(arbitration.NewXBarArbiter()).Build("ResourceControl")
		local := sim.NewLimitNumMsgPort(sw, width, "Local")
		remote := sim.NewLimitNumMsgPort(nil, width, "Remote")
		MakeSwitchPortAdder(sw).WithPorts(local, remote).WithLatency(stages).
			WithNumInputChannel(width).WithNumOutputChannel(width).AddPort()
		pc := sw.portToComplexMapping[local]
		accepted := 0
		// Keep the route buffer blocked and count all accepted pipeline entries.
		for cycle := 0; cycle < stages+8; cycle++ {
			now := sim.VTimeInSec(cycle) * 1e-9
			pc.pipeline.Tick(now)
			for lane := 0; lane < width && pc.pipeline.CanAccept(); lane++ {
				pc.pipeline.Accept(now, flitPipelineItem{taskID: fmt.Sprint(accepted)})
				accepted++
			}
		}
		t.Logf("switch_stages=%d pipeline_capacity_flits=%d route_buffer_flits=%d blocked_population=%d",
			stages, stages*width, width, accepted)
		if accepted != (stages+1)*width || pc.pipeline.CanAccept() {
			t.Fatal("inherited pipeline storage/backpressure differs from stage count times width")
		}
	}
}

// This characterizes an inherited limit, not a claim of finite endpoint storage.
func TestInheritedEndpointFlitQueueIsNotItsMessageAdmissionLimit(t *testing.T) {
	const width = 48
	engine := sim.NewSerialEngine()
	port := sim.NewLimitNumMsgPort(nil, width, "Source")
	dst := sim.NewLimitNumMsgPort(nil, width, "Destination")
	ep := MakeEndPointBuilder().WithEngine(engine).WithFreq(sim.GHz).WithFlitByteSize(16).
		WithNumInputChannels(width).WithNumOutputChannels(width).WithDevicePorts([]sim.Port{port}).Build("EndpointControl")
	accepted := 0
	for batch := 0; batch < 4; batch++ {
		for i := 0; i < width; i++ {
			req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(uint64(accepted) * 4096).
				WithSrc(port).WithDst(dst).Build()
			if ep.Send(req) != nil {
				t.Fatal("unexpected message admission failure")
			}
			accepted++
		}
		if ep.CanSend(port) {
			t.Fatal("message input buffer exceeded its configured limit")
		}
		if !ep.prepareFlits(0) || !ep.CanSend(port) {
			t.Fatal("expected conversion to move messages out of the admission buffer")
		}
	}
	if len(ep.flitsToSend) != accepted || len(ep.msgOutBuf) != 0 {
		t.Fatal("one-flit translation requests were lost during conversion")
	}
	t.Logf("message_admission_slots=%d accepted_without_network_drain=%d unsent_flits=%d",
		ep.msgOutBufSize, accepted, len(ep.flitsToSend))
	if len(ep.flitsToSend) <= ep.msgOutBufSize {
		t.Fatal("inherited endpoint buffering changed; revise this characterization and the audit")
	}
}
