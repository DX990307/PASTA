// Package trafficstats collects read-only network task observations.
package trafficstats

import (
	"sync"

	"github.com/sarchlab/akita/v3/noc/messaging"
	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

// Counter separates incomplete observations from completed latency samples.
type Counter struct {
	Started, Completed, Inflight, DuplicateStarts uint64
	DeclaredBytes, ZeroByteMessages               uint64
	Seconds, MaxSeconds                           float64
	InvalidDurations                              uint64
}

type observation struct {
	start sim.VTimeInSec
	key   string
}

// Tracer uses existing task hooks; it never sends, schedules, or mutates messages.
// A classifier must be read-only and return a bounded set of labels.
type Tracer struct {
	mu       sync.Mutex
	clock    sim.TimeTeller
	classify func(sim.Msg) string
	forward  tracing.Tracer
	active   map[string]observation
	counts   map[string]Counter
}

// A nil clock is only for replaying explicitly timestamped tasks.
func New(clock sim.TimeTeller, classify func(sim.Msg) string, forward tracing.Tracer) *Tracer {
	return &Tracer{clock: clock, classify: classify, forward: forward,
		active: make(map[string]observation), counts: make(map[string]Counter)}
}

func (t *Tracer) StartTask(task tracing.Task) {
	if t.clock != nil {
		task.StartTime = t.clock.CurrentTime()
	}
	if t.forward != nil {
		t.forward.StartTask(task)
	}
	var stage string
	var msg sim.Msg
	switch {
	case task.Kind == "msg_e2e":
		stage = "message_e2e"
		msg, _ = task.Detail.(sim.Msg)
	case task.Kind == "flit_e2e":
		stage = "flit_e2e"
	case task.Kind == "flit" && task.What == "flit_inside_sw":
		stage = "switch_flit"
	case task.What == "flit_through_channel":
		stage = "channel_flit"
	default:
		return
	}
	if stage != "message_e2e" {
		flit, ok := task.Detail.(*messaging.Flit)
		if !ok || flit == nil {
			return
		}
		msg = flit.Msg
	}
	if msg == nil {
		return
	}
	class := "all"
	if t.classify != nil {
		class = t.classify(msg)
	}
	key := stage + "." + class
	t.mu.Lock()
	defer t.mu.Unlock()
	if previous, exists := t.active[task.ID]; exists {
		// Legacy endpoint hooks may repeat starts for queued, not-yet-sent flits.
		count := t.counts[previous.key]
		count.DuplicateStarts++
		t.counts[previous.key] = count
		return
	}
	t.active[task.ID] = observation{start: task.StartTime, key: key}
	count := t.counts[key]
	count.Started++
	count.Inflight++
	if stage == "message_e2e" {
		if msg.Meta().TrafficBytes > 0 {
			count.DeclaredBytes += uint64(msg.Meta().TrafficBytes)
		} else {
			count.ZeroByteMessages++
		}
	}
	t.counts[key] = count
}

func (t *Tracer) StepTask(task tracing.Task) {
	if t.forward != nil {
		t.forward.StepTask(task)
	}
}

func (t *Tracer) EndTask(task tracing.Task) {
	if t.clock != nil {
		task.EndTime = t.clock.CurrentTime()
	}
	if t.forward != nil {
		t.forward.EndTask(task)
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	active, exists := t.active[task.ID]
	if !exists {
		return
	}
	delete(t.active, task.ID)
	count := t.counts[active.key]
	count.Inflight--
	count.Completed++
	duration := float64(task.EndTime - active.start)
	if duration < 0 {
		count.InvalidDurations++
	} else {
		count.Seconds += duration
		if duration > count.MaxSeconds {
			count.MaxSeconds = duration
		}
	}
	t.counts[active.key] = count
}

// Snapshot copies counters without flushing, advancing, or changing any task.
func (t *Tracer) Snapshot() map[string]Counter {
	t.mu.Lock()
	defer t.mu.Unlock()
	result := make(map[string]Counter, len(t.counts))
	for name, count := range t.counts {
		result[name] = count
	}
	return result
}
