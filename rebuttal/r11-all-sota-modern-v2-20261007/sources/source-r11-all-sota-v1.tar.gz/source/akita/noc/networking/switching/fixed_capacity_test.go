package switching

import (
	"fmt"
	"testing"

	"github.com/sarchlab/akita/v3/noc/networking/arbitration"
	"github.com/sarchlab/akita/v3/noc/networking/routing"
	"github.com/sarchlab/akita/v3/sim"
)

func TestSwitchFixedIngressCapacityIndependentOfLatency(t *testing.T) {
	const width, capacity = 48, 1536
	for _, latency := range []int{16, 32, 64} {
		engine := sim.NewSerialEngine()
		sw := SwitchBuilder{}.WithEngine(engine).WithFreq(sim.GHz).
			WithRoutingTable(routing.NewTable()).WithArbiter(arbitration.NewXBarArbiter()).Build("FixedResourceControl")
		local := sim.NewLimitNumMsgPort(sw, width, "Local")
		remote := sim.NewLimitNumMsgPort(nil, width, "Remote")
		MakeSwitchPortAdder(sw).WithPorts(local, remote).WithLatency(latency).
			WithFixedIngressCapacity(capacity).WithNumInputChannel(width).WithNumOutputChannel(width).AddPort()
		pc := sw.portToComplexMapping[local]
		accepted := 0
		for cycle := 0; cycle < 200; cycle++ {
			now := sim.VTimeInSec(cycle) / 1e9
			pc.pipeline.Tick(now)
			for pc.pipeline.CanAccept() {
				pc.pipeline.Accept(now, flitPipelineItem{taskID: fmt.Sprint(accepted)})
				accepted++
			}
		}
		if accepted != capacity+width || pc.pipeline.CanAccept() {
			t.Fatalf("latency %d: accepted %d", latency, accepted)
		}
		t.Logf("latency=%d fixed_pipeline_capacity=%d route_buffer=%d blocked_population=%d", latency, capacity, width, accepted)
		for i := 0; i < accepted; i++ {
			if i%width == 0 {
				pc.pipeline.Tick(sim.VTimeInSec(1000+i/width) / 1e9)
			}
			item := pc.routeBuffer.Pop()
			if item == nil || item.(flitPipelineItem).taskID != fmt.Sprint(i) {
				t.Fatalf("lost/reordered flit %d", i)
			}
		}
	}
}
