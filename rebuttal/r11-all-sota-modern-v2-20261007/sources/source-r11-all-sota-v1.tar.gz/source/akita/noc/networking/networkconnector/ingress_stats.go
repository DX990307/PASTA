package networkconnector

// FixedIngressStats returns a read-only snapshot of fixed-capacity ingress queues.
func (c *Connector) FixedIngressStats() map[string]map[string]uint64 {
	result := make(map[string]map[string]uint64)
	for _, node := range c.switches {
		for name, stats := range node.sw.FixedIngressStats() {
			result[name] = stats
		}
	}
	return result
}
