package mesh

import (
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/noc/networking/trafficstats"
	"github.com/sarchlab/akita/v3/sim"
)

// Reproduce the inherited runner's duplicate shared-port registration and its
// use of destination.Send(req), independently of any GPU workload or PTW cost.
func TestSharedPortRegistrationAndSendingPortDetermineActualPath(t *testing.T) {
	for _, test := range []struct {
		name                       string
		duplicate, destinationSend bool
		hops                       uint64
	}{
		{"correct_source_and_unique_destination", false, false, 1},
		{"duplicate_destination_only", true, false, 2},
		{"destination_send_only", false, true, 0},
		{"inherited_both_errors", true, true, 0},
	} {
		t.Run(test.name, func(t *testing.T) {
			engine := sim.NewSerialEngine()
			a, b, central := newLatencyTestPeer(engine, "GPU0"), newLatencyTestPeer(engine, "GPU1"), newLatencyTestPeer(engine, "IOMMU")
			observer := trafficstats.New(engine, nil, nil)
			c := NewConnector().WithEngine(engine).WithFreq(sim.GHz).WithFlitSize(16).
				WithBandwidth(48).WithSwitchLatency(32).WithVisTracer(observer)
			c.CreateNetwork("PortBinding")
			c.AddTile([3]int{1, 0, 0}, []sim.Port{central.port})
			left, right := []sim.Port{a.port}, []sim.Port{b.port}
			if test.duplicate {
				left = append(left, central.port)
				right = append(right, central.port)
			}
			c.AddTile([3]int{0, 0, 0}, left)
			c.AddTile([3]int{2, 0, 0}, right)
			c.EstablishNetwork()
			req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(4096).WithSrc(a.port).WithDst(central.port).Build()
			port := a.port
			if test.destinationSend {
				port = central.port
			}
			if port.Send(req) != nil {
				t.Fatal("request rejected")
			}
			if err := engine.Run(); err != nil {
				t.Fatal(err)
			}
			if len(central.received) != 1 || central.received[0] != req {
				t.Fatal("incorrect delivery")
			}
			actual := observer.Snapshot()["channel_flit.all"].Started
			t.Logf("inter_switch_links=%d request_cycles=%.6f", actual, float64(req.RecvTime-req.SendTime)*1e9)
			if actual != test.hops {
				t.Fatalf("got %d hops, want %d", actual, test.hops)
			}
		})
	}
}
