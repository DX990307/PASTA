package mesh

import (
	"fmt"
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/noc/networking/trafficstats"
	"github.com/sarchlab/akita/v3/sim"
)

func observedMeshWorkload(t *testing.T, latency int, observe bool) ([]string, map[string]trafficstats.Counter) {
	t.Helper()
	engine := sim.NewSerialEngine()
	a, b := newLatencyTestPeer(engine, "Left"), newLatencyTestPeer(engine, "Right")
	a.releaseCycle, b.releaseCycle = 500, 500
	c := NewConnector().WithEngine(engine).WithFreq(sim.GHz).WithFlitSize(16).
		WithBandwidth(48).WithSwitchLatency(latency).WithFixedIngressCapacity(1536)
	var tracer *trafficstats.Tracer
	if observe {
		tracer = trafficstats.New(engine, func(msg sim.Msg) string { return msg.(*vm.TranslationReq).TracePath }, nil)
		c.WithVisTracer(tracer)
	}
	c.CreateNetwork("ObservedMesh")
	c.AddTile([3]int{0, 0, 0}, []sim.Port{a.port})
	c.AddTile([3]int{2, 1, 0}, []sim.Port{b.port})
	c.EstablishNetwork()
	for i := 0; i < 64; i++ {
		for _, pair := range [][2]*latencyTestPeer{{a, b}, {b, a}} {
			req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(uint64(i) * 4096).
				WithSrc(pair[0].port).WithDst(pair[1].port).Build()
			req.TracePath = "native"
			if i%2 != 0 {
				req.TracePath = "assist"
			}
			if i%3 == 0 {
				req.TrafficBytes = 128
			}
			pair[0].pending = append(pair[0].pending, req)
		}
	}
	a.TickLater(0)
	b.TickLater(0)
	if err := engine.Run(); err != nil {
		t.Fatal(err)
	}
	result := []string{}
	for _, peer := range []*latencyTestPeer{a, b} {
		if len(peer.pending) != 0 || len(peer.received) != 64 {
			t.Fatal("incomplete replay")
		}
		for _, msg := range peer.received {
			req := msg.(*vm.TranslationReq)
			result = append(result, fmt.Sprintf("%s/%d/%s/%d/%.15g/%.15g", peer.Name(), req.VAddr, req.TracePath, req.TrafficBytes, req.SendTime, req.RecvTime))
		}
	}
	stats := c.FixedIngressStats()
	// A 3-by-2 mesh has seven bidirectional inter-switch links, fourteen ingresses.
	if len(stats) != 14 {
		t.Fatalf("fixed queue applied to wrong ports: %d", len(stats))
	}
	for _, stat := range stats {
		if stat["capacity_flits"] != 1536 || stat["latency_cycles"] != uint64(latency) || stat["width_flits_per_cycle"] != 48 ||
			stat["accepted_flits"] != stat["departed_flits"] || stat["inflight_flits"] != 0 {
			t.Fatal("wrong topology/resource/retirement counters", stat)
		}
	}
	if tracer == nil {
		return result, nil
	}
	return result, tracer.Snapshot()
}

func TestNetworkObservationDoesNotChangeDeliveryOrTiming(t *testing.T) {
	for _, latency := range []int{16, 32, 64} {
		without, _ := observedMeshWorkload(t, latency, false)
		with, stats := observedMeshWorkload(t, latency, true)
		if !reflect.DeepEqual(without, with) {
			t.Fatal("read-only network observation changed delivery order, timing, or packets")
		}
		for _, class := range []string{"native", "assist"} {
			count := stats["message_e2e."+class]
			if count.Started != 64 || count.Completed != 64 || count.Inflight != 0 || count.InvalidDurations != 0 || count.Seconds <= 0 {
				t.Fatal("wrong message counters", count)
			}
			flit := stats["flit_e2e."+class]
			channel := stats["channel_flit."+class]
			if flit.Started != flit.Completed || channel.Started != flit.Started*3 || channel.Completed != channel.Started {
				t.Fatal("flit/hop counts inconsistent", flit, channel)
			}
		}
	}
}
