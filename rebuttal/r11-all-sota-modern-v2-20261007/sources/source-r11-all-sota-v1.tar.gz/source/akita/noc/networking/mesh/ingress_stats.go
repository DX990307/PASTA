package mesh

// FixedIngressStats reports inter-switch queues without changing their state.
func (c *Connector) FixedIngressStats() map[string]map[string]uint64 {
	return c.connector.FixedIngressStats()
}
