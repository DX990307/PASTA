package trafficstats

import (
	"math"
	"reflect"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/noc/messaging"
	"github.com/sarchlab/akita/v3/sim"
	"github.com/sarchlab/akita/v3/tracing"
)

func TestMessageCountersAndInflightCensoring(t *testing.T) {
	tr := New(nil, nil, nil)
	a, b := vm.TranslationReqBuilder{}.Build(), vm.TranslationReqBuilder{}.Build()
	a.TrafficBytes = 48
	tr.StartTask(tracing.Task{ID: "a", Kind: "msg_e2e", StartTime: 1e-9, Detail: a})
	tr.StartTask(tracing.Task{ID: "b", Kind: "msg_e2e", StartTime: 2e-9, Detail: b})
	tr.EndTask(tracing.Task{ID: "a", EndTime: 11e-9})
	stats := tr.Snapshot()["message_e2e.all"]
	if stats.Started != 2 || stats.Completed != 1 || stats.Inflight != 1 ||
		stats.DeclaredBytes != 48 || stats.ZeroByteMessages != 1 || math.Abs(stats.Seconds-10e-9) > 1e-18 {
		t.Fatalf("incorrect counts: %+v", stats)
	}
	copy := tr.Snapshot()
	copy["message_e2e.all"] = Counter{}
	if !reflect.DeepEqual(stats, tr.Snapshot()["message_e2e.all"]) {
		t.Fatal("snapshot aliases internal state")
	}
	if a.TrafficBytes != 48 || b.TrafficBytes != 0 {
		t.Fatal("observation changed packet size")
	}
}

func TestDuplicateFlitStartsKeepOriginalTimestamp(t *testing.T) {
	tr := New(nil, func(msg sim.Msg) string { return "native" }, nil)
	flit := messaging.FlitBuilder{}.WithMsg(vm.TranslationReqBuilder{}.Build()).Build()
	tr.StartTask(tracing.Task{ID: "f", Kind: "flit_e2e", StartTime: 1e-9, Detail: flit})
	tr.StartTask(tracing.Task{ID: "f", Kind: "flit_e2e", StartTime: 9e-9, Detail: flit})
	tr.EndTask(tracing.Task{ID: "f", EndTime: 11e-9})
	stats := tr.Snapshot()["flit_e2e.native"]
	if stats.Started != 1 || stats.Completed != 1 || stats.DuplicateStarts != 1 ||
		stats.Inflight != 0 || math.Abs(stats.Seconds-10e-9) > 1e-18 {
		t.Fatalf("bad dedup: %+v", stats)
	}
}

func TestSwitchAndChannelTaskScopesStaySeparate(t *testing.T) {
	tr := New(nil, nil, nil)
	flit := messaging.FlitBuilder{}.WithMsg(vm.TranslationReqBuilder{}.Build()).Build()
	tr.StartTask(tracing.Task{ID: "s", Kind: "flit", What: "flit_inside_sw", StartTime: 1e-9, Detail: flit})
	tr.StartTask(tracing.Task{ID: "c", Kind: "flit.vm", What: "flit_through_channel", StartTime: 4e-9, Detail: flit})
	tr.EndTask(tracing.Task{ID: "s", EndTime: 4e-9})
	tr.EndTask(tracing.Task{ID: "c", EndTime: 5e-9})
	counts := tr.Snapshot()
	if len(counts) != 2 || counts["switch_flit.all"].Completed != 1 || counts["channel_flit.all"].Completed != 1 {
		t.Fatal(counts)
	}
}
