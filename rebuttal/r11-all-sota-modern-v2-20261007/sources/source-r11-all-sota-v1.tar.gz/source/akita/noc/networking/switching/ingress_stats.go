package switching

// FixedIngressStats reports only the explicitly selected fixed-capacity queues.
func (s *Switch) FixedIngressStats() map[string]map[string]uint64 {
	result := make(map[string]map[string]uint64)
	for _, port := range s.ports {
		p := s.portToComplexMapping[port].pipeline
		if stats, ok := p.(interface{ DelayQueueStats() map[string]uint64 }); ok {
			result[p.Name()] = stats.DelayQueueStats()
		}
	}
	return result
}
