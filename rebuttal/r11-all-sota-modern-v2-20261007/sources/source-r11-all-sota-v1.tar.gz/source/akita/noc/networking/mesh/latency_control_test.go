package mesh

import (
	"fmt"
	"math"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

type latencyTestPeer struct {
	*sim.TickingComponent
	port         sim.Port
	pending      []sim.Msg
	received     []sim.Msg
	releaseCycle uint64
}

func newLatencyTestPeer(engine sim.Engine, name string) *latencyTestPeer {
	p := &latencyTestPeer{}
	p.TickingComponent = sim.NewTickingComponent(name, engine, sim.GHz, p)
	p.port = sim.NewLimitNumMsgPort(p, 1, name+".Port")
	p.AddPort("Port", p.port)
	return p
}

func (p *latencyTestPeer) Tick(now sim.VTimeInSec) bool {
	progress := false
	if len(p.pending) > 0 {
		msg := p.pending[0]
		msg.Meta().SendTime = now
		if p.port.Send(msg) == nil {
			p.pending = p.pending[1:]
			progress = true
		}
	}
	if p.port.Peek() != nil && p.Freq.Cycle(now) < p.releaseCycle {
		return true
	}
	if msg := p.port.Retrieve(now); msg != nil {
		p.received = append(p.received, msg)
		progress = true
	}
	return progress
}

func measuredMeshDelay(t *testing.T, hops, latency int) sim.VTimeInSec {
	t.Helper()
	return measuredMeshDelayWithCapacity(t, hops, latency, 0)
}

func measuredMeshDelayWithCapacity(t *testing.T, hops, latency, capacity int) sim.VTimeInSec {
	t.Helper()
	engine := sim.NewSerialEngine()
	a, b := newLatencyTestPeer(engine, "Source"), newLatencyTestPeer(engine, "Sink")
	c := NewConnector().WithEngine(engine).WithFreq(sim.GHz).WithFlitSize(16).
		WithBandwidth(48).WithSwitchLatency(latency).WithFixedIngressCapacity(capacity)
	c.CreateNetwork("LatencyControl")
	c.AddTile([3]int{0, 0, 0}, []sim.Port{a.port})
	c.AddTile([3]int{hops, 0, 0}, []sim.Port{b.port})
	c.EstablishNetwork()
	req := vm.TranslationReqBuilder{}.WithPID(1).WithVAddr(4096).
		WithSrc(a.port).WithDst(b.port).Build()
	a.pending = append(a.pending, req)
	a.TickLater(0)
	if err := engine.Run(); err != nil {
		t.Fatal(err)
	}
	if len(a.pending) != 0 || len(b.received) != 1 || b.received[0] != req {
		t.Fatal("message was lost, duplicated, or routed to the wrong destination")
	}
	return req.RecvTime - req.SendTime
}

func TestMeshSwitchLatencyAddsPerTraversedLinkIngress(t *testing.T) {
	for _, hops := range []int{1, 2, 3} {
		var previous sim.VTimeInSec
		previousLatency := 0
		for _, latency := range []int{16, 32, 64} {
			delay := measuredMeshDelay(t, hops, latency)
			t.Logf("hops=%d switch_stages=%d one_way_cycles=%.6f", hops, latency, float64(delay)*1e9)
			if previousLatency != 0 {
				want := float64(hops*(latency-previousLatency)) * 1e-9
				if math.Abs(float64(delay-previous)-want) > 1e-12 {
					t.Fatalf("per-hop latency delta=%g, want %g", delay-previous, want)
				}
			}
			previous, previousLatency = delay, latency
		}
	}
}

func TestMeshFixedCoordinatesAndBidirectionalRequestIdentity(t *testing.T) {
	engine := sim.NewSerialEngine()
	a, b := newLatencyTestPeer(engine, "Left"), newLatencyTestPeer(engine, "Right")
	c := NewConnector().WithEngine(engine).WithFreq(sim.GHz).WithFlitSize(16).
		WithBandwidth(48).WithSwitchLatency(32)
	c.CreateNetwork("BidirectionalControl")
	c.AddTile([3]int{0, 0, 0}, []sim.Port{a.port})
	c.AddTile([3]int{2, 1, 0}, []sim.Port{b.port})
	c.EstablishNetwork()
	expected := map[string]sim.Msg{}
	for i := 0; i < 64; i++ {
		for _, pair := range [][2]*latencyTestPeer{{a, b}, {b, a}} {
			req := vm.TranslationReqBuilder{}.WithPID(vm.PID(i + 1)).WithVAddr(uint64(i) * 4096).
				WithSrc(pair[0].port).WithDst(pair[1].port).Build()
			pair[0].pending = append(pair[0].pending, req)
			expected[req.ID] = req
		}
	}
	a.TickLater(0)
	b.TickLater(0)
	if err := engine.Run(); err != nil {
		t.Fatal(err)
	}
	for _, peer := range []*latencyTestPeer{a, b} {
		if len(peer.received) != 64 || len(peer.pending) != 0 {
			t.Fatalf("%s did not transfer every request", peer.Name())
		}
		for _, msg := range peer.received {
			if expected[msg.Meta().ID] != msg || msg.Meta().Dst != peer.port {
				t.Fatal(fmt.Sprintf("wrong or duplicate request %s", msg.Meta().ID))
			}
			delete(expected, msg.Meta().ID)
		}
	}
	if len(expected) != 0 {
		t.Fatal("requests missing after network quiescence")
	}
}
