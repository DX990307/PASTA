package mesh

import (
	"math"
	"testing"

	"github.com/sarchlab/akita/v3/mem/vm"
	"github.com/sarchlab/akita/v3/sim"
)

func TestFixedCapacityMeshPreservesUnloadedDelay(t *testing.T) {
	for _, hops := range []int{1, 2, 3} {
		for _, latency := range []int{16, 32, 64} {
			legacy := measuredMeshDelay(t, hops, latency)
			fixed := measuredMeshDelayWithCapacity(t, hops, latency, 1536)
			if math.Abs(float64(fixed-legacy)) > 1e-12 {
				t.Fatalf("hops=%d latency=%d legacy=%g fixed=%g", hops, latency, legacy, fixed)
			}
			t.Logf("hops=%d delay_cycles=%d capacity=1536 observed_cycles=%.6f", hops, latency, float64(fixed)*1e9)
		}
	}
}

func TestFixedCapacityMeshBackpressureAndMultiFlitIdentity(t *testing.T) {
	for _, latency := range []int{16, 32, 64} {
		engine := sim.NewSerialEngine()
		a, b := newLatencyTestPeer(engine, "Left"), newLatencyTestPeer(engine, "Right")
		a.releaseCycle, b.releaseCycle = 3000, 3000
		c := NewConnector().WithEngine(engine).WithFreq(sim.GHz).WithFlitSize(16).
			WithBandwidth(48).WithSwitchLatency(latency).WithFixedIngressCapacity(16)
		c.CreateNetwork("BackpressureControl")
		c.AddTile([3]int{0, 0, 0}, []sim.Port{a.port})
		c.AddTile([3]int{2, 1, 0}, []sim.Port{b.port})
		c.EstablishNetwork()
		expected := map[string]sim.Msg{}
		for i := 0; i < 256; i++ {
			for _, pair := range [][2]*latencyTestPeer{{a, b}, {b, a}} {
				req := vm.TranslationReqBuilder{}.WithPID(vm.PID(i + 1)).WithVAddr(uint64(i) * 4096).
					WithSrc(pair[0].port).WithDst(pair[1].port).Build()
				req.Meta().TrafficBytes = 256
				pair[0].pending = append(pair[0].pending, req)
				expected[req.ID] = req
			}
		}
		a.TickLater(0)
		b.TickLater(0)
		if err := engine.Run(); err != nil {
			t.Fatal(err)
		}
		for _, peer := range []*latencyTestPeer{a, b} {
			if len(peer.received) != 256 || len(peer.pending) != 0 {
				t.Fatal("incomplete transfer after backpressure")
			}
			for _, msg := range peer.received {
				if expected[msg.Meta().ID] != msg || msg.Meta().Dst != peer.port {
					t.Fatal("wrong or duplicated request")
				}
				delete(expected, msg.Meta().ID)
			}
		}
		if len(expected) != 0 {
			t.Fatal("missing requests")
		}
	}
}
