package pipelining

import (
	"fmt"
	"testing"

	"github.com/sarchlab/akita/v3/sim"
)

type delayTestItem int

func (i delayTestItem) TaskID() string { return fmt.Sprint(int(i)) }

func TestDelayQueueExactLatencyAndClock(t *testing.T) {
	for _, freq := range []sim.Freq{sim.GHz, 2 * sim.GHz} {
		for _, latency := range []int{1, 16, 32, 64} {
			out := sim.NewBuffer("Output", 8)
			p := NewDelayQueue("Delay", freq, latency, 2, 8, out)
			start := 1000000
			now := sim.VTimeInSec(float64(start) / float64(freq))
			p.Tick(now)
			p.Accept(now, delayTestItem(1))
			for cycle := 0; cycle < latency; cycle++ {
				if !p.Tick(sim.VTimeInSec(float64(start+cycle) / float64(freq))) {
					t.Fatal("pending propagation must keep the component ticking")
				}
				if out.Peek() != nil {
					t.Fatal("item arrived before its configured delay")
				}
			}
			p.Tick(sim.VTimeInSec(float64(start+latency) / float64(freq)))
			if out.Pop() != delayTestItem(1) || out.Peek() != nil {
				t.Fatal("item did not arrive exactly at its ready cycle")
			}
		}
	}
}

func TestDelayQueueWidthBudgetSurvivesRepeatedTicks(t *testing.T) {
	out := sim.NewBuffer("Output", 20)
	p := NewDelayQueue("Delay", sim.GHz, 1, 2, 8, out)
	p.Tick(0)
	p.Accept(0, delayTestItem(0))
	p.Accept(0, delayTestItem(1))
	p.Tick(0)
	if p.CanAccept() {
		t.Fatal("a repeated same-cycle tick reset the input budget")
	}
	for cycle := 1; cycle <= 10; cycle++ {
		now := sim.VTimeInSec(cycle) / 1e9
		p.Tick(now)
		for lane := 0; lane < 2; lane++ {
			if out.Pop() != delayTestItem((cycle-1)*2+lane) {
				t.Fatal("full-rate FIFO stream lost order or bandwidth")
			}
		}
		p.Tick(now)
		if out.Peek() != nil {
			t.Fatal("output exceeded its width")
		}
		p.Accept(now, delayTestItem(cycle*2))
		p.Accept(now, delayTestItem(cycle*2+1))
	}
}

func TestDelayQueueFixedCapacityAndBackpressure(t *testing.T) {
	for _, latency := range []int{16, 32, 64} {
		out := sim.NewBuffer("Output", 1)
		out.Push(delayTestItem(-1))
		p := NewDelayQueue("Delay", sim.GHz, latency, 48, 1536, out).(*delayQueue)
		accepted := 0
		for cycle := 0; cycle < 200; cycle++ {
			now := sim.VTimeInSec(cycle) / 1e9
			p.Tick(now)
			for p.CanAccept() {
				p.Accept(now, delayTestItem(accepted))
				accepted++
			}
		}
		if accepted != 1536 || p.size != 1536 || p.CanAccept() {
			t.Fatalf("latency %d changed fixed capacity: %d", latency, accepted)
		}
		out.Pop()
		for want := 0; want < accepted; want++ {
			// Deliberately skip time while blocked: all retained entries have aged.
			p.Tick(sim.VTimeInSec(10000+want) / 1e9)
			if out.Pop() != delayTestItem(want) {
				t.Fatalf("lost/reordered item %d after backpressure", want)
			}
		}
		if p.size != 0 || !p.CanAccept() {
			t.Fatal("queue failed to release storage")
		}
	}
}

func TestDelayQueueReadyItemsAgeAcrossUntickedInterval(t *testing.T) {
	out := sim.NewBuffer("Output", 4)
	for i := 0; i < 4; i++ {
		out.Push(delayTestItem(-1))
	}
	p := NewDelayQueue("Delay", sim.GHz, 64, 2, 8, out)
	p.Tick(0)
	p.Accept(0, delayTestItem(1))
	p.Tick(63e-9)
	p.Accept(63e-9, delayTestItem(2))
	if p.Tick(64e-9) {
		t.Fatal("ready but blocked queue need not spin")
	}
	for out.Peek() != nil {
		out.Pop()
	}
	p.Tick(1000e-9)
	if out.Pop() != delayTestItem(1) || out.Pop() != delayTestItem(2) {
		t.Fatal("unticked time failed to age the later item")
	}
}

func TestDelayQueueBlockedBurstHonorsOutputWidth(t *testing.T) {
	out := sim.NewBuffer("Output", 8)
	for i := 0; i < 8; i++ {
		out.Push(delayTestItem(-1))
	}
	p := NewDelayQueue("Delay", sim.GHz, 1, 2, 8, out)
	for cycle := 0; cycle < 4; cycle++ {
		now := sim.VTimeInSec(cycle) / 1e9
		p.Tick(now)
		p.Accept(now, delayTestItem(cycle*2))
		p.Accept(now, delayTestItem(cycle*2+1))
	}
	for out.Peek() != nil {
		out.Pop()
	}
	for cycle := 10; cycle < 14; cycle++ {
		now := sim.VTimeInSec(cycle) / 1e9
		p.Tick(now)
		p.Tick(now)
		for lane := 0; lane < 2; lane++ {
			if out.Pop() != delayTestItem((cycle-10)*2+lane) {
				t.Fatal("burst order changed")
			}
		}
		if out.Peek() != nil {
			t.Fatal("burst exceeded output width")
		}
	}
}

func TestDelayQueueRingWrapAndClear(t *testing.T) {
	out := sim.NewBuffer("Output", 1)
	p := NewDelayQueue("Delay", sim.GHz, 1, 2, 3, out).(*delayQueue)
	for cycle := 0; cycle < 100; cycle++ {
		now := sim.VTimeInSec(cycle) / 1e9
		p.Tick(now)
		if cycle > 0 && out.Pop() != delayTestItem(cycle-1) {
			t.Fatal("ring wrap reordered data")
		}
		p.Accept(now, delayTestItem(cycle))
	}
	p.Clear()
	if p.size != 0 || !p.CanAccept() {
		t.Fatal("clear retained occupancy or credits")
	}
	for _, item := range p.items {
		if item.elem != nil {
			t.Fatal("clear retained an item")
		}
	}
	p.Tick(0)
	p.Accept(0, delayTestItem(999))
	p.Tick(1e-9)
	if out.Pop() != delayTestItem(999) {
		t.Fatal("cleared queue failed to restart")
	}
}

func TestDelayQueueRejectsInvalidParameters(t *testing.T) {
	for _, params := range [][4]int{{0, 1, 1, 1}, {1, 0, 1, 1}, {1, 1, 0, 1}, {1, 1, 1, 0}, {1, -1, 1, 1}} {
		t.Run(fmt.Sprint(params), func(t *testing.T) {
			defer func() {
				if recover() == nil {
					t.Fatal("invalid queue accepted")
				}
			}()
			NewDelayQueue("Delay", sim.Freq(params[0]), params[1], params[2], params[3], sim.NewBuffer("Output", 1))
		})
	}
}
